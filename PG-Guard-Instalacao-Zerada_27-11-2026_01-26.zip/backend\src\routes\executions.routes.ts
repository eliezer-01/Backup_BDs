import fs from 'node:fs';
import path from 'node:path';
import type { FastifyInstance } from 'fastify';
import { env } from '../config/env';
import { getDatabase } from '../db/sqlite';
import { authenticateRequest, requirePermission } from '../security/auth';

/**
 * Registra as rotas de consulta ao histórico de execuções, logs e download de backups.
 *
 * @example
 * app.register(executionsRoutes, { prefix: '/api/executions' });
 */
export async function executionsRoutes(app: FastifyInstance): Promise<void> {
  app.addHook('preHandler', authenticateRequest);

  app.get('/', { preHandler: [requirePermission('logs:read')] }, async () => {
    const db = getDatabase();
    const executions = db
      .prepare(`
        SELECT
          e.id, e.type, e.profile_id, e.source_connection_id, e.target_connection_id,
          e.database_name, e.status, e.command_preview, e.file_path, e.file_size_bytes,
          e.started_at, e.finished_at, e.duration_ms, e.error_message,
          sc.name as source_connection_name,
          tc.name as target_connection_name
        FROM executions e
        LEFT JOIN connections sc ON sc.id = e.source_connection_id
        LEFT JOIN connections tc ON tc.id = e.target_connection_id
        ORDER BY e.started_at DESC
        LIMIT 100
      `)
      .all();

    return { executions };
  });

  app.get<{ Params: { id: string } }>('/:id', { preHandler: [requirePermission('logs:read')] }, async (request, reply) => {
    const db = getDatabase();
    const execution = db.prepare('SELECT * FROM executions WHERE id = ?').get(request.params.id);
    if (!execution) {
      return reply.status(404).send({ error: 'Execução não encontrada.' });
    }
    return { execution };
  });

  app.get<{ Params: { id: string } }>('/:id/download', { preHandler: [requirePermission('logs:download')] }, async (request, reply) => {
    const db = getDatabase();
    const execution = db
      .prepare('SELECT file_path FROM executions WHERE id = ?')
      .get(request.params.id) as { file_path: string | null } | undefined;

    if (!execution || !execution.file_path) {
      return reply.status(404).send({ error: 'Arquivo de backup não associado a esta execução.' });
    }

    const resolved = path.resolve(execution.file_path);
    const allowedRoots = [path.resolve(env.BACKUP_DIR), path.resolve(env.CUSTOM_BACKUP_DIR)];
    const isAllowed = allowedRoots.some((root) => resolved.startsWith(root + path.sep));

    if (!isAllowed || !fs.existsSync(resolved)) {
      return reply.status(404).send({ error: 'Arquivo não encontrado no disco (pode ter sido removido pela rotação).' });
    }

    const fileName = path.basename(resolved);
    const stat = fs.statSync(resolved);
    if (stat.isDirectory()) {
      return reply.status(400).send({
        error: 'Backups no formato Directory (-Fd) são pastas no servidor e não podem ser baixados como arquivo único.'
      });
    }

    reply.header('Content-Disposition', `attachment; filename="${fileName}"`);
    return reply.send(fs.createReadStream(resolved));
  });
}
