import crypto from 'node:crypto';
import type { FastifyReply, FastifyRequest } from 'fastify';
import { env } from '../config/env';
import { getDatabase } from '../db/sqlite';
import { ALL_PERMISSIONS, type Permission } from './permissions';

/**
 * Gera o hash seguro de uma senha utilizando `scrypt` com salt aleatório de 16 bytes.
 *
 * @param password Senha em texto plano.
 * @returns String formatada `salt:hash` em hexadecimal.
 * @example
 * const hash = hashPassword('SenhaForte!2026');
 */
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derivedKey = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derivedKey}`;
}

/**
 * Verifica se a senha informada corresponde ao hash armazenado usando comparação em tempo constante.
 *
 * @param password Senha em texto plano informada no login.
 * @param storedHash Hash salvo no banco no formato `salt:hash`.
 * @returns `true` se a senha for válida.
 * @example
 * const ok = verifyPassword('SenhaForte!2026', user.password_hash);
 */
export function verifyPassword(password: string, storedHash: string): boolean {
  const [salt, key] = storedHash.split(':');
  if (!salt || !key) return false;

  const keyBuffer = Buffer.from(key, 'hex');
  const derivedBuffer = crypto.scryptSync(password, salt, 64);

  if (keyBuffer.length !== derivedBuffer.length) return false;
  return crypto.timingSafeEqual(keyBuffer, derivedBuffer);
}

/**
 * Garante que o usuário administrador inicial definido no `.env` exista na tabela `users`,
 * vinculado ao perfil `Administrador`. Executado apenas no primeiro boot (quando `users` está vazia).
 *
 * @example
 * ensureInitialAdminUser();
 */
export function ensureInitialAdminUser(): void {
  const db = getDatabase();
  const countRow = db.prepare('SELECT COUNT(*) as total FROM users').get() as { total: number };

  if (countRow.total === 0) {
    const adminRole = db
      .prepare("SELECT id FROM roles WHERE name = 'Administrador'")
      .get() as { id: string } | undefined;

    const id = crypto.randomUUID();
    const passwordHash = hashPassword(env.ADMIN_PASSWORD);
    db.prepare('INSERT INTO users (id, username, password_hash, role_id, is_master) VALUES (?, ?, ?, ?, 1)').run(
      id,
      env.ADMIN_USER,
      passwordHash,
      adminRole?.id ?? null
    );
    console.log(`🔐 Usuário administrador inicial '${env.ADMIN_USER}' criado com sucesso.`);
  }
}

/**
 * Retorna o perfil e a lista de permissões atuais de um usuário a partir do SQLite.
 *
 * @param userId UUID do usuário autenticado.
 * @example
 * const info = getUserAccessInfo(user.id);
 */
export function getUserAccessInfo(userId: string): {
  roleId: string | null;
  roleName: string;
  permissions: Permission[];
  isMaster: boolean;
} {
  const db = getDatabase();
  const row = db
    .prepare(`
      SELECT u.is_master, r.id as role_id, r.name as role_name, r.is_system, r.permissions_json
      FROM users u
      LEFT JOIN roles r ON r.id = u.role_id
      WHERE u.id = ?
    `)
    .get(userId) as {
      is_master: number;
      role_id: string | null;
      role_name: string | null;
      is_system: number | null;
      permissions_json: string | null;
    } | undefined;

  if (!row || !row.permissions_json) {
    return { roleId: null, roleName: 'Sem Perfil', permissions: [], isMaster: row?.is_master === 1 };
  }

  if (row.is_system === 1 || row.is_master === 1) {
    return {
      roleId: row.role_id,
      roleName: row.role_name ?? 'Administrador',
      permissions: [...ALL_PERMISSIONS],
      isMaster: row.is_master === 1
    };
  }

  try {
    return {
      roleId: row.role_id,
      roleName: row.role_name ?? 'Personalizado',
      permissions: JSON.parse(row.permissions_json) as Permission[],
      isMaster: row.is_master === 1
    };
  } catch {
    return { roleId: row.role_id, roleName: row.role_name ?? 'Personalizado', permissions: [], isMaster: row.is_master === 1 };
  }
}

/**
 * Hook de autenticação JWT para proteger rotas privadas da API.
 * Retorna HTTP 401 caso o token esteja ausente, expirado ou inválido.
 *
 * @example
 * fastify.get('/api/connections', { preHandler: [authenticateRequest] }, handler);
 */
export async function authenticateRequest(request: FastifyRequest, reply: FastifyReply): Promise<void> {
  try {
    await request.jwtVerify();
  } catch {
    return reply.status(401).send({
      error: 'Não autorizado',
      message: 'Token de autenticação inválido ou expirado. Faça login novamente.'
    });
  }
}

/**
 * Cria um middleware de autorização modular que exige pelo menos uma das permissões
 * informadas (suporta permissões granulares novas e chaves legadas).
 *
 * @param acceptedPermissions Lista de permissões aceitas para a rota.
 * @example
 * app.post('/', { preHandler: [requirePermission('jobs:create', 'schedules:manage')] }, handler);
 */
export function requirePermission(...acceptedPermissions: Permission[]) {
  return async (request: FastifyRequest, reply: FastifyReply): Promise<void> => {
    const userPayload = request.user as { sub?: string } | undefined;
    if (!userPayload?.sub) {
      return reply.status(401).send({ error: 'Não autorizado.' });
    }

    const access = getUserAccessInfo(userPayload.sub);
    const hasAny = acceptedPermissions.some((p) => access.permissions.includes(p));
    if (!hasAny) {
      return reply.status(403).send({
        error: 'Acesso negado',
        message: `Seu perfil (${access.roleName}) não possui permissão para esta ação (${acceptedPermissions[0]}).`
      });
    }
  };
}
