#!/usr/bin/env bash
set -euo pipefail

cd "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "========================================================================"
echo "  PG Guard - Instalacao e Atualizacao Automatica (Linux / macOS)"
echo "========================================================================"
echo

OS_TYPE="$(uname -s)"
echo "[INFO] Sistema operacional detectado: $OS_TYPE"
mkdir -p atualizacao

# 1. Verifica e instala o Docker automaticamente conforme o SO
if ! command -v docker >/dev/null 2>&1; then
  echo "[0/5] Docker nao encontrado. Instalando automaticamente..."
  if [ "$OS_TYPE" = "Darwin" ]; then
    if ! command -v brew >/dev/null 2>&1; then
      echo "[ERRO] Homebrew nao encontrado no macOS. Instale em https://brew.sh e rode novamente."
      exit 1
    fi
    brew install --cask docker
  elif [ "$OS_TYPE" = "Linux" ]; then
    if command -v curl >/dev/null 2>&1; then
      curl -fsSL https://get.docker.com | sh
    else
      echo "[ERRO] 'curl' nao encontrado para instalar o Docker automaticamente."
      exit 1
    fi
    if command -v systemctl >/dev/null 2>&1; then
      sudo systemctl enable --now docker || true
    fi
  else
    echo "[ERRO] Sistema operacional nao suportado automaticamente: $OS_TYPE"
    exit 1
  fi
fi

# 2. Verifica se o daemon do Docker esta rodando; inicia se necessario
if ! docker info >/dev/null 2>&1; then
  echo "[0/5] Iniciando o servico Docker..."
  if [ "$OS_TYPE" = "Darwin" ]; then
    open -a Docker
  elif [ "$OS_TYPE" = "Linux" ]; then
    if command -v systemctl >/dev/null 2>&1; then
      sudo systemctl start docker
    elif command -v service >/dev/null 2>&1; then
      sudo service docker start
    fi
  fi

  for i in $(seq 1 40); do
    if docker info >/dev/null 2>&1; then
      break
    fi
    echo "       Aguardando motor do Docker iniciar ($i/40)..."
    sleep 3
  done

  if ! docker info >/dev/null 2>&1; then
    echo "[ERRO] Docker nao respondeu a tempo. Verifique o servico e tente novamente."
    exit 1
  fi
fi

# 2.1 Verifica no Linux se o Docker inicia automaticamente no boot
if [ "$OS_TYPE" = "Linux" ] && command -v systemctl >/dev/null 2>&1; then
  if systemctl is-enabled docker >/dev/null 2>&1; then
    echo "[OK] Inicializacao automatica do Docker no boot ja esta ATIVA."
  else
    echo "[AVISO] O Docker nao esta configurado para iniciar no boot do Linux."
    read -r -p "Deseja ativar a inicializacao automatica (systemctl enable docker)? [s/N]: " RESP_AUTO
    if [[ "$RESP_AUTO" =~ ^[sS]$ ]]; then
      sudo systemctl enable docker && echo "[OK] Inicializacao automatica ativada!"
    else
      echo "[OK] Mantido como inicializacao manual."
    fi
  fi
fi

# 3. Verifica atualizacoes em ./atualizacao/ ou via argumento ($1)
UPDATE_SRC="${1:-}"
FROM_DEFAULT_DIR=0
NEEDS_BUILD=0

if [ "$UPDATE_SRC" = "--rebuild" ]; then
  UPDATE_SRC=""
  NEEDS_BUILD=1
fi

if [ -z "$UPDATE_SRC" ]; then
  if [ -n "$(find ./atualizacao -mindepth 1 -maxdepth 1 ! -name 'LEIA-ME.txt' 2>/dev/null)" ]; then
    UPDATE_SRC="./atualizacao"
    FROM_DEFAULT_DIR=1
  fi
fi

if [ -n "$UPDATE_SRC" ]; then
  if [ ! -d "$UPDATE_SRC" ]; then
    echo "[ERRO] Pasta de atualizacao nao encontrada: $UPDATE_SRC"
    exit 1
  fi

  echo "[1/5] Mudancas detectadas em $UPDATE_SRC. Substituindo arquivos..."
  NEEDS_BUILD=1

  if [ -f "data/db/app.sqlite" ]; then
    cp "data/db/app.sqlite" "data/db/app.sqlite.bak"
  fi

  if command -v rsync >/dev/null 2>&1; then
    rsync -a \
      --exclude 'data' \
      --exclude 'node_modules' \
      --exclude 'dist' \
      --exclude '.git' \
      --exclude '.env' \
      --exclude 'atualizacao' \
      --exclude 'LEIA-ME.txt' \
      "$UPDATE_SRC/" "./"
  else
    tar -C "$UPDATE_SRC" \
      --exclude='data' \
      --exclude='node_modules' \
      --exclude='dist' \
      --exclude='.git' \
      --exclude='.env' \
      --exclude='atualizacao' \
      --exclude='LEIA-ME.txt' \
      -cf - . | tar -xf -
  fi

  if [ "$FROM_DEFAULT_DIR" -eq 1 ]; then
    find ./atualizacao -mindepth 1 ! -name 'LEIA-ME.txt' -delete
    echo "[OK] Pasta ./atualizacao/ limpa apos aplicar as mudancas."
  fi
  echo "[OK] Arquivos atualizados preservando seus dados e senhas!"
else
  echo "[1/5] Nenhuma mudanca nova em ./atualizacao/. Iniciando/atualizando sistema atual..."
fi

# 4. Cria .env na primeira instalacao ou mescla novas variaveis do .env.example
if [ ! -f ".env" ]; then
  echo "[2/5] Primeira instalacao detectada. Gerando .env seguro..."
  MASTER_KEY="$(openssl rand -hex 32)"
  JWT_KEY="$(openssl rand -base64 24)"
  DEFAULT_HOST_DIR="/"
  if [ "$OS_TYPE" = "Darwin" ]; then
    DEFAULT_HOST_DIR="$HOME"
  fi
  sed -e "s|^MASTER_ENCRYPTION_KEY=.*|MASTER_ENCRYPTION_KEY=$MASTER_KEY|" \
      -e "s|^JWT_SECRET=.*|JWT_SECRET=$JWT_KEY|" \
      -e "s|^CUSTOM_BACKUP_HOST_DIR=.*|CUSTOM_BACKUP_HOST_DIR=$DEFAULT_HOST_DIR|" \
      .env.example > .env
  echo "[OK] Arquivo .env criado com chaves aleatorias!"
else
  echo "[2/5] Verificando novas variaveis em .env.example para mesclar no .env..."
  if [ -f ".env.example" ]; then
    while IFS= read -r line; do
      if [[ "$line" =~ ^[[:space:]]*([A-Za-z0-9_]+)= ]]; then
        KEY="${BASH_REMATCH[1]}"
        if ! grep -qE "^[[:space:]]*${KEY}=" .env; then
          echo "$line" >> .env
          echo "[OK] Nova variavel adicionada ao .env: $KEY"
        fi
      fi
    done < .env.example
  fi
fi

mkdir -p data/db data/backups

IMG_COUNT="$(docker compose images -q 2>/dev/null | grep -c . || true)"
if [ "$IMG_COUNT" -lt 2 ]; then
  NEEDS_BUILD=1
fi

CURRENT_HASH="$(find backend frontend docker-compose.yml -type f -not -path '*/node_modules/*' -not -path '*/dist/*' 2>/dev/null | sort | xargs stat -c '%n%s%Y' 2>/dev/null | sha256sum | awk '{print $1}' || true)"
LAST_HASH="$(cat data/.last_build_hash 2>/dev/null || true)"
if [ -n "$CURRENT_HASH" ] && [ "$CURRENT_HASH" != "$LAST_HASH" ]; then
  NEEDS_BUILD=1
fi

if [ "$NEEDS_BUILD" -eq 1 ]; then
  echo "[3/5] Construindo imagens e iniciando os containers..."
  docker compose up -d --build --remove-orphans
  if [ -n "$CURRENT_HASH" ]; then
    echo "$CURRENT_HASH" > data/.last_build_hash
  fi
else
  echo "[3/5] Imagens ja prontas. Iniciando containers sem recompilar..."
  docker compose up -d --remove-orphans
fi

echo "[4/5] Limpando imagens antigas e cache de build..."
docker image prune -f >/dev/null 2>&1 || true
docker builder prune -f >/dev/null 2>&1 || true

APP_PORT="$(grep -E '^APP_PORT=' .env | cut -d '=' -f2 | tr -d '\r' || echo '8080')"
APP_PORT="${APP_PORT:-8080}"

echo "[5/5] Aguardando sistema iniciar em http://localhost:${APP_PORT} ..."
for i in $(seq 1 20); do
  if command -v curl >/dev/null 2>&1 && curl -fsS "http://localhost:${APP_PORT}/api/health" >/dev/null 2>&1; then
    break
  fi
  sleep 2
done

docker compose ps
echo
echo "========================================================================"
echo "  Sistema iniciado e rodando com sucesso!"
echo "  Acesse: http://localhost:${APP_PORT}"
echo "========================================================================"

if [ "$OS_TYPE" = "Darwin" ]; then
  open "http://localhost:${APP_PORT}" >/dev/null 2>&1 || true
elif [ "$OS_TYPE" = "Linux" ] && command -v xdg-open >/dev/null 2>&1; then
  xdg-open "http://localhost:${APP_PORT}" >/dev/null 2>&1 || true
fi
