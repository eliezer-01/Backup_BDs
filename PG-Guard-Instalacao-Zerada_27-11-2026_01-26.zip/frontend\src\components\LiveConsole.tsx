import { useEffect, useRef, useState } from 'react';
import { Terminal, Trash2 } from 'lucide-react';
import { getWebSocketUrl } from '../services/api';
import { Button, Card } from './ui';

export interface WsLogEntry {
  executionId: string;
  type: 'stdout' | 'stderr' | 'status';
  message: string;
  status?: 'running' | 'success' | 'error';
  timestamp: string;
}

/**
 * Console em tempo real conectado via WebSocket (`/ws/logs`) para exibir
 * a saída `--verbose` de backups e restaurações enquanto executam.
 *
 * @example
 * <LiveConsole filterExecutionId={activeExecutionId} />
 */
export function LiveConsole({ filterExecutionId }: { filterExecutionId?: string | null }) {
  const [lines, setLines] = useState<WsLogEntry[]>([]);
  const [connected, setConnected] = useState(false);
  const bottomRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const ws = new WebSocket(getWebSocketUrl());

    ws.onopen = () => setConnected(true);
    ws.onclose = () => setConnected(false);
    ws.onmessage = (event) => {
      try {
        const parsed = JSON.parse(event.data) as WsLogEntry;
        setLines((prev) => [...prev.slice(-300), parsed]);
      } catch {
        // Ignora mensagens malformadas
      }
    };

    return () => ws.close();
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [lines]);

  const visibleLines = filterExecutionId
    ? lines.filter((l) => l.executionId === filterExecutionId)
    : lines;

  return (
    <Card className="overflow-hidden">
      <div className="flex items-center justify-between border-b border-border bg-muted/50 px-4 py-2.5">
        <div className="flex items-center gap-2 text-sm font-medium">
          <Terminal className="h-4 w-4 text-primary" />
          <span>Console em Tempo Real</span>
          <span
            className={`h-2 w-2 rounded-full ${connected ? 'bg-emerald-500' : 'bg-red-500'}`}
            title={connected ? 'Conectado via WebSocket' : 'Desconectado'}
          />
        </div>
        <Button variant="ghost" size="sm" onClick={() => setLines([])}>
          <Trash2 className="h-3.5 w-3.5" />
          Limpar
        </Button>
      </div>

      <div className="h-64 overflow-y-auto bg-slate-950 p-4 font-mono text-xs text-slate-200">
        {visibleLines.length === 0 ? (
          <div className="text-slate-500">
            Aguardando saída de execução (--verbose)...
          </div>
        ) : (
          visibleLines.map((line, idx) => (
            <div
              key={`${line.timestamp}-${idx}`}
              className={
                line.status === 'error'
                  ? 'text-red-400'
                  : line.status === 'success'
                    ? 'text-emerald-400 font-semibold'
                    : line.type === 'stderr'
                      ? 'text-sky-300'
                      : 'text-slate-200'
              }
            >
              <span className="mr-2 text-slate-500">[{line.timestamp.slice(11, 19)}]</span>
              {line.message}
            </div>
          ))
        )}
        <div ref={bottomRef} />
      </div>
    </Card>
  );
}
