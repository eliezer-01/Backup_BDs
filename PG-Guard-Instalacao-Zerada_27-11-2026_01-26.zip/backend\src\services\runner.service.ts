import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import type { BuiltCommand } from '../adapters/base.adapter';
import { getDatabase } from '../db/sqlite';

export interface WsClient {
  readyState: number;
  send(data: string): void;
  on(event: 'close', listener: () => void): void;
}

export interface LogBroadcastEvent {
  executionId: string;
  type: 'stdout' | 'stderr' | 'status';
  message: string;
  status?: 'running' | 'success' | 'error';
  timestamp: string;
}

/** Conjunto de clientes WebSocket conectados para receber logs em tempo real. */
const wsClients = new Set<WsClient>();

/**
 * Registra um cliente WebSocket para receber transmissões de logs em tempo real.
 *
 * @param socket Instância de conexão WebSocket do cliente.
 * @example
 * registerWsClient(socket);
 */
export function registerWsClient(socket: WsClient): void {
  wsClients.add(socket);
  socket.on('close', () => {
    wsClients.delete(socket);
  });
}

/**
 * Envia um evento de log ou mudança de status para todos os navegadores conectados.
 *
 * @param event Evento estruturado com ID da execução, tipo e mensagem.
 */
export function broadcastExecutionEvent(event: LogBroadcastEvent): void {
  const payload = JSON.stringify(event);
  for (const client of wsClients) {
    if (client.readyState === 1) {
      client.send(payload);
    }
  }
}

/**
 * Executa um comando curto e síncrono-assíncrono (ex: `psql SELECT 1` ou `pg_restore --list`)
 * sem usar shell, retornando `stdout` e `stderr` completos.
 *
 * @param cmd Comando validado com array de argumentos e variáveis isoladas.
 * @returns Código de saída e saídas capturadas.
 * @example
 * const res = await runQuickCommand(adapter.buildTestConnectionCommand(conn, senha));
 */
export function runQuickCommand(cmd: BuiltCommand): Promise<{
  exitCode: number;
  stdout: string;
  stderr: string;
}> {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd.binary, cmd.args, {
      shell: false,
      env: {
        ...process.env,
        ...cmd.envVars
      }
    });

    let stdout = '';
    let stderr = '';

    child.stdout.on('data', (chunk: Buffer) => {
      stdout += chunk.toString('utf8');
    });

    child.stderr.on('data', (chunk: Buffer) => {
      stderr += chunk.toString('utf8');
    });

    child.on('error', (err) => {
      reject(new Error(`Falha ao iniciar binário '${cmd.binary}': ${err.message}`));
    });

    child.on('close', (code) => {
      resolve({
        exitCode: code ?? 1,
        stdout: stdout.trim(),
        stderr: stderr.trim()
      });
    });
  });
}

/**
 * Calcula o tamanho total em bytes de um arquivo ou diretório de backup (`-Fd`).
 *
 * @param targetPath Caminho absoluto do arquivo ou pasta gerado.
 */
function calculatePathSize(targetPath: string): number {
  if (!fs.existsSync(targetPath)) return 0;
  const stat = fs.statSync(targetPath);
  if (!stat.isDirectory()) {
    return stat.size;
  }

  let total = 0;
  for (const entry of fs.readdirSync(targetPath)) {
    total += calculatePathSize(path.join(targetPath, entry));
  }
  return total;
}

/**
 * Executa uma operação longa de backup ou restauração em processo filho isolado (`shell: false`),
 * transmitindo linhas de `--verbose` em tempo real via WebSocket e atualizando o histórico no SQLite.
 *
 * @param executionId UUID do registro já criado na tabela `executions`.
 * @param cmd Comando estruturado (sem senha nos argumentos).
 * @param outputPathToMeasure Caminho do arquivo/diretório gerado (apenas para backups).
 * @example
 * void runTrackedExecution(execId, cmd, '/app/data/backups/oficial.backup');
 */
export function runTrackedExecution(
  executionId: string,
  cmd: BuiltCommand,
  outputPathToMeasure?: string
): Promise<{ success: boolean; exitCode: number; logOutput: string }> {
  return new Promise((resolve) => {
    const startedAtMs = Date.now();
    const db = getDatabase();
    const logLines: string[] = [];

    const appendLine = (type: 'stdout' | 'stderr', text: string) => {
      const cleaned = text.trimEnd();
      if (!cleaned) return;
      logLines.push(cleaned);
      broadcastExecutionEvent({
        executionId,
        type,
        message: cleaned,
        timestamp: new Date().toISOString()
      });
    };

    broadcastExecutionEvent({
      executionId,
      type: 'status',
      status: 'running',
      message: `Iniciando: ${cmd.preview}`,
      timestamp: new Date().toISOString()
    });

    const child = spawn(cmd.binary, cmd.args, {
      shell: false,
      env: {
        ...process.env,
        ...cmd.envVars
      }
    });

    child.stdout.on('data', (chunk: Buffer) => appendLine('stdout', chunk.toString('utf8')));
    child.stderr.on('data', (chunk: Buffer) => appendLine('stderr', chunk.toString('utf8')));

    child.on('error', (err) => {
      const durationMs = Date.now() - startedAtMs;
      const errMsg = `Erro ao executar '${cmd.binary}': ${err.message}`;
      logLines.push(errMsg);

      db.prepare(`
        UPDATE executions
        SET status = 'error', finished_at = datetime('now'), duration_ms = ?, error_message = ?, log_output = ?
        WHERE id = ?
      `).run(durationMs, errMsg, logLines.join('\n'), executionId);

      broadcastExecutionEvent({
        executionId,
        type: 'status',
        status: 'error',
        message: errMsg,
        timestamp: new Date().toISOString()
      });

      resolve({ success: false, exitCode: 1, logOutput: logLines.join('\n') });
    });

    child.on('close', (code) => {
      const exitCode = code ?? 1;
      const success = exitCode === 0;
      const durationMs = Date.now() - startedAtMs;
      const fullLog = logLines.join('\n');
      const fileSize = success && outputPathToMeasure ? calculatePathSize(outputPathToMeasure) : null;
      const errorMessage = success ? null : `Processo finalizado com código de saída ${exitCode}.`;

      db.prepare(`
        UPDATE executions
        SET status = ?, finished_at = datetime('now'), duration_ms = ?, file_size_bytes = COALESCE(?, file_size_bytes), error_message = ?, log_output = ?
        WHERE id = ?
      `).run(success ? 'success' : 'error', durationMs, fileSize, errorMessage, fullLog, executionId);

      broadcastExecutionEvent({
        executionId,
        type: 'status',
        status: success ? 'success' : 'error',
        message: success
          ? `Concluído com sucesso em ${(durationMs / 1000).toFixed(2)}s.`
          : `Falha na execução (código ${exitCode}).`,
        timestamp: new Date().toISOString()
      });

      resolve({ success, exitCode, logOutput: fullLog });
    });
  });
}
