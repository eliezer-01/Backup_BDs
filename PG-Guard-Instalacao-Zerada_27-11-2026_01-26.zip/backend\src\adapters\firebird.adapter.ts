import {
  formatCommandPreview,
  resolveRuntimeHost,
  type BuiltCommand,
  type ConnectionDescriptor,
  type DatabaseAdapter
} from './base.adapter';

/**
 * Adaptador modular para Firebird utilizando `gbak` e `isql-fb`.
 * A senha é repassada de forma isolada via variável de ambiente `ISC_PASSWORD`
 * e usuário via `ISC_USER`.
 *
 * @example
 * const adapter = new FirebirdAdapter();
 */
export class FirebirdAdapter implements DatabaseAdapter {
  readonly engine = 'firebird';

  private buildEnv(conn: ConnectionDescriptor, password: string): Record<string, string> {
    return {
      ISC_USER: conn.username,
      ISC_PASSWORD: password
    };
  }

  private remoteTarget(conn: ConnectionDescriptor, dbPath: string): string {
    return `${resolveRuntimeHost(conn.host)}/${conn.port}:${dbPath}`;
  }

  buildTestConnectionCommand(conn: ConnectionDescriptor, password: string): BuiltCommand {
    // gbak -b -v -m (metadata only) para /dev/null ou isql-fb -q
    const target = this.remoteTarget(conn, conn.defaultDatabase);
    const args = ['-q', '-z', target];
    return {
      binary: 'isql-fb',
      args,
      envVars: this.buildEnv(conn, password),
      preview: formatCommandPreview('isql-fb', args)
    };
  }

  buildListDatabasesCommand(conn: ConnectionDescriptor, password: string): BuiltCommand {
    const db = conn.defaultDatabase;
    return {
      binary: 'node',
      args: ['-e', `console.log(${JSON.stringify(db)})`],
      envVars: {},
      preview: `firebird://${resolveRuntimeHost(conn.host)}:${conn.port}/${db}`
    };
  }

  buildBackupCommand(
    conn: ConnectionDescriptor,
    password: string,
    rawParams: Record<string, unknown>,
    outputPath: string
  ): BuiltCommand {
    const dbPath = (rawParams.databaseName as string) || conn.defaultDatabase;
    const target = this.remoteTarget(conn, dbPath);
    const args = ['-b', '-v', target, outputPath];

    return {
      binary: 'gbak',
      args,
      envVars: this.buildEnv(conn, password),
      preview: formatCommandPreview('gbak', args)
    };
  }

  buildRestoreCommand(
    conn: ConnectionDescriptor,
    password: string,
    rawParams: Record<string, unknown>,
    inputPath: string
  ): BuiltCommand {
    const targetDb = (rawParams.targetDatabase as string) || conn.defaultDatabase;
    const target = this.remoteTarget(conn, targetDb);
    const modeFlag = rawParams.clean ? '-rep' : '-c';
    const args = [modeFlag, '-v', inputPath, target];

    return {
      binary: 'gbak',
      args,
      envVars: this.buildEnv(conn, password),
      preview: formatCommandPreview('gbak', args)
    };
  }
}
