import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { env } from '../config/env';
import { runPendingMigrations } from './migrations';

let dbInstance: DatabaseSync | null = null;

/**
 * Inicializa e retorna a instância singleton do banco SQLite local usando `node:sqlite` nativo.
 * Cria os diretórios necessários e aplica o schema inicial automaticamente.
 *
 * @returns Instância conectada do `DatabaseSync`.
 * @example
 * const db = getDatabase();
 * const rows = db.prepare('SELECT id, name FROM connections').all();
 */
export function getDatabase(): DatabaseSync {
  if (dbInstance) {
    return dbInstance;
  }

  const dbDir = path.dirname(env.DB_PATH);
  if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
  }

  if (!fs.existsSync(env.BACKUP_DIR)) {
    fs.mkdirSync(env.BACKUP_DIR, { recursive: true });
  }

  if (!fs.existsSync(env.CUSTOM_BACKUP_DIR)) {
    fs.mkdirSync(env.CUSTOM_BACKUP_DIR, { recursive: true });
  }

  dbInstance = new DatabaseSync(env.DB_PATH);
  dbInstance.exec('PRAGMA journal_mode = WAL;');
  dbInstance.exec('PRAGMA foreign_keys = ON;');

  const schemaPath = path.resolve(__dirname, 'schema.sql');
  const fallbackSchemaPath = path.resolve(process.cwd(), 'src/db/schema.sql');
  const resolvedSchema = fs.existsSync(schemaPath) ? schemaPath : fallbackSchemaPath;

  const schemaSql = fs.readFileSync(resolvedSchema, 'utf-8');
  dbInstance.exec(schemaSql);

  runPendingMigrations(dbInstance);

  return dbInstance;
}
