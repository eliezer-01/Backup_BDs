import { useEffect, useState, type ChangeEvent } from 'react';
import { BookmarkPlus, FileSearch, FolderOpen, Play, Trash2, Upload } from 'lucide-react';
import { apiRequest } from '../services/api';
import { Button, Card, Input, Select, Toggle } from '../components/ui';
import { LiveConsole } from '../components/LiveConsole';
import { FolderBrowserModal } from '../components/FolderBrowserModal';
import type { Connection } from './ConnectionsPage';

interface BackupFile {
  name: string;
  isDirectory: boolean;
  sizeBytes: number;
  modifiedAt: string;
}

interface RestoreProfile {
  id: string;
  name: string;
  source_folder: string;
  source_connection_id: string | null;
  source_database: string | null;
  use_latest_backup: number;
  file_name: string | null;
  target_connection_id: string;
  target_connection_name: string;
  target_database: string;
  create_database_if_not_exists: number;
  restore_tool: 'pg_restore' | 'psql';
  options_json: string;
}

/**
 * Módulo de Restauração (`pg_restore` e `psql`).
 * Permite escolher backup salvo ou fazer upload, restaurar em servidor local ou remoto,
 * criar o banco automaticamente e inspecionar o índice TOC (`--list`) antes de confirmar.
 *
 * @example
 * <RestorePage />
 */
export function RestorePage() {
  const [connections, setConnections] = useState<Connection[]>([]);
  const [files, setFiles] = useState<BackupFile[]>([]);
  const [sourceFolder, setSourceFolder] = useState('backups');
  const [availableFolders, setAvailableFolders] = useState<string[]>(['backups', 'custom']);
  const [targetDatabases, setTargetDatabases] = useState<string[]>([]);

  const [selectedFile, setSelectedFile] = useState('');
  const [targetConnectionId, setTargetConnectionId] = useState('');
  const [targetMode, setTargetMode] = useState<'new' | 'existing'>('new');
  const [targetDatabase, setTargetDatabase] = useState('');
  const [createDbIfNotExists, setCreateDbIfNotExists] = useState(true);

  const [restoreTool, setRestoreTool] = useState<'pg_restore' | 'psql'>('pg_restore');
  const [onErrorStop, setOnErrorStop] = useState(true);
  const [verbose, setVerbose] = useState(true);
  const [clean, setClean] = useState(true);
  const [noAcl, setNoAcl] = useState(false);
  const [noOwner, setNoOwner] = useState(true);
  const [createFlag, setCreateFlag] = useState(false);
  const [section, setSection] = useState<'all' | 'pre-data' | 'data' | 'post-data'>('all');

  const [tocOutput, setTocOutput] = useState('');
  const [activeExecId, setActiveExecId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState('');
  const [showFolderBrowser, setShowFolderBrowser] = useState(false);
  const [restoreProfiles, setRestoreProfiles] = useState<RestoreProfile[]>([]);
  const [profileName, setProfileName] = useState('');
  const [useLatestBackup, setUseLatestBackup] = useState(false);
  const [sourceConnectionId, setSourceConnectionId] = useState('');
  const [sourceDatabases, setSourceDatabases] = useState<string[]>([]);
  const [sourceDatabase, setSourceDatabase] = useState('');

  const targetConn = connections.find((c) => c.id === targetConnectionId);
  const targetEngine = targetConn?.engine || 'postgresql';

  async function loadInitialData(folderToLoad = sourceFolder) {
    const [connRes, filesRes, foldersRes, rpRes] = await Promise.all([
      apiRequest<{ connections: Connection[] }>('/api/connections'),
      apiRequest<{ files: BackupFile[] }>(`/api/restores/files?folder=${encodeURIComponent(folderToLoad)}`),
      apiRequest<{ folders: string[] }>('/api/backups/folders').catch(() => ({ folders: ['backups', 'custom'] })),
      apiRequest<{ profiles: RestoreProfile[] }>('/api/restores/profiles').catch(() => ({ profiles: [] }))
    ]);
    setConnections(connRes.connections);
    setFiles(filesRes.files);
    setAvailableFolders(foldersRes.folders);
    setRestoreProfiles(rpRes.profiles);
    if (connRes.connections.length > 0 && !targetConnectionId) setTargetConnectionId(connRes.connections[0].id);
    if (connRes.connections.length > 0 && !sourceConnectionId) setSourceConnectionId(connRes.connections[0].id);
    if (filesRes.files.length > 0) {
      setSelectedFile(filesRes.files[0].name);
    } else {
      setSelectedFile('');
    }
  }

  useEffect(() => {
    if (!sourceConnectionId || !useLatestBackup) return;
    void apiRequest<{ databases: string[] }>(`/api/connections/${sourceConnectionId}/databases`)
      .then((res) => {
        setSourceDatabases(res.databases);
        if (res.databases.length > 0 && !res.databases.includes(sourceDatabase)) {
          setSourceDatabase(res.databases[0]);
        }
      })
      .catch(() => setSourceDatabases([]));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sourceConnectionId, useLatestBackup]);

  async function handleSaveRestoreProfile() {
    if (!profileName.trim() || !targetConnectionId || !targetDatabase) return;
    setFeedback('');
    try {
      await apiRequest('/api/restores/profiles', {
        method: 'POST',
        body: JSON.stringify({
          name: profileName.trim(),
          sourceFolder,
          useLatestBackup,
          sourceConnectionId: useLatestBackup ? sourceConnectionId : null,
          sourceDatabase: useLatestBackup ? sourceDatabase : null,
          fileName: useLatestBackup ? null : (selectedFile || null),
          targetConnectionId,
          targetDatabase,
          createDatabaseIfNotExists: createDbIfNotExists,
          restoreTool,
          options: { onErrorStop, verbose, clean, noAcl, noOwner, createFlag, section }
        })
      });
      setProfileName('');
      await loadInitialData(sourceFolder);
      setFeedback('Perfil de restauração salvo com sucesso!');
    } catch (err) {
      setFeedback((err as Error).message);
    }
  }

  async function handleRunRestoreProfile(id: string) {
    setFeedback('');
    try {
      const res = await apiRequest<{ executionId: string }>(`/api/restores/profiles/${id}/execute`, {
        method: 'POST'
      });
      setActiveExecId(res.executionId);
      setFeedback('Restauração iniciada pelo perfil! Acompanhe no console abaixo.');
    } catch (err) {
      setFeedback((err as Error).message);
    }
  }

  function applyRestoreProfile(rp: RestoreProfile) {
    setSourceFolder(rp.source_folder || 'backups');
    setUseLatestBackup(rp.use_latest_backup === 1);
    if (rp.source_connection_id) setSourceConnectionId(rp.source_connection_id);
    if (rp.source_database) setSourceDatabase(rp.source_database);
    if (rp.file_name) setSelectedFile(rp.file_name);
    setTargetConnectionId(rp.target_connection_id);
    setTargetDatabase(rp.target_database);
    setCreateDbIfNotExists(rp.create_database_if_not_exists === 1);
    setTargetMode(rp.create_database_if_not_exists === 1 ? 'new' : 'existing');
    setRestoreTool(rp.restore_tool);
    try {
      const o = JSON.parse(rp.options_json) as Record<string, unknown>;
      if (typeof o.onErrorStop === 'boolean') setOnErrorStop(o.onErrorStop);
      if (typeof o.verbose === 'boolean') setVerbose(o.verbose);
      if (typeof o.clean === 'boolean') setClean(o.clean);
      if (typeof o.noAcl === 'boolean') setNoAcl(o.noAcl);
      if (typeof o.noOwner === 'boolean') setNoOwner(o.noOwner);
      if (typeof o.createFlag === 'boolean') setCreateFlag(o.createFlag);
      if (typeof o.section === 'string') setSection(o.section as typeof section);
    } catch {
      // Ignora JSON inválido
    }
    setFeedback(`Perfil "${rp.name}" carregado!`);
  }

  useEffect(() => {
    void loadInitialData(sourceFolder);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sourceFolder]);

  async function loadTargetDatabases(connId: string) {
    if (!connId) return;
    try {
      const res = await apiRequest<{ databases: string[] }>(`/api/connections/${connId}/databases`);
      setTargetDatabases(res.databases);
      if (targetMode === 'existing' && res.databases.length > 0) {
        setTargetDatabase(res.databases[0]);
      }
    } catch {
      setTargetDatabases([]);
    }
  }

  useEffect(() => {
    void loadTargetDatabases(targetConnectionId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [targetConnectionId]);

  useEffect(() => {
    if (selectedFile.toLowerCase().endsWith('.sql')) {
      setRestoreTool('psql');
    } else if (selectedFile) {
      setRestoreTool('pg_restore');
    }
  }, [selectedFile]);

  async function handleUpload(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setFeedback('Enviando arquivo...');
    try {
      const formData = new FormData();
      formData.append('file', file);
      const res = await apiRequest<{ fileName: string }>(
        `/api/restores/upload?folder=${encodeURIComponent(sourceFolder)}`,
        {
          method: 'POST',
          body: formData
        }
      );
      await loadInitialData();
      setSelectedFile(res.fileName);
      setFeedback(`Arquivo '${res.fileName}' enviado com sucesso.`);
    } catch (err) {
      setFeedback((err as Error).message);
    }
  }

  async function handleInspect() {
    if (!selectedFile) return;
    setTocOutput('Inspecionando arquivo...');
    try {
      const res = await apiRequest<{ totalItems: number; toc: string }>('/api/restores/inspect', {
        method: 'POST',
        body: JSON.stringify({ fileName: selectedFile, sourceFolder })
      });
      setTocOutput(res.toc || 'Nenhum item encontrado.');
    } catch (err) {
      setTocOutput(`Erro: ${(err as Error).message}`);
    }
  }

  async function handleExecuteRestore() {
    if (!selectedFile || !targetConnectionId || !targetDatabase) return;
    setFeedback('');
    try {
      const res = await apiRequest<{ executionId: string }>('/api/restores/execute', {
        method: 'POST',
        body: JSON.stringify({
          targetConnectionId,
          targetDatabase,
          createDatabaseIfNotExists: createDbIfNotExists,
          fileName: selectedFile,
          sourceFolder,
          restoreTool,
          onErrorStop,
          verbose,
          clean,
          noAcl,
          noOwner,
          createFlag,
          section
        })
      });
      setActiveExecId(res.executionId);
      setFeedback('Restauração iniciada! Acompanhe o console em tempo real abaixo.');
    } catch (err) {
      setFeedback((err as Error).message);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Módulo de Restauração</h2>
        <p className="text-sm text-muted-foreground">
          Restaure backups salvos ou enviados do seu computador em qualquer servidor (ex: copiar Oficial para Teste).
        </p>
      </div>

      <Card className="space-y-5 p-5">
        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">
              Arquivo de Backup no Servidor
            </label>
            <div className="flex gap-2">
              <Select value={selectedFile} onChange={(e) => setSelectedFile(e.target.value)}>
                {files.length === 0 && <option value="">Nenhum arquivo disponível</option>}
                {files.map((f) => (
                  <option key={f.name} value={f.name}>
                    {f.name} ({(f.sizeBytes / 1024 / 1024).toFixed(2)} MB)
                  </option>
                ))}
              </Select>
              <Button variant="outline" onClick={() => void handleInspect()} disabled={!selectedFile || restoreTool === 'psql'}>
                <FileSearch className="h-4 w-4" />
                Inspecionar (--list)
              </Button>
            </div>
          </div>

          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">
              Ou Enviar Arquivo (.sql, .tar, .backup, .gz, .bak, .dmp, .json, .fbk)
            </label>
            <label className="flex cursor-pointer items-center justify-center gap-2 rounded-lg border border-dashed border-border px-4 py-2 text-sm hover:bg-muted/50">
              <Upload className="h-4 w-4 text-primary" />
              <span>Selecionar arquivo do computador</span>
              <input type="file" accept=".sql,.tar,.backup,.dump,.gz,.archive,.bak,.dmp,.json,.fbk" className="hidden" onChange={(e) => void handleUpload(e)} />
            </label>
          </div>
        </div>

        <div>
          <label className="mb-1 block text-xs font-medium text-muted-foreground">Pasta de Origem dos Arquivos</label>
          <div className="flex gap-2">
            <Input
              list="restore-folders-list"
              value={sourceFolder}
              onChange={(e) => setSourceFolder(e.target.value)}
            />
            <Button type="button" variant="outline" onClick={() => setShowFolderBrowser(true)}>
              <FolderOpen className="h-4 w-4" />
              Browser
            </Button>
          </div>
          <datalist id="restore-folders-list">
            {availableFolders.map((f) => (
              <option key={f} value={f} />
            ))}
          </datalist>
        </div>

        <FolderBrowserModal
          open={showFolderBrowser}
          initialPath={sourceFolder}
          onClose={() => setShowFolderBrowser(false)}
          onSelect={(folder) => setSourceFolder(folder)}
        />

        <Toggle
          checked={useLatestBackup}
          onChange={setUseLatestBackup}
          label="Modo Automático por Banco (sempre pegar o último backup pela data/hora)"
          hint="Ideal para salvar um Perfil de Restauração: selecione apenas o banco existente e o sistema busca o backup mais recente"
        />

        {useLatestBackup && (
          <div className="grid gap-4 rounded-lg border border-border bg-muted/20 p-3 md:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Conexão de Origem do Backup</label>
              <Select value={sourceConnectionId} onChange={(e) => setSourceConnectionId(e.target.value)}>
                {connections.map((c) => (
                  <option key={c.id} value={c.id}>{c.name} [{c.engine}]</option>
                ))}
              </Select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">
                Banco Existente (pega o último backup automaticamente)
              </label>
              <Select value={sourceDatabase} onChange={(e) => setSourceDatabase(e.target.value)}>
                {sourceDatabases.length === 0 && <option value="">Nenhum banco listado</option>}
                {sourceDatabases.map((db) => (
                  <option key={db} value={db}>{db}</option>
                ))}
              </Select>
            </div>
          </div>
        )}

        <div className="grid gap-4 md:grid-cols-3">
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">Servidor de Destino</label>
            <Select value={targetConnectionId} onChange={(e) => setTargetConnectionId(e.target.value)}>
              {connections.map((c) => (
                <option key={c.id} value={c.id}>{c.name} [{c.engine}] ({c.host})</option>
              ))}
            </Select>
          </div>

          {targetEngine !== 'rabbitmq' && (
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Modo de Destino</label>
              <Select
                value={targetMode}
                onChange={(e) => {
                  const mode = e.target.value as 'new' | 'existing';
                  setTargetMode(mode);
                  if (mode === 'new') {
                    setCreateDbIfNotExists(true);
                    setTargetDatabase('');
                  } else {
                    setCreateDbIfNotExists(false);
                    if (targetDatabases.length > 0) {
                      setTargetDatabase(targetDatabases[0]);
                    }
                  }
                }}
              >
                <option value="new">Criar novo banco (preserva o original)</option>
                <option value="existing">Sobrescrever banco existente</option>
              </Select>
            </div>
          )}

          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">
              {targetEngine === 'postgresql' ? 'Ferramenta' : 'Motor de Destino'}
            </label>
            {targetEngine === 'postgresql' ? (
              <Select value={restoreTool} onChange={(e) => setRestoreTool(e.target.value as 'pg_restore' | 'psql')}>
                <option value="pg_restore">pg_restore (.backup / .tar / dir)</option>
                <option value="psql">psql (.sql / globais)</option>
              </Select>
            ) : (
              <div className="rounded-lg border border-border bg-muted/50 px-3 py-2 text-sm font-medium uppercase">
                {targetEngine}
              </div>
            )}
          </div>
        </div>

        {targetMode === 'new' ? (
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">
                Nome do Novo Banco (será criado automaticamente se não existir)
              </label>
              <Input
                value={targetDatabase}
                onChange={(e) => setTargetDatabase(e.target.value)}
                placeholder="Ex: gestao_projetos_db_teste"
              />
            </div>
            <div className="flex items-end">
              <Toggle
                checked={createDbIfNotExists}
                onChange={setCreateDbIfNotExists}
                label="Criar banco automaticamente antes de restaurar"
                hint="Ativado por padrão para novos bancos"
              />
            </div>
          </div>
        ) : (
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">
              Selecione o Banco Existente no Servidor para Sobrescrever
            </label>
            <div className="flex gap-2">
              <Select value={targetDatabase} onChange={(e) => setTargetDatabase(e.target.value)}>
                {targetDatabases.length === 0 && <option value="">Nenhum banco encontrado</option>}
                {targetDatabases.map((db) => (
                  <option key={db} value={db}>{db}</option>
                ))}
              </Select>
              <Button variant="outline" onClick={() => void loadTargetDatabases(targetConnectionId)}>
                Atualizar Lista
              </Button>
            </div>
          </div>
        )}

        {targetEngine === 'postgresql' && (restoreTool === 'psql' ? (
          <Toggle
            checked={onErrorStop}
            onChange={setOnErrorStop}
            label="Interromper no primeiro erro (--set ON_ERROR_STOP=on)"
            hint="Recomendado para evitar restaurações parciais em arquivos SQL"
          />
        ) : (
          <div className="space-y-4">
            <div className="grid gap-3 md:grid-cols-3">
              <Toggle checked={verbose} onChange={setVerbose} label="--verbose" hint="Log detalhado em tempo real" />
              <Toggle checked={clean} onChange={setClean} label="--clean" hint="Recria objetos existentes no destino" />
              <Toggle checked={noOwner} onChange={setNoOwner} label="--no-owner" hint="Ignora dono original das tabelas" />
              <Toggle checked={noAcl} onChange={setNoAcl} label="--no-acl" hint="Ignora permissões GRANT/REVOKE" />
              <Toggle checked={createFlag} onChange={setCreateFlag} label="--create" hint="Usa o CREATE DATABASE embutido no dump" />
              <div>
                <label className="mb-1 block text-xs font-medium text-muted-foreground">Filtro de Seção (--section)</label>
                <Select value={section} onChange={(e) => setSection(e.target.value as typeof section)}>
                  <option value="all">Tudo (Padrão)</option>
                  <option value="pre-data">pre-data (Schemas e Tabelas)</option>
                  <option value="data">data (Apenas Dados)</option>
                  <option value="post-data">post-data (Índices e Constraints)</option>
                </Select>
              </div>
            </div>
          </div>
        ))}

        {(targetEngine === 'mongodb' || targetEngine === 'sqlserver') && (
          <Toggle
            checked={clean}
            onChange={setClean}
            label={targetEngine === 'mongodb' ? 'Sobrescrever coleções existentes (--drop)' : 'Substituir banco existente (WITH REPLACE)'}
            hint="Remove ou substitui dados existentes no destino antes de restaurar"
          />
        )}

        {tocOutput && (
          <div className="rounded-lg border border-border bg-slate-950 p-3">
            <div className="mb-1 text-xs font-semibold text-slate-400">Índice do Backup (pg_restore --list):</div>
            <pre className="max-h-48 overflow-auto font-mono text-xs text-sky-300">{tocOutput}</pre>
          </div>
        )}

        {feedback && <div className="rounded-lg bg-primary/10 p-3 text-xs text-primary">{feedback}</div>}

        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border pt-4">
          <div className="flex items-center gap-2">
            <Input
              className="w-60"
              value={profileName}
              onChange={(e) => setProfileName(e.target.value)}
              placeholder="Nome do perfil de restauração"
            />
            <Button
              variant="outline"
              onClick={() => void handleSaveRestoreProfile()}
              disabled={!profileName.trim() || !targetConnectionId || !targetDatabase}
            >
              <BookmarkPlus className="h-4 w-4" />
              Salvar Perfil
            </Button>
          </div>

          <Button onClick={() => void handleExecuteRestore()} disabled={!selectedFile || !targetConnectionId || (targetEngine !== 'rabbitmq' && !targetDatabase)}>
            <Play className="h-4 w-4" />
            Iniciar Restauração
          </Button>
        </div>
      </Card>

      {restoreProfiles.length > 0 && (
        <Card className="p-4">
          <div className="mb-3 text-sm font-semibold">Perfis de Restauração Salvos</div>
          <div className="flex flex-wrap gap-2">
            {restoreProfiles.map((rp) => (
              <div key={rp.id} className="flex items-center gap-1.5 rounded-lg border border-border bg-muted/40 px-3 py-1.5 text-xs">
                <button
                  type="button"
                  onClick={() => applyRestoreProfile(rp)}
                  className="font-medium hover:text-primary"
                  title="Clique para carregar este perfil"
                >
                  {rp.name} ({rp.use_latest_backup === 1 ? `Último de ${rp.source_database}` : rp.file_name} → {rp.target_database})
                </button>
                <button
                  type="button"
                  onClick={() => void handleRunRestoreProfile(rp.id)}
                  className="ml-1 text-emerald-600 hover:opacity-80 dark:text-emerald-400"
                  title="Executar restauração deste perfil agora"
                >
                  <Play className="h-3.5 w-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => void apiRequest(`/api/restores/profiles/${rp.id}`, { method: 'DELETE' }).then(() => loadInitialData(sourceFolder))}
                  className="ml-1 text-destructive hover:opacity-80"
                  title="Excluir perfil"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        </Card>
      )}

      <LiveConsole filterExecutionId={activeExecId} />
    </div>
  );
}
