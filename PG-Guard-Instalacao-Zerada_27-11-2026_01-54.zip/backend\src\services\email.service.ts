import nodemailer from 'nodemailer';
import { env } from '../config/env';
import { getDatabase } from '../db/sqlite';
import { decryptSecret } from '../security/crypto';

export interface EmailBodyFields {
  perfil: boolean;
  conexao: boolean;
  banco: boolean;
  data_hora: boolean;
  duracao: boolean;
  tamanho: boolean;
  arquivo: boolean;
  erro: boolean;
}

export const DEFAULT_BODY_FIELDS: EmailBodyFields = {
  perfil: true,
  conexao: true,
  banco: true,
  data_hora: true,
  duracao: true,
  tamanho: true,
  arquivo: true,
  erro: true
};

export interface JobEmailFields {
  etapa: boolean;
  alvo: boolean;
  status: boolean;
  data_hora: boolean;
  duracao: boolean;
  detalhes: boolean;
}

export interface JobEmailConfig {
  subjectSuccess: string;
  subjectError: string;
  customMessage: string;
  fields: JobEmailFields;
}

export const DEFAULT_JOB_EMAIL_CONFIG: JobEmailConfig = {
  subjectSuccess: '[PG Guard] ✅ SUCESSO - {{perfil}} ({{banco}})',
  subjectError: '[PG Guard] ❌ FALHA - {{perfil}} ({{banco}})',
  customMessage: '',
  fields: {
    etapa: true,
    alvo: true,
    status: true,
    data_hora: true,
    duracao: true,
    detalhes: true
  }
};

export interface SmtpSettingsRow {
  id: string;
  host: string;
  port: number;
  secure: number;
  username: string;
  password_encrypted: string;
  password_iv: string;
  password_tag: string;
  from_email: string;
  from_name: string;
  allow_self_signed: number;
  subject_success: string;
  subject_error: string;
  custom_message: string | null;
  body_fields_json: string;
  job_email_config_json: string | null;
}

export interface BackupAlertPayload {
  to: string;
  profileName: string;
  connectionName: string;
  engine: string;
  databaseName: string;
  success: boolean;
  durationMs: number;
  filePath?: string;
  fileSizeBytes?: number | null;
  errorMessage?: string | null;
}

export function parseJobEmailConfig(raw?: string | null): JobEmailConfig {
  if (!raw) return DEFAULT_JOB_EMAIL_CONFIG;
  try {
    const parsed = JSON.parse(raw) as Partial<JobEmailConfig>;
    return {
      subjectSuccess: parsed.subjectSuccess || DEFAULT_JOB_EMAIL_CONFIG.subjectSuccess,
      subjectError: parsed.subjectError || DEFAULT_JOB_EMAIL_CONFIG.subjectError,
      customMessage: parsed.customMessage ?? '',
      fields: { ...DEFAULT_JOB_EMAIL_CONFIG.fields, ...(parsed.fields || {}) }
    };
  } catch {
    return DEFAULT_JOB_EMAIL_CONFIG;
  }
}

function parseBodyFields(raw?: string): EmailBodyFields {
  if (!raw) return DEFAULT_BODY_FIELDS;
  try {
    return { ...DEFAULT_BODY_FIELDS, ...(JSON.parse(raw) as Partial<EmailBodyFields>) };
  } catch {
    return DEFAULT_BODY_FIELDS;
  }
}

interface TemplateVars {
  perfil: string;
  banco: string;
  conexao: string;
  status: string;
  data: string;
  data_hora?: string;
  duracao?: string;
  tamanho?: string;
  arquivo?: string;
  erro?: string;
}

/**
 * Substitui variáveis dinâmicas (`{{perfil}}`, `{{banco}}`, `{{conexao}}`, `{{status}}`,
 * `{{data}}`, `{{data_hora}}`, `{{duracao}}`, `{{tamanho}}`, `{{arquivo}}`, `{{erro}}`)
 * tanto no assunto quanto na mensagem fixa manual do corpo do e-mail.
 */
function renderTemplate(template: string, vars: TemplateVars): string {
  return template
    .replace(/\{\{perfil\}\}/gi, vars.perfil)
    .replace(/\{\{banco\}\}/gi, vars.banco)
    .replace(/\{\{conexao\}\}/gi, vars.conexao)
    .replace(/\{\{status\}\}/gi, vars.status)
    .replace(/\{\{data_hora\}\}/gi, vars.data_hora ?? vars.data)
    .replace(/\{\{data\}\}/gi, vars.data)
    .replace(/\{\{duracao\}\}/gi, vars.duracao ?? '-')
    .replace(/\{\{tamanho\}\}/gi, vars.tamanho ?? '-')
    .replace(/\{\{arquivo\}\}/gi, vars.arquivo ?? '-')
    .replace(/\{\{erro\}\}/gi, vars.erro ?? '');
}

/**
 * Cria um transporter Nodemailer a partir das configurações SMTP criptografadas no SQLite.
 */
function buildTransporter(): {
  transporter: nodemailer.Transporter;
  from: string;
  cfg: SmtpSettingsRow;
  bodyFields: EmailBodyFields;
} | null {
  const db = getDatabase();
  const cfg = db
    .prepare("SELECT * FROM smtp_settings WHERE id = 'default'")
    .get() as SmtpSettingsRow | undefined;

  if (!cfg) return null;

  const password = decryptSecret({
    encrypted: cfg.password_encrypted,
    iv: cfg.password_iv,
    tag: cfg.password_tag
  });

  const transporter = nodemailer.createTransport({
    host: cfg.host,
    port: cfg.port,
    secure: cfg.secure === 1,
    auth: {
      user: cfg.username,
      pass: password
    },
    tls: cfg.allow_self_signed === 1 ? { rejectUnauthorized: false } : undefined
  });

  return {
    transporter,
    from: `"${cfg.from_name}" <${cfg.from_email}>`,
    cfg,
    bodyFields: parseBodyFields(cfg.body_fields_json)
  };
}

/**
 * Envia um e-mail de teste para validar a configuração SMTP e o template atual.
 */
export async function sendTestAlertEmail(
  to: string,
  alertType: 'individual' | 'job' = 'individual'
): Promise<void> {
  if (alertType === 'job') {
    await sendJobAlertEmail({
      to,
      jobName: 'Rotina Teste',
      allSuccess: true,
      totalDurationMs: 4250,
      steps: [
        { order: 1, type: 'backup', label: 'Oficial (teste/Banco_Oficial)', success: true, durationMs: 2500, detail: 'Arquivo: Banco_Oficial.backup' },
        { order: 2, type: 'restore', label: 'Teste → Banco_Teste', success: true, durationMs: 1750, detail: 'Restaurado de: Banco_Oficial.backup' }
      ]
    });
    return;
  }

  const built = buildTransporter();
  if (!built) {
    throw new Error('Configuração SMTP ainda não foi salva.');
  }

  await sendBackupAlertEmail({
    to,
    profileName: 'Teste SMTP',
    connectionName: 'Servidor Local',
    engine: 'postgresql',
    databaseName: 'postgres',
    success: true,
    durationMs: 1200,
    filePath: '/app/data/backups/teste.backup',
    fileSizeBytes: 1250000
  });
}

/**
 * Envia o alerta personalizado (assunto, mensagem fixa e apenas as variáveis marcadas na tela).
 */
export async function sendBackupAlertEmail(payload: BackupAlertPayload): Promise<void> {
  const built = buildTransporter();
  if (!built) return;

  const localNow = new Date().toLocaleString('pt-BR', { timeZone: env.TZ });
  const localDate = new Date().toLocaleDateString('pt-BR', { timeZone: env.TZ });
  const template = payload.success
    ? built.cfg.subject_success || '[PG Guard] ✅ SUCESSO - {{perfil}} ({{banco}})'
    : built.cfg.subject_error || '[PG Guard] ❌ FALHA - {{perfil}} ({{banco}})';

  const sizeMb =
    payload.fileSizeBytes !== undefined && payload.fileSizeBytes !== null
      ? `${(payload.fileSizeBytes / 1024 / 1024).toFixed(2)} MB`
      : '-';
  const durationSec = `${(payload.durationMs / 1000).toFixed(2)}s`;

  const tplVars: TemplateVars = {
    perfil: payload.profileName,
    banco: payload.databaseName,
    conexao: `${payload.connectionName} (${payload.engine})`,
    status: payload.success ? 'SUCESSO' : 'FALHA',
    data: localDate,
    data_hora: localNow,
    duracao: durationSec,
    tamanho: sizeMb,
    arquivo: payload.filePath || '-',
    erro: payload.errorMessage || ''
  };

  const subject = renderTemplate(template, tplVars);
  const f = built.bodyFields;

  const rows: Array<[string, string, boolean]> = [
    ['Perfil', payload.profileName, f.perfil],
    ['Conexão / Motor', `${payload.connectionName} (${payload.engine})`, f.conexao],
    ['Banco de Dados', payload.databaseName, f.banco],
    ['Data / Hora', localNow, f.data_hora],
    ['Duração', durationSec, f.duracao],
    ['Tamanho', sizeMb, f.tamanho],
    ['Arquivo', payload.filePath || '-', f.arquivo]
  ];

  const rowsHtml = rows
    .filter(([, , enabled]) => enabled)
    .map(
      ([label, val]) =>
        `<tr><td style="padding: 6px; border-bottom: 1px solid #e2e8f0;"><strong>${label}:</strong></td><td style="padding: 6px; border-bottom: 1px solid #e2e8f0;">${val}</td></tr>`
    )
    .join('');

  const renderedCustom = built.cfg.custom_message
    ? renderTemplate(built.cfg.custom_message, tplVars).replace(/\r?\n/g, '<br/>')
    : '';
  const customBlock = renderedCustom
    ? `<div style="margin-bottom: 12px; padding: 10px; background: #f8fafc; border-left: 4px solid #3b82f6; font-size: 13px;">${renderedCustom}</div>`
    : '';

  const html = `
    <div style="font-family: Arial, sans-serif; color: #1e293b; max-width: 600px;">
      <h2 style="color: ${payload.success ? '#059669' : '#dc2626'};">
        ${payload.success ? 'Operação Concluída com Sucesso' : 'Falha na Execução'}
      </h2>
      ${customBlock}
      ${rowsHtml ? `<table style="width: 100%; border-collapse: collapse; font-size: 14px;">${rowsHtml}</table>` : ''}
      ${
        f.erro && payload.errorMessage
          ? `<div style="margin-top: 12px; padding: 10px; background: #fef2f2; color: #991b1b; border-radius: 6px;"><strong>Erro:</strong> ${payload.errorMessage}</div>`
          : ''
      }
    </div>
  `;

  await built.transporter.sendMail({
    from: built.from,
    to: payload.to,
    subject,
    html
  });
}

export interface JobStepReport {
  order: number;
  type: 'backup' | 'restore';
  label: string;
  success: boolean;
  durationMs: number;
  detail: string;
}

/**
 * Envia um único e-mail consolidado ao término de um Job sequencial,
 * respeitando assunto personalizado, mensagem fixa e campos selecionados.
 */
export async function sendJobAlertEmail(payload: {
  to: string;
  jobName: string;
  allSuccess: boolean;
  totalDurationMs: number;
  steps: JobStepReport[];
}): Promise<void> {
  const built = buildTransporter();
  if (!built) return;

  const jobCfg = parseJobEmailConfig(built.cfg.job_email_config_json);
  const passedCount = payload.steps.filter((s) => s.success).length;
  const localNow = new Date().toLocaleString('pt-BR', { timeZone: env.TZ });
  const localDate = new Date().toLocaleDateString('pt-BR', { timeZone: env.TZ });
  const template = payload.allSuccess ? jobCfg.subjectSuccess : jobCfg.subjectError;

  const tplVars: TemplateVars = {
    perfil: `Job: ${payload.jobName}`,
    banco: `${passedCount}/${payload.steps.length} etapas`,
    conexao: 'Pipeline',
    status: payload.allSuccess ? 'SUCESSO' : 'FALHA',
    data: localDate,
    data_hora: localNow,
    duracao: `${(payload.totalDurationMs / 1000).toFixed(2)}s`,
    tamanho: '-',
    arquivo: `${passedCount}/${payload.steps.length} etapas concluídas`,
    erro: payload.steps.filter((s) => !s.success).map((s) => s.detail).join(' | ')
  };

  const subject = renderTemplate(template, tplVars);
  const f = jobCfg.fields;
  const renderedCustom = jobCfg.customMessage
    ? renderTemplate(jobCfg.customMessage, tplVars).replace(/\r?\n/g, '<br/>')
    : '';
  const customBlock = renderedCustom
    ? `<div style="margin-bottom: 12px; padding: 10px; background: #f8fafc; border-left: 4px solid #3b82f6; font-size: 13px;">${renderedCustom}</div>`
    : '';

  const showAnyCol = f.etapa || f.alvo || f.status || f.duracao || f.detalhes;
  const rowsHtml = showAnyCol
    ? payload.steps
        .map(
          (s) => `
      <tr>
        ${f.etapa ? `<td style="padding: 6px; border-bottom: 1px solid #e2e8f0;">#${s.order} (${s.type === 'backup' ? 'Backup' : 'Restauração'})</td>` : ''}
        ${f.alvo ? `<td style="padding: 6px; border-bottom: 1px solid #e2e8f0;">${s.label}</td>` : ''}
        ${f.status ? `<td style="padding: 6px; border-bottom: 1px solid #e2e8f0; color: ${s.success ? '#059669' : '#dc2626'}; font-weight: bold;">${s.success ? 'Sucesso' : 'Falha'}</td>` : ''}
        ${f.duracao ? `<td style="padding: 6px; border-bottom: 1px solid #e2e8f0;">${(s.durationMs / 1000).toFixed(2)}s</td>` : ''}
        ${f.detalhes ? `<td style="padding: 6px; border-bottom: 1px solid #e2e8f0; font-size: 12px;">${s.detail}</td>` : ''}
      </tr>
    `
        )
        .join('')
    : '';

  const html = `
    <div style="font-family: Arial, sans-serif; color: #1e293b; max-width: 760px;">
      <h2 style="color: ${payload.allSuccess ? '#059669' : '#dc2626'};">
        ${payload.allSuccess ? 'Job Concluído com Sucesso' : 'Job Finalizado com Falha(s)'}: ${payload.jobName}
      </h2>
      ${customBlock}
      ${
        f.data_hora || f.duracao
          ? `<p style="font-size: 13px; color: #475569;">
              ${f.data_hora ? `Executado em: <strong>${localNow}</strong> ` : ''}
              ${f.duracao ? `• Duração total: <strong>${(payload.totalDurationMs / 1000).toFixed(2)}s</strong>` : ''}
            </p>`
          : ''
      }
      ${
        showAnyCol
          ? `<table style="width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 10px;">
              <thead>
                <tr style="background: #f1f5f9; text-align: left;">
                  ${f.etapa ? '<th style="padding: 8px;">Etapa</th>' : ''}
                  ${f.alvo ? '<th style="padding: 8px;">Alvo</th>' : ''}
                  ${f.status ? '<th style="padding: 8px;">Status</th>' : ''}
                  ${f.duracao ? '<th style="padding: 8px;">Duração</th>' : ''}
                  ${f.detalhes ? '<th style="padding: 8px;">Detalhes</th>' : ''}
                </tr>
              </thead>
              <tbody>${rowsHtml}</tbody>
            </table>`
          : ''
      }
    </div>
  `;

  await built.transporter.sendMail({
    from: built.from,
    to: payload.to,
    subject,
    html
  });
}
