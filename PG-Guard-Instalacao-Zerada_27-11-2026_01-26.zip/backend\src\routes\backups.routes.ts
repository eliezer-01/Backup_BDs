import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { env } from '../config/env';
import { getDatabase } from '../db/sqlite';
import { authenticateRequest, requirePermission } from '../security/auth';
import { backupOptionsSchema, executeBackupSchema, resolveSafeFolderDir } from '../security/sanitizer';
import { getDatabaseAdapter } from '../adapters/registry';
import { getDecryptedConnection } from '../services/connections.service';
import { runTrackedExecution } from '../services/runner.service';
import { createSmbDirectory, listSmbDirectory, uploadFileToSmb } from '../services/smb.service';

const EXTENSION_BY_FORMAT: Record<string, string> = {
  custom: '.backup',
  tar: '.tar',
  plain: '.sql',
  directory: ''
};

const EXTENSION_BY_ENGINE: Record<string, string> = {
  mysql: '.sql',
  mariadb: '.sql',
  sqlserver: '.bak',
  oracle: '.dmp',
  mongodb: '.archive.gz',
  rabbitmq: '.json',
  firebird: '.fbk'
};

/**
 * Gera um nome de arquivo padronizado e seguro para o backup usando o fuso horário local (`env.TZ`)
 * e a extensão adequada para cada motor.
 *
 * @example
 * buildBackupFileName('oficial', 'pg_dump', 'custom', 'postgresql');
 * // "oficial_25-11-2026_23-55-16.backup"
 */
export function buildBackupFileName(
  baseLabel: string,
  dumpType: 'pg_dump' | 'pg_dumpall',
  format: string,
  engine = 'postgresql'
): string {
  const safeLabel = baseLabel.replace(/[^a-zA-Z0-9_-]/g, '_');
  const now = new Date();
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: env.TZ,
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  }).formatToParts(now);

  const get = (type: string) => parts.find((p) => p.type === type)?.value ?? '00';
  const stamp = `${get('day')}-${get('month')}-${get('year')}_${get('hour')}-${get('minute')}-${get('second')}`;

  let ext = '.backup';
  if (engine !== 'postgresql') {
    ext = EXTENSION_BY_ENGINE[engine] ?? '.bak';
  } else {
    ext = dumpType === 'pg_dumpall' ? '.sql' : (EXTENSION_BY_FORMAT[format] ?? '.backup');
  }
  return `${safeLabel}_${stamp}${ext}`;
}

/**
 * Registra as rotas de preview de comando, execução de backup (`pg_dump` / `pg_dumpall`)
 * e gerenciamento de perfis reutilizáveis de backup.
 *
 * @example
 * app.register(backupsRoutes, { prefix: '/api/backups' });
 */
export async function backupsRoutes(app: FastifyInstance): Promise<void> {
  app.addHook('preHandler', authenticateRequest);

  app.get('/folders', async () => {
    const listSubfolders = (baseDir: string, prefix: string): string[] => {
      const result = [prefix];
      if (!fs.existsSync(baseDir)) return result;
      for (const entry of fs.readdirSync(baseDir, { withFileTypes: true })) {
        if (entry.isDirectory() && !entry.name.startsWith('.')) {
          result.push(`${prefix}/${entry.name}`);
        }
      }
      return result;
    };

    const folders = [
      ...listSubfolders(env.BACKUP_DIR, 'backups'),
      ...listSubfolders(env.CUSTOM_BACKUP_DIR, 'custom')
    ];
    return { folders };
  });

  // Navegador visual de pastas do servidor (funciona em Windows, Linux Server headless, macOS e pastas de rede montadas)
  app.get('/browse', async (request, reply) => {
    const query = request.query as { path?: string };
    const currentPath = (query.path || '').replace(/\\/g, '/').replace(/^\/+|\/+$/g, '');

    if (!currentPath) {
      const db = getDatabase();
      const shares = db
        .prepare('SELECT id, name, unc_path FROM network_shares ORDER BY name ASC')
        .all() as Array<{ id: string; name: string; unc_path: string }>;

      return {
        currentPath: '',
        parentPath: null,
        directories: [
          { name: 'backups', fullPath: 'backups', label: 'backups (Pasta padrão do sistema)' },
          { name: 'custom', fullPath: 'custom', label: 'custom (Pasta externa montada via .env)' },
          ...shares.map((s) => ({
            name: s.name,
            fullPath: `share:${s.id}:`,
            label: `🌐 ${s.name} (${s.unc_path})`
          }))
        ]
      };
    }

    if (currentPath.startsWith('share:')) {
      const [, shareId, ...restParts] = currentPath.split(':');
      const subPath = restParts.join(':');
      try {
        const listed = await listSmbDirectory(shareId, subPath);
        const subSegments = subPath.split('/').filter(Boolean);
        const parentPath = subSegments.length > 0 ? `share:${shareId}:${subSegments.slice(0, -1).join('/')}` : '';
        return {
          currentPath,
          parentPath,
          directories: listed.directories.map((d) => ({
            name: d.name,
            fullPath: d.fullPath,
            label: d.name
          }))
        };
      } catch (err) {
        return reply.status(400).send({ error: (err as Error).message });
      }
    }

    try {
      const resolvedDir = resolveSafeFolderDir(currentPath);
      const entries = fs.readdirSync(resolvedDir, { withFileTypes: true });
      const directories = entries
        .filter((e) => e.isDirectory() && !e.name.startsWith('.'))
        .map((e) => ({
          name: e.name,
          fullPath: `${currentPath}/${e.name}`,
          label: e.name
        }))
        .sort((a, b) => a.name.localeCompare(b.name));

      const parts = currentPath.split('/');
      const parentPath = parts.length > 1 ? parts.slice(0, -1).join('/') : '';

      return { currentPath, parentPath, directories };
    } catch (err) {
      return reply.status(400).send({ error: (err as Error).message });
    }
  });

  // Cria uma nova subpasta segura dentro de backups/, custom/ ou compartilhamento SMB
  app.post('/folders', async (request, reply) => {
    const schema = z.object({
      parentPath: z.string().trim().default('backups'),
      folderName: z.string().trim().min(1).max(80)
    });
    const parsed = schema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Nome da pasta inválido.' });
    }

    const root = parsed.data.parentPath || 'backups';
    if (root.startsWith('share:')) {
      const [, shareId, ...restParts] = root.split(':');
      const subPath = restParts.join(':');
      try {
        const fullPath = await createSmbDirectory(shareId, subPath, parsed.data.folderName);
        return reply.status(201).send({ fullPath });
      } catch (err) {
        return reply.status(400).send({ error: (err as Error).message });
      }
    }

    const cleanName = parsed.data.folderName.replace(/[^a-zA-Z0-9_-]/g, '_');
    const fullPath = `${root}/${cleanName}`;

    try {
      resolveSafeFolderDir(fullPath);
      return reply.status(201).send({ fullPath });
    } catch (err) {
      return reply.status(400).send({ error: (err as Error).message });
    }
  });

  app.post('/preview', { preHandler: [requirePermission('backup:execute')] }, async (request, reply) => {
    const parsed = executeBackupSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Parâmetros inválidos.', details: parsed.error.flatten() });
    }

    try {
      const { descriptor } = getDecryptedConnection(parsed.data.connectionId);
      const adapter = getDatabaseAdapter(descriptor.engine);
      const fileName = buildBackupFileName(
        parsed.data.databaseName || descriptor.name,
        parsed.data.dumpType,
        parsed.data.options.format,
        descriptor.engine
      );
      const targetDir = resolveSafeFolderDir(parsed.data.targetFolder);
      const outputPath = path.join(targetDir, fileName);

      const cmd = adapter.buildBackupCommand(descriptor, '***', parsed.data, outputPath);
      return reply.send({ commandPreview: cmd.preview, fileName });
    } catch (err) {
      return reply.status(404).send({ error: (err as Error).message });
    }
  });

  app.post('/execute', { preHandler: [requirePermission('backup:execute')] }, async (request, reply) => {
    const parsed = executeBackupSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Parâmetros inválidos.', details: parsed.error.flatten() });
    }

    try {
      const { descriptor, password } = getDecryptedConnection(parsed.data.connectionId);
      const adapter = getDatabaseAdapter(descriptor.engine);
      const fileName = buildBackupFileName(
        parsed.data.databaseName || descriptor.name,
        parsed.data.dumpType,
        parsed.data.options.format,
        descriptor.engine
      );
      const isSmb = parsed.data.targetFolder.startsWith('share:');
      const targetDir = isSmb ? env.BACKUP_DIR : resolveSafeFolderDir(parsed.data.targetFolder);
      const outputPath = path.join(targetDir, fileName);

      const cmd = adapter.buildBackupCommand(descriptor, password, parsed.data, outputPath);
      const executionId = crypto.randomUUID();
      const db = getDatabase();

      db.prepare(`
        INSERT INTO executions (id, type, source_connection_id, database_name, status, command_preview, file_path)
        VALUES (?, 'backup', ?, ?, 'running', ?, ?)
      `).run(
        executionId,
        descriptor.id,
        parsed.data.dumpType === 'pg_dumpall' ? 'CLUSTER_GLOBAL' : (parsed.data.databaseName || descriptor.defaultDatabase),
        cmd.preview,
        isSmb ? `${parsed.data.targetFolder}/${fileName}` : outputPath
      );

      void runTrackedExecution(executionId, cmd, outputPath).then(async (res) => {
        if (res.success && isSmb) {
          const [, shareId, ...restParts] = parsed.data.targetFolder.split(':');
          const subPath = restParts.join(':');
          try {
            await uploadFileToSmb(shareId, subPath, outputPath, fileName);
            fs.rmSync(outputPath, { recursive: true, force: true });
          } catch (err) {
            db.prepare("UPDATE executions SET status = 'error', error_message = ? WHERE id = ?").run(
              (err as Error).message,
              executionId
            );
          }
        }
      });

      return reply.status(202).send({
        executionId,
        fileName,
        commandPreview: cmd.preview,
        status: 'running'
      });
    } catch (err) {
      return reply.status(404).send({ error: (err as Error).message });
    }
  });

  // Perfis de Backup salvos (para reutilização e agendamento)
  app.get('/profiles', async () => {
    const db = getDatabase();
    const profiles = db
      .prepare(`
        SELECT p.*, c.name as connection_name
        FROM backup_profiles p
        JOIN connections c ON c.id = p.connection_id
        ORDER BY p.name ASC
      `)
      .all();

    return { profiles };
  });

  app.post('/profiles', { preHandler: [requirePermission('backup:create', 'backup:profiles')] }, async (request, reply) => {
    const profileSchema = z.object({
      name: z.string().trim().min(2).max(100),
      description: z.string().trim().max(300).optional(),
      connectionId: z.string().uuid(),
      databaseName: z.string().trim().max(120).optional().nullable(),
      dumpType: z.enum(['pg_dump', 'pg_dumpall']).default('pg_dump'),
      options: backupOptionsSchema.default({}),
      targetFolder: z.string().trim().max(120).default('backups')
    });

    const parsed = profileSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Dados do perfil inválidos.', details: parsed.error.flatten() });
    }

    const id = crypto.randomUUID();
    const db = getDatabase();
    db.prepare(`
      INSERT INTO backup_profiles (id, name, description, connection_id, database_name, dump_type, options_json, target_folder)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      parsed.data.name,
      parsed.data.description ?? null,
      parsed.data.connectionId,
      parsed.data.databaseName ?? null,
      parsed.data.dumpType,
      JSON.stringify(parsed.data.options),
      parsed.data.targetFolder
    );

    return reply.status(201).send({ id, ...parsed.data });
  });

  app.delete<{ Params: { id: string } }>('/profiles/:id', { preHandler: [requirePermission('backup:delete', 'backup:profiles')] }, async (request, reply) => {
    const db = getDatabase();
    const res = db.prepare('DELETE FROM backup_profiles WHERE id = ?').run(request.params.id);
    if (res.changes === 0) {
      return reply.status(404).send({ error: 'Perfil não encontrado.' });
    }
    return reply.send({ deleted: true });
  });
}
