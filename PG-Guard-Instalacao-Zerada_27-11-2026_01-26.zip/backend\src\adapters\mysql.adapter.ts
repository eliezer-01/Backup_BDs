import {
  formatCommandPreview,
  resolveRuntimeHost,
  type BuiltCommand,
  type ConnectionDescriptor,
  type DatabaseAdapter
} from './base.adapter';

/**
 * Adaptador modular para MySQL e MariaDB utilizando os binários `mariadb` e `mariadb-dump`.
 * A senha é repassada de forma isolada via variável de ambiente `MYSQL_PWD`.
 *
 * @example
 * const adapter = new MysqlAdapter('mysql');
 */
export class MysqlAdapter implements DatabaseAdapter {
  readonly engine: string;

  constructor(engine: 'mysql' | 'mariadb' = 'mysql') {
    this.engine = engine;
  }

  private buildEnv(password: string): Record<string, string> {
    return { MYSQL_PWD: password };
  }

  private baseConnArgs(conn: ConnectionDescriptor): string[] {
    const args = [
      '-h', resolveRuntimeHost(conn.host),
      '-P', String(conn.port),
      '-u', conn.username
    ];
    if (conn.sslMode === 'disable') {
      args.push('--skip-ssl');
    } else if (conn.sslMode === 'require' || conn.sslMode === 'verify-full') {
      args.push('--ssl');
    }
    return args;
  }

  buildTestConnectionCommand(conn: ConnectionDescriptor, password: string): BuiltCommand {
    const args = [...this.baseConnArgs(conn), '-N', '-s', '-e', 'SELECT 1;'];
    return {
      binary: 'mariadb',
      args,
      envVars: this.buildEnv(password),
      preview: formatCommandPreview('mariadb', args)
    };
  }

  buildListDatabasesCommand(conn: ConnectionDescriptor, password: string): BuiltCommand {
    const args = [
      ...this.baseConnArgs(conn),
      '-N', '-s',
      '-e',
      "SELECT schema_name FROM information_schema.schemata WHERE schema_name NOT IN ('information_schema','mysql','performance_schema','sys') ORDER BY schema_name;"
    ];
    return {
      binary: 'mariadb',
      args,
      envVars: this.buildEnv(password),
      preview: formatCommandPreview('mariadb', args)
    };
  }

  buildCreateDatabaseCommand(
    conn: ConnectionDescriptor,
    password: string,
    targetDatabase: string
  ): BuiltCommand {
    const safeDb = targetDatabase.replace(/`/g, '');
    const args = [
      ...this.baseConnArgs(conn),
      '-e',
      `CREATE DATABASE IF NOT EXISTS \`${safeDb}\`;`
    ];
    return {
      binary: 'mariadb',
      args,
      envVars: this.buildEnv(password),
      preview: formatCommandPreview('mariadb', args)
    };
  }

  buildBackupCommand(
    conn: ConnectionDescriptor,
    password: string,
    rawParams: Record<string, unknown>,
    outputPath: string
  ): BuiltCommand {
    const dbName = (rawParams.databaseName as string) || conn.defaultDatabase;
    const opts = (rawParams.options as Record<string, unknown>) || {};
    const args = [
      ...this.baseConnArgs(conn),
      '--single-transaction',
      '--routines',
      '--triggers',
      '--events'
    ];

    if (opts.verbose !== false) {
      args.push('--verbose');
    }

    args.push(`--result-file=${outputPath}`, dbName);

    return {
      binary: 'mariadb-dump',
      args,
      envVars: this.buildEnv(password),
      preview: formatCommandPreview('mariadb-dump', args)
    };
  }

  buildRestoreCommand(
    conn: ConnectionDescriptor,
    password: string,
    rawParams: Record<string, unknown>,
    inputPath: string
  ): BuiltCommand {
    const targetDb = (rawParams.targetDatabase as string) || conn.defaultDatabase;
    const args = [
      ...this.baseConnArgs(conn),
      targetDb,
      '-e',
      `SOURCE ${inputPath};`
    ];
    return {
      binary: 'mariadb',
      args,
      envVars: this.buildEnv(password),
      preview: formatCommandPreview('mariadb', args)
    };
  }
}
