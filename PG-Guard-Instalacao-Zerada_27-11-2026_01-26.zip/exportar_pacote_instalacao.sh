#!/usr/bin/env bash
set -euo pipefail

cd "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

STAMP="$(date +%d-%m-%Y_%H-%M)"
OUT_ARCHIVE="PG-Guard-Instalacao-Zerada_${STAMP}.tar.gz"

echo "========================================================================"
echo "  PG Guard - Exportando Pacote Limpo para Nova Instalacao"
echo "========================================================================"

tar -czf "$OUT_ARCHIVE" \
  --exclude='data' \
  --exclude='node_modules' \
  --exclude='dist' \
  --exclude='.git' \
  --exclude='.env' \
  --exclude='.env.*' \
  --exclude='*.sqlite*' \
  --exclude='*.log' \
  --exclude='*.zip' \
  --exclude='*.tar.gz' \
  --exclude='atualizacao/*' \
  .

echo "[OK] Pacote gerado com sucesso: $OUT_ARCHIVE"
echo "     Para instalar em outro servidor, extraia o arquivo e rode ./instalar_atualizar.sh (ou instalar_atualizar.bat no Windows)."
