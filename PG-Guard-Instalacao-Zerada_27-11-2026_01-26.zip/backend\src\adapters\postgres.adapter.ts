import {
  formatCommandPreview,
  resolveRuntimeHost,
  type BuiltCommand,
  type ConnectionDescriptor,
  type DatabaseAdapter
} from './base.adapter';
import { backupOptionsSchema } from '../security/sanitizer';

export interface PostgresBackupParams {
  databaseName?: string;
  dumpType: 'pg_dump' | 'pg_dumpall';
  options: {
    format?: 'custom' | 'tar' | 'plain' | 'directory';
    jobs?: number;
    includeTables?: string[];
    excludeSchemas?: string[];
    includeBlobs?: boolean;
    verbose?: boolean;
    columnInserts?: boolean;
    globalScope?: 'all' | 'globals-only' | 'roles-only' | 'tablespaces-only';
  };
}

export interface PostgresRestoreParams {
  targetDatabase: string;
  restoreTool: 'pg_restore' | 'psql';
  onErrorStop?: boolean;
  verbose?: boolean;
  clean?: boolean;
  noAcl?: boolean;
  noOwner?: boolean;
  createFlag?: boolean;
  section?: 'all' | 'pre-data' | 'data' | 'post-data';
}

const FORMAT_FLAG_MAP: Record<string, string> = {
  custom: 'c',
  tar: 't',
  plain: 'p',
  directory: 'd'
};

/**
 * Adaptador modular completo para PostgreSQL.
 * Utiliza exclusivamente os binários nativos `psql`, `pg_dump`, `pg_dumpall` e `pg_restore`,
 * repassando a senha de forma isolada via `PGPASSWORD` no ambiente do processo filho.
 */
export class PostgresAdapter implements DatabaseAdapter {
  readonly engine = 'postgresql';

  /**
   * Gera as variáveis de ambiente isoladas para o processo filho do PostgreSQL.
   * Garante que a senha nunca apareça na linha de comando (`ps aux`) nem nos logs.
   */
  private buildEnv(conn: ConnectionDescriptor, password: string): Record<string, string> {
    return {
      PGPASSWORD: password,
      PGSSLMODE: conn.sslMode || 'prefer',
      PGCONNECT_TIMEOUT: '10'
    };
  }

  /**
   * Monta o comando `psql` para testar a conexão executando `SELECT 1;`.
   *
   * @example
   * const cmd = adapter.buildTestConnectionCommand(conn, senha);
   */
  buildTestConnectionCommand(conn: ConnectionDescriptor, password: string): BuiltCommand {
    const args = [
      '-h', resolveRuntimeHost(conn.host),
      '-p', String(conn.port),
      '-U', conn.username,
      '-d', conn.defaultDatabase || 'postgres',
      '-t', '-A',
      '-c', 'SELECT 1;'
    ];

    return {
      binary: 'psql',
      args,
      envVars: this.buildEnv(conn, password),
      preview: formatCommandPreview('psql', args)
    };
  }

  /**
   * Monta o comando `psql` para listar todos os bancos de dados não-template do servidor.
   *
   * @example
   * const cmd = adapter.buildListDatabasesCommand(conn, senha);
   */
  buildListDatabasesCommand(conn: ConnectionDescriptor, password: string): BuiltCommand {
    const args = [
      '-h', resolveRuntimeHost(conn.host),
      '-p', String(conn.port),
      '-U', conn.username,
      '-d', conn.defaultDatabase || 'postgres',
      '-t', '-A',
      '-c', 'SELECT datname FROM pg_database WHERE datistemplate = false ORDER BY datname;'
    ];

    return {
      binary: 'psql',
      args,
      envVars: this.buildEnv(conn, password),
      preview: formatCommandPreview('psql', args)
    };
  }

  /**
   * Monta comando `psql` para criar um banco de dados caso não exista no destino.
   *
   * @param targetDatabase Nome do novo banco de dados a ser criado.
   */
  buildCreateDatabaseCommand(
    conn: ConnectionDescriptor,
    password: string,
    targetDatabase: string
  ): BuiltCommand {
    const checkArgs = [
      '-h', resolveRuntimeHost(conn.host),
      '-p', String(conn.port),
      '-U', conn.username,
      '-d', conn.defaultDatabase || 'postgres',
      '-t', '-A',
      '-v', `dbname=${targetDatabase}`,
      '-c', `CREATE DATABASE "${targetDatabase.replace(/"/g, '')}";`
    ];

    return {
      binary: 'psql',
      args: checkArgs,
      envVars: this.buildEnv(conn, password),
      preview: formatCommandPreview('psql', checkArgs)
    };
  }

  /**
   * Monta o comando de backup (`pg_dump` ou `pg_dumpall`) com todas as flags configuradas.
   *
   * @example
   * const cmd = adapter.buildBackupCommand(conn, senha, { dumpType: 'pg_dump', databaseName: 'oficial', options: { format: 'custom', verbose: true } }, '/app/data/backups/oficial.backup');
   */
  buildBackupCommand(
    conn: ConnectionDescriptor,
    password: string,
    rawParams: Record<string, unknown>,
    outputPath: string
  ): BuiltCommand {
    const params = rawParams as unknown as PostgresBackupParams;
    const opts = backupOptionsSchema.parse(params.options ?? {});

    if (params.dumpType === 'pg_dumpall') {
      const args = [
        '-h', resolveRuntimeHost(conn.host),
        '-p', String(conn.port),
        '-U', conn.username
      ];

      if (opts.globalScope === 'globals-only') args.push('--globals-only');
      if (opts.globalScope === 'roles-only') args.push('--roles-only');
      if (opts.globalScope === 'tablespaces-only') args.push('--tablespaces-only');
      if (opts.verbose) args.push('-v');

      args.push('-f', outputPath);

      return {
        binary: 'pg_dumpall',
        args,
        envVars: this.buildEnv(conn, password),
        preview: formatCommandPreview('pg_dumpall', args)
      };
    }

    const dbName = params.databaseName || conn.defaultDatabase || 'postgres';
    const formatCode = FORMAT_FLAG_MAP[opts.format] ?? 'c';

    const args = [
      '-h', resolveRuntimeHost(conn.host),
      '-p', String(conn.port),
      '-U', conn.username,
      '-d', dbName,
      `-F${formatCode}`
    ];

    if (opts.format === 'directory' && opts.jobs && opts.jobs > 1) {
      args.push('-j', String(opts.jobs));
    }

    for (const tablePattern of opts.includeTables) {
      args.push('-t', tablePattern);
    }

    for (const schemaName of opts.excludeSchemas) {
      args.push('-N', schemaName);
    }

    if (opts.includeBlobs) {
      args.push('-b');
    }

    if (opts.verbose) {
      args.push('-v');
    }

    if (opts.format === 'plain' && opts.columnInserts) {
      args.push('--column-inserts');
    }

    args.push('-f', outputPath);

    return {
      binary: 'pg_dump',
      args,
      envVars: this.buildEnv(conn, password),
      preview: formatCommandPreview('pg_dump', args)
    };
  }

  /**
   * Monta o comando de restauração (`pg_restore` ou `psql`).
   *
   * @example
   * const cmd = adapter.buildRestoreCommand(connTeste, senha, { targetDatabase: 'teste', restoreTool: 'pg_restore', clean: true, noOwner: true }, '/app/data/backups/oficial.backup');
   */
  buildRestoreCommand(
    conn: ConnectionDescriptor,
    password: string,
    rawParams: Record<string, unknown>,
    inputPath: string
  ): BuiltCommand {
    const params = rawParams as unknown as PostgresRestoreParams;

    if (params.restoreTool === 'psql') {
      const args = [
        '-h', resolveRuntimeHost(conn.host),
        '-p', String(conn.port),
        '-U', conn.username,
        '-d', params.targetDatabase
      ];

      if (params.onErrorStop !== false) {
        args.push('--set', 'ON_ERROR_STOP=on');
      }

      args.push('-f', inputPath);

      return {
        binary: 'psql',
        args,
        envVars: this.buildEnv(conn, password),
        preview: formatCommandPreview('psql', args)
      };
    }

    const args = [
      '-h', resolveRuntimeHost(conn.host),
      '-p', String(conn.port),
      '-U', conn.username
    ];

    if (params.createFlag) {
      args.push('-d', conn.defaultDatabase || 'postgres', '--create');
    } else {
      args.push('-d', params.targetDatabase);
    }

    if (params.verbose) args.push('--verbose');
    if (params.clean) args.push('--clean', '--if-exists');
    if (params.noAcl) args.push('--no-acl');
    if (params.noOwner) args.push('--no-owner');

    if (params.section && params.section !== 'all') {
      args.push('--section', params.section);
    }

    args.push(inputPath);

    return {
      binary: 'pg_restore',
      args,
      envVars: this.buildEnv(conn, password),
      preview: formatCommandPreview('pg_restore', args)
    };
  }

  /**
   * Monta o comando `pg_restore --list` para inspecionar o índice (TOC) do backup antes de restaurar.
   *
   * @example
   * const cmd = adapter.buildInspectCommand('/app/data/backups/oficial.backup');
   */
  buildInspectCommand(inputPath: string): BuiltCommand {
    const args = ['--list', inputPath];
    return {
      binary: 'pg_restore',
      args,
      envVars: {},
      preview: formatCommandPreview('pg_restore', args)
    };
  }
}

const adaptersRegistry: Record<string, DatabaseAdapter> = {
  postgresql: new PostgresAdapter()
};

/**
 * Retorna o adaptador correspondente ao motor de banco de dados solicitado.
 * Ponto central de extensão para adicionar MySQL, MariaDB, Oracle, SQL Server, MongoDB ou RabbitMQ.
 *
 * @param engine Identificador do motor (`postgresql`, etc.).
 * @example
 * const adapter = getDatabaseAdapter('postgresql');
 */
export function getDatabaseAdapter(engine: string): DatabaseAdapter {
  const adapter = adaptersRegistry[engine];
  if (!adapter) {
    throw new Error(`Motor de banco de dados '${engine}' ainda não possui adaptador registrado.`);
  }
  return adapter;
}
