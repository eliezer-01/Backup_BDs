# PG Guard — Gerenciador Seguro de Backups PostgreSQL

Sistema web multiplataforma (Linux, Windows e macOS) empacotado em Docker para gerenciar backups, restaurações, agendamentos e rotação de bancos PostgreSQL, com arquitetura modular preparada para outros motores no futuro.

## Instalação e Atualização Automática (Sem Git)

- **Windows:** Dê um duplo clique em [`instalar_atualizar.bat`](instalar_atualizar.bat).
- **Linux / macOS:** Execute `chmod +x instalar_atualizar.sh && ./instalar_atualizar.sh`.

### O que os scripts fazem por sistema operacional:
1. **Instalam e iniciam o Docker automaticamente** (`winget` no Windows, `Homebrew` no macOS, `get.docker.com` + `systemctl` no Linux).
2. **Atualizam a partir de uma pasta nova (sem Git):** Basta arrastar a pasta da nova versão para cima do `.bat`, colocá-la em `./atualizacao/`, ou informar o caminho quando solicitado:
   - Fazem backup de segurança automático de `data/db/app.sqlite` e `.env`;
   - Copiam apenas os arquivos novos preservando `data/` (bancos e backups) e `.env`;
   - Mesclam automaticamente novas variáveis do `.env.example` no `.env` sem sobrescrever suas chaves (`MASTER_ENCRYPTION_KEY`, `JWT_SECRET`, senhas);
   - Ao subir o container, o backend executa automaticamente as **migrations de tabelas e colunas no SQLite** (`schema.sql` + `migrations.ts`) sem perda de dados.

## Instalação Manual (Linux / macOS / Windows)

1. Copie o arquivo de exemplo de variáveis de ambiente:
   ```bash
   cp .env.example .env
   ```
2. Edite o `.env` e defina:
   - `MASTER_ENCRYPTION_KEY`: chave hexadecimal de 64 caracteres (ex: `openssl rand -hex 32`) para criptografia **AES-256-GCM**.
   - `JWT_SECRET`: segredo longo e aleatório para tokens de sessão.
   - `ADMIN_USER` e `ADMIN_PASSWORD`: login inicial do painel web.
3. Suba os containers:
   ```bash
   docker compose up -d --build
   ```
4. Acesse `http://localhost:8080` (ou a porta configurada em `APP_PORT`).

> **Dica para bancos no host local:** Ao cadastrar uma conexão para um PostgreSQL rodando diretamente na sua máquina Windows/macOS/Linux, utilize `host.docker.internal` como host.

## Fluxo Comum: Copiar Base Oficial para Base Teste

1. Na aba **Conexões**, cadastre o servidor **Oficial** e o servidor **Teste** (ou o mesmo servidor) e clique em **Testar Conexão**.
2. Na aba **Backup**, selecione a conexão **Oficial**, escolha o banco oficial, formato `Custom (-Fc)` e clique em **Executar Backup Agora**.
3. Na aba **Restauração**, selecione o arquivo gerado, escolha a conexão **Teste**, informe o banco de destino (marcando **Criar banco alvo automaticamente** se necessário) e clique em **Iniciar Restauração**.
