import type { DatabaseAdapter } from './base.adapter';
import { PostgresAdapter } from './postgres.adapter';
import { MysqlAdapter } from './mysql.adapter';
import { MongoDbAdapter } from './mongodb.adapter';
import { SqlServerAdapter } from './sqlserver.adapter';
import { OracleAdapter } from './oracle.adapter';
import { RabbitMqAdapter } from './rabbitmq.adapter';
import { FirebirdAdapter } from './firebird.adapter';

const adaptersRegistry: Record<string, DatabaseAdapter> = {
  postgresql: new PostgresAdapter(),
  mysql: new MysqlAdapter('mysql'),
  mariadb: new MysqlAdapter('mariadb'),
  sqlserver: new SqlServerAdapter(),
  oracle: new OracleAdapter(),
  mongodb: new MongoDbAdapter(),
  rabbitmq: new RabbitMqAdapter(),
  firebird: new FirebirdAdapter()
};

/**
 * Retorna o adaptador correspondente ao motor de banco de dados ou serviço solicitado.
 *
 * @param engine Identificador do motor (`postgresql`, `mysql`, `mariadb`, `sqlserver`, `oracle`, `mongodb`, `rabbitmq`).
 * @example
 * const adapter = getDatabaseAdapter('mysql');
 */
export function getDatabaseAdapter(engine: string): DatabaseAdapter {
  const adapter = adaptersRegistry[engine];
  if (!adapter) {
    throw new Error(`Motor '${engine}' não possui adaptador registrado.`);
  }
  return adapter;
}
