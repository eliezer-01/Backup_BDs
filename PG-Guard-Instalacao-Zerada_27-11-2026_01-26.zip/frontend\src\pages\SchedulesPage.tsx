import { useEffect, useState, type FormEvent } from 'react';
import { CalendarClock, Info, Pause, Play, Plus, RotateCw, Trash2, X } from 'lucide-react';
import { apiRequest } from '../services/api';
import { Badge, Button, Card, Input, Select, Toggle } from '../components/ui';
import type { Connection } from './ConnectionsPage';

interface BackupProfile {
  id: string;
  name: string;
  connection_name: string;
  database_name: string | null;
  dump_type: string;
}

interface RestoreProfile {
  id: string;
  name: string;
  target_connection_name: string;
  target_database: string;
  use_latest_backup: number;
  source_database: string | null;
}

interface Schedule {
  id: string;
  schedule_type: 'backup' | 'restore';
  profile_id: string | null;
  restore_profile_id: string | null;
  profile_name: string;
  connection_name: string;
  database_name: string | null;
  cron_expression: string;
  is_active: number;
  retention_daily: number;
  retention_weekly: number;
  retention_monthly: number;
  last_run_at: string | null;
  next_run_at: string | null;
}

/**
 * Gerenciador de Agendamentos Avulsos (Backup OU Restauração) com Pop-up unificado
 * para criação rápida de Perfis de Backup ou Perfis de Restauração.
 *
 * @example
 * <SchedulesPage />
 */
export function SchedulesPage() {
  const [profiles, setProfiles] = useState<BackupProfile[]>([]);
  const [restoreProfiles, setRestoreProfiles] = useState<RestoreProfile[]>([]);
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [modalDatabases, setModalDatabases] = useState<string[]>([]);
  const [modalTargetDbs, setModalTargetDbs] = useState<string[]>([]);

  const [scheduleType, setScheduleType] = useState<'backup' | 'restore'>('backup');
  const [profileId, setProfileId] = useState('');
  const [restoreProfileId, setRestoreProfileId] = useState('');
  const [preset, setPreset] = useState<'daily' | 'weekly' | 'monthly' | 'custom'>('daily');
  const [hour, setHour] = useState('02');
  const [minute, setMinute] = useState('00');
  const [weekDay, setWeekDay] = useState('0');
  const [monthDay, setMonthDay] = useState('1');
  const [customCron, setCustomCron] = useState('0 2 * * *');

  const [retDaily, setRetDaily] = useState(7);
  const [retWeekly, setRetWeekly] = useState(4);
  const [retMonthly, setRetMonthly] = useState(3);
  const [notifyEmailTo, setNotifyEmailTo] = useState('');
  const [notifyOnSuccess, setNotifyOnSuccess] = useState(true);
  const [notifyOnError, setNotifyOnError] = useState(true);
  const [feedback, setFeedback] = useState('');

  // Estados do Pop-up unificado (Perfil de Backup OU Perfil de Restauração)
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [modalKind, setModalKind] = useState<'backup' | 'restore'>('backup');
  const [pName, setPName] = useState('');
  const [pConnId, setPConnId] = useState('');
  const [pDumpType, setPDumpType] = useState<'pg_dump' | 'pg_dumpall'>('pg_dump');
  const [pDbName, setPDbName] = useState('');
  const [pFormat, setPFormat] = useState<'custom' | 'tar' | 'plain' | 'directory'>('custom');
  const [pExcludeSchemas, setPExcludeSchemas] = useState('');
  const [pVerbose, setPVerbose] = useState(true);
  const [pBlobs, setPBlobs] = useState(false);

  // Campos extras quando o pop-up estiver no modo Perfil de Restauração
  const [rpTargetConnId, setRpTargetConnId] = useState('');
  const [rpTargetDb, setRpTargetDb] = useState('');
  const [rpCreateDb, setRpCreateDb] = useState(true);
  const [rpClean, setRpClean] = useState(true);
  const [modalError, setModalError] = useState('');

  async function loadAll() {
    const [pRes, rpRes, sRes, cRes] = await Promise.all([
      apiRequest<{ profiles: BackupProfile[] }>('/api/backups/profiles'),
      apiRequest<{ profiles: RestoreProfile[] }>('/api/restores/profiles').catch(() => ({ profiles: [] })),
      apiRequest<{ schedules: Schedule[] }>('/api/schedules'),
      apiRequest<{ connections: Connection[] }>('/api/connections')
    ]);
    setProfiles(pRes.profiles);
    setRestoreProfiles(rpRes.profiles);
    setSchedules(sRes.schedules);
    setConnections(cRes.connections);

    if (pRes.profiles.length > 0 && !profileId) setProfileId(pRes.profiles[0].id);
    if (rpRes.profiles.length > 0 && !restoreProfileId) setRestoreProfileId(rpRes.profiles[0].id);
    if (cRes.connections.length > 0 && !pConnId) setPConnId(cRes.connections[0].id);
    if (cRes.connections.length > 0 && !rpTargetConnId) setRpTargetConnId(cRes.connections[0].id);
  }

  useEffect(() => {
    void loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!showProfileModal || !pConnId) return;
    void apiRequest<{ databases: string[] }>(`/api/connections/${pConnId}/databases`)
      .then((res) => {
        setModalDatabases(res.databases);
        if (res.databases.length > 0) setPDbName(res.databases[0]);
      })
      .catch(() => setModalDatabases([]));
  }, [showProfileModal, pConnId]);

  useEffect(() => {
    if (!showProfileModal || modalKind !== 'restore' || !rpTargetConnId) return;
    void apiRequest<{ databases: string[] }>(`/api/connections/${rpTargetConnId}/databases`)
      .then((res) => setModalTargetDbs(res.databases))
      .catch(() => setModalTargetDbs([]));
  }, [showProfileModal, modalKind, rpTargetConnId]);

  const resolvedCron =
    preset === 'daily'
      ? `${Number(minute)} ${Number(hour)} * * *`
      : preset === 'weekly'
        ? `${Number(minute)} ${Number(hour)} * * ${weekDay}`
        : preset === 'monthly'
          ? `${Number(minute)} ${Number(hour)} ${monthDay} * *`
          : customCron;

  async function handleCreateProfileModal(e: FormEvent) {
    e.preventDefault();
    setModalError('');
    try {
      if (modalKind === 'backup') {
        const created = await apiRequest<{ id: string }>('/api/backups/profiles', {
          method: 'POST',
          body: JSON.stringify({
            name: pName.trim(),
            connectionId: pConnId,
            databaseName: pDumpType === 'pg_dump' ? pDbName : null,
            dumpType: pDumpType,
            options: {
              format: pFormat,
              excludeSchemas: pExcludeSchemas.split(',').map((s) => s.trim()).filter(Boolean),
              includeBlobs: pBlobs,
              verbose: pVerbose
            }
          })
        });
        setPName('');
        setShowProfileModal(false);
        await loadAll();
        setScheduleType('backup');
        setProfileId(created.id);
        setFeedback('Perfil de backup criado e selecionado!');
      } else {
        const created = await apiRequest<{ id: string }>('/api/restores/profiles', {
          method: 'POST',
          body: JSON.stringify({
            name: pName.trim(),
            sourceFolder: 'backups',
            useLatestBackup: true,
            sourceConnectionId: pConnId,
            sourceDatabase: pDbName,
            targetConnectionId: rpTargetConnId,
            targetDatabase: rpTargetDb,
            createDatabaseIfNotExists: rpCreateDb,
            restoreTool: 'pg_restore',
            options: { verbose: true, clean: rpClean, noOwner: true, onErrorStop: true }
          })
        });
        setPName('');
        setRpTargetDb('');
        setShowProfileModal(false);
        await loadAll();
        setScheduleType('restore');
        setRestoreProfileId(created.id);
        setFeedback('Perfil de restauração criado e selecionado!');
      }
    } catch (err) {
      setModalError((err as Error).message);
    }
  }

  async function handleCreate(e: FormEvent) {
    e.preventDefault();
    setFeedback('');
    try {
      await apiRequest('/api/schedules', {
        method: 'POST',
        body: JSON.stringify({
          scheduleType,
          profileId: scheduleType === 'backup' ? profileId : null,
          restoreProfileId: scheduleType === 'restore' ? restoreProfileId : null,
          cronExpression: resolvedCron,
          isActive: true,
          retentionDaily: Number(retDaily),
          retentionWeekly: Number(retWeekly),
          retentionMonthly: Number(retMonthly),
          notifyEmailTo: notifyEmailTo.trim() || '',
          notifyOnSuccess,
          notifyOnError
        })
      });
      setNotifyEmailTo('');
      await loadAll();
      setFeedback('Agendamento criado com sucesso!');
    } catch (err) {
      setFeedback((err as Error).message);
    }
  }

  async function handleToggleActive(s: Schedule) {
    await apiRequest(`/api/schedules/${s.id}`, {
      method: 'PUT',
      body: JSON.stringify({ isActive: s.is_active !== 1 })
    });
    await loadAll();
  }

  async function handleRunNow(id: string) {
    await apiRequest(`/api/schedules/${id}/run-now`, { method: 'POST' });
    setFeedback('Execução agendada disparada manualmente! Acompanhe na aba Histórico e Logs.');
  }

  async function handleDelete(id: string) {
    if (!confirm('Excluir este agendamento?')) return;
    await apiRequest(`/api/schedules/${id}`, { method: 'DELETE' });
    await loadAll();
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold">Agendamentos e Rotação</h2>
          <p className="text-sm text-muted-foreground">
            Agende rotinas individuais de <strong>Backup</strong> ou <strong>Restauração</strong> (fuso: <code>America/Sao_Paulo</code>).
          </p>
        </div>
        <Button
          variant="outline"
          onClick={() => {
            setModalKind(scheduleType);
            setShowProfileModal(true);
          }}
        >
          <Plus className="h-4 w-4" />
          Criar Perfil (Backup / Restauração)
        </Button>
      </div>

      {/* Pop-up Unificado para criar Perfil de Backup ou Perfil de Restauração */}
      {showProfileModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <Card className="max-h-[90vh] w-full max-w-lg overflow-y-auto p-6">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-lg font-bold">Novo Perfil</h3>
              <Button variant="ghost" size="sm" onClick={() => setShowProfileModal(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>

            <form onSubmit={handleCreateProfileModal} className="space-y-4">
              <div>
                <label className="mb-1 block text-xs font-medium text-muted-foreground">Tipo do Perfil</label>
                <Select value={modalKind} onChange={(e) => setModalKind(e.target.value as 'backup' | 'restore')}>
                  <option value="backup">Perfil de Backup</option>
                  <option value="restore">Perfil de Restauração (pega último backup por data/hora)</option>
                </Select>
              </div>

              <div>
                <label className="mb-1 block text-xs font-medium text-muted-foreground">Nome do Perfil</label>
                <Input
                  value={pName}
                  onChange={(e) => setPName(e.target.value)}
                  placeholder={modalKind === 'backup' ? 'Ex: Backup Diário Oficial' : 'Ex: Restaurar Oficial em Teste'}
                  required
                />
              </div>

              {modalKind === 'backup' ? (
                <>
                  <div className="grid gap-3 md:grid-cols-2">
                    <div>
                      <label className="mb-1 block text-xs font-medium text-muted-foreground">Servidor</label>
                      <Select value={pConnId} onChange={(e) => setPConnId(e.target.value)} required>
                        {connections.map((c) => (
                          <option key={c.id} value={c.id}>{c.name} [{c.engine}]</option>
                        ))}
                      </Select>
                    </div>
                    {(connections.find((c) => c.id === pConnId)?.engine || 'postgresql') === 'postgresql' && (
                      <div>
                        <label className="mb-1 block text-xs font-medium text-muted-foreground">Tipo</label>
                        <Select value={pDumpType} onChange={(e) => setPDumpType(e.target.value as 'pg_dump' | 'pg_dumpall')}>
                          <option value="pg_dump">Banco Único (pg_dump)</option>
                          <option value="pg_dumpall">Cluster Global (pg_dumpall)</option>
                        </Select>
                      </div>
                    )}
                  </div>

                  {pDumpType === 'pg_dump' && (
                    <div className="grid gap-3 md:grid-cols-2">
                      <div>
                        <label className="mb-1 block text-xs font-medium text-muted-foreground">Banco de Dados</label>
                        <Select value={pDbName} onChange={(e) => setPDbName(e.target.value)} required>
                          {modalDatabases.map((db) => (
                            <option key={db} value={db}>{db}</option>
                          ))}
                        </Select>
                      </div>
                      <div>
                        <label className="mb-1 block text-xs font-medium text-muted-foreground">Formato</label>
                        <Select value={pFormat} onChange={(e) => setPFormat(e.target.value as typeof pFormat)}>
                          <option value="custom">Custom (-Fc)</option>
                          <option value="tar">Tar (-Ft)</option>
                          <option value="plain">Plain SQL (-Fp)</option>
                          <option value="directory">Directory (-Fd)</option>
                        </Select>
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">
                      Excluir Schemas (-N, opcional, separados por vírgula)
                    </label>
                    <Input value={pExcludeSchemas} onChange={(e) => setPExcludeSchemas(e.target.value)} placeholder="Ex: logs_temp" />
                  </div>

                  <div className="grid gap-2 md:grid-cols-2">
                    <Toggle checked={pVerbose} onChange={setPVerbose} label="Modo Verbose (-v)" />
                    <Toggle checked={pBlobs} onChange={setPBlobs} label="Incluir Blobs (-b)" />
                  </div>
                </>
              ) : (
                <>
                  <div className="grid gap-3 md:grid-cols-2">
                    <div>
                      <label className="mb-1 block text-xs font-medium text-muted-foreground">Conexão do Backup de Origem</label>
                      <Select value={pConnId} onChange={(e) => setPConnId(e.target.value)} required>
                        {connections.map((c) => (
                          <option key={c.id} value={c.id}>{c.name} [{c.engine}]</option>
                        ))}
                      </Select>
                    </div>
                    <div>
                      <label className="mb-1 block text-xs font-medium text-muted-foreground">Banco de Origem (último backup)</label>
                      <Select value={pDbName} onChange={(e) => setPDbName(e.target.value)} required>
                        {modalDatabases.map((db) => (
                          <option key={db} value={db}>{db}</option>
                        ))}
                      </Select>
                    </div>
                    <div>
                      <label className="mb-1 block text-xs font-medium text-muted-foreground">Servidor de Destino</label>
                      <Select value={rpTargetConnId} onChange={(e) => setRpTargetConnId(e.target.value)} required>
                        {connections.map((c) => (
                          <option key={c.id} value={c.id}>{c.name} [{c.engine}]</option>
                        ))}
                      </Select>
                    </div>
                    <div>
                      <label className="mb-1 block text-xs font-medium text-muted-foreground">Banco de Destino (selecione ou digite)</label>
                      <Input
                        list="modal-rp-target-dbs"
                        value={rpTargetDb}
                        onChange={(e) => setRpTargetDb(e.target.value)}
                        placeholder="Ex: base_teste"
                        required
                      />
                      <datalist id="modal-rp-target-dbs">
                        {modalTargetDbs.map((db) => (
                          <option key={db} value={db} />
                        ))}
                      </datalist>
                    </div>
                  </div>
                  <div className="grid gap-2 md:grid-cols-2">
                    <Toggle checked={rpCreateDb} onChange={setRpCreateDb} label="Criar banco se não existir" />
                    <Toggle checked={rpClean} onChange={setRpClean} label="Sobrescrever objetos (--clean)" />
                  </div>
                </>
              )}

              {modalError && <div className="rounded-lg bg-destructive/15 p-3 text-xs text-destructive">{modalError}</div>}

              <div className="flex justify-end gap-2 pt-2">
                <Button type="button" variant="outline" onClick={() => setShowProfileModal(false)}>
                  Cancelar
                </Button>
                <Button type="submit" disabled={!pConnId}>
                  Salvar Perfil
                </Button>
              </div>
            </form>
          </Card>
        </div>
      )}

      <Card className="p-5">
        <h3 className="mb-4 flex items-center gap-2 text-base font-semibold">
          <Plus className="h-4 w-4 text-primary" />
          Novo Agendamento Automático
        </h3>

        <form onSubmit={handleCreate} className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Tipo de Agendamento</label>
              <Select value={scheduleType} onChange={(e) => setScheduleType(e.target.value as 'backup' | 'restore')}>
                <option value="backup">Backup Automático</option>
                <option value="restore">Restauração Automática</option>
              </Select>
            </div>

            <div>
              <label className="mb-1 flex items-center justify-between text-xs font-medium text-muted-foreground">
                <span>{scheduleType === 'backup' ? 'Perfil de Backup' : 'Perfil de Restauração'}</span>
                <button
                  type="button"
                  onClick={() => {
                    setModalKind(scheduleType);
                    setShowProfileModal(true);
                  }}
                  className="text-[11px] font-semibold text-primary hover:underline"
                >
                  + Novo Perfil
                </button>
              </label>

              {scheduleType === 'backup' ? (
                <Select value={profileId} onChange={(e) => setProfileId(e.target.value)} required>
                  {profiles.length === 0 && <option value="">Clique em &quot;+ Novo Perfil&quot;</option>}
                  {profiles.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.connection_name} / {p.database_name || 'Cluster'})
                    </option>
                  ))}
                </Select>
              ) : (
                <Select value={restoreProfileId} onChange={(e) => setRestoreProfileId(e.target.value)} required>
                  {restoreProfiles.length === 0 && <option value="">Clique em &quot;+ Novo Perfil&quot;</option>}
                  {restoreProfiles.map((rp) => (
                    <option key={rp.id} value={rp.id}>
                      {rp.name} ({rp.target_connection_name} → {rp.target_database})
                    </option>
                  ))}
                </Select>
              )}
            </div>

            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Frequência</label>
              <Select value={preset} onChange={(e) => setPreset(e.target.value as typeof preset)}>
                <option value="daily">Diário</option>
                <option value="weekly">Semanal</option>
                <option value="monthly">Mensal</option>
                <option value="custom">Expressão Cron Avançada</option>
              </Select>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-4">
            {preset !== 'custom' ? (
              <>
                <div>
                  <label className="mb-1 block text-xs font-medium text-muted-foreground">Hora (0-23)</label>
                  <Input type="number" min={0} max={23} value={hour} onChange={(e) => setHour(e.target.value)} />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-muted-foreground">Minuto (0-59)</label>
                  <Input type="number" min={0} max={59} value={minute} onChange={(e) => setMinute(e.target.value)} />
                </div>
                {preset === 'weekly' && (
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Dia da Semana</label>
                    <Select value={weekDay} onChange={(e) => setWeekDay(e.target.value)}>
                      <option value="0">Domingo</option>
                      <option value="1">Segunda-feira</option>
                      <option value="2">Terça-feira</option>
                      <option value="3">Quarta-feira</option>
                      <option value="4">Quinta-feira</option>
                      <option value="5">Sexta-feira</option>
                      <option value="6">Sábado</option>
                    </Select>
                  </div>
                )}
                {preset === 'monthly' && (
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Dia do Mês (1-28)</label>
                    <Input type="number" min={1} max={28} value={monthDay} onChange={(e) => setMonthDay(e.target.value)} />
                  </div>
                )}
              </>
            ) : (
              <div className="md:col-span-2">
                <label className="mb-1 block text-xs font-medium text-muted-foreground">Expressão Cron (5 campos)</label>
                <Input value={customCron} onChange={(e) => setCustomCron(e.target.value)} placeholder="0 2 * * *" />
              </div>
            )}

            <div className="flex items-end">
              <div className="w-full rounded-lg bg-muted p-2.5 text-xs">
                Cron gerada: <code className="font-bold">{resolvedCron}</code>
              </div>
            </div>
          </div>

          <div className="space-y-3 border-t border-border pt-4">
            {scheduleType === 'backup' && (
              <>
                <div className="flex items-start gap-2 rounded-lg bg-muted/60 p-3 text-xs text-muted-foreground">
                  <Info className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                  <div>
                    <strong className="text-foreground">Como funciona a Rotação (ex: 7D / 4S / 3M):</strong>{' '}
                    O sistema mantém o backup mais recente dos últimos <strong>7 dias (D)</strong>, mais 1 backup por semana das últimas <strong>4 semanas (S)</strong> e 1 por mês dos últimos <strong>3 meses (M)</strong>.
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-3">
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Manter últimos X Diários (D)</label>
                    <Input type="number" min={1} value={retDaily} onChange={(e) => setRetDaily(Number(e.target.value))} />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Manter últimos Y Semanais (S)</label>
                    <Input type="number" min={0} value={retWeekly} onChange={(e) => setRetWeekly(Number(e.target.value))} />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Manter últimos Z Mensais (M)</label>
                    <Input type="number" min={0} value={retMonthly} onChange={(e) => setRetMonthly(Number(e.target.value))} />
                  </div>
                </div>
              </>
            )}

            <div className="grid gap-4 border-t border-border pt-4 md:grid-cols-3">
              <div>
                <label className="mb-1 block text-xs font-medium text-muted-foreground">
                  E-mail para Alertas (opcional)
                </label>
                <Input
                  type="email"
                  value={notifyEmailTo}
                  onChange={(e) => setNotifyEmailTo(e.target.value)}
                  placeholder="ti@empresa.com.br"
                />
              </div>
              <Toggle checked={notifyOnSuccess} onChange={setNotifyOnSuccess} label="Alertar em Sucesso" />
              <Toggle checked={notifyOnError} onChange={setNotifyOnError} label="Alertar em Falha" />
            </div>
          </div>

          {feedback && <div className="rounded-lg bg-primary/10 p-3 text-xs text-primary">{feedback}</div>}

          <Button type="submit" disabled={scheduleType === 'backup' ? !profileId : !restoreProfileId}>
            <CalendarClock className="h-4 w-4" />
            Criar Agendamento
          </Button>
        </form>
      </Card>

      <div className="space-y-3">
        {schedules.map((s) => (
          <Card key={s.id} className="flex flex-wrap items-center justify-between gap-4 p-4">
            <div>
              <div className="flex items-center gap-2">
                <Badge tone={s.schedule_type === 'restore' ? 'running' : 'neutral'}>
                  {s.schedule_type === 'restore' ? 'Restauração' : 'Backup'}
                </Badge>
                <span className="font-semibold">{s.profile_name}</span>
                <Badge tone={s.is_active === 1 ? 'success' : 'neutral'}>
                  {s.is_active === 1 ? 'Ativo' : 'Pausado'}
                </Badge>
                <code className="rounded bg-muted px-2 py-0.5 text-xs">{s.cron_expression}</code>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                {s.connection_name} ({s.database_name || 'Cluster'})
                {s.schedule_type === 'backup' && ` • Rotação: ${s.retention_daily}D / ${s.retention_weekly}S / ${s.retention_monthly}M`}
                {s.next_run_at && ` • Próxima: ${new Date(s.next_run_at).toLocaleString('pt-BR')}`}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => void handleRunNow(s.id)}>
                <RotateCw className="h-3.5 w-3.5" />
                Executar Agora
              </Button>
              <Button variant="outline" size="sm" onClick={() => void handleToggleActive(s)}>
                {s.is_active === 1 ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
                {s.is_active === 1 ? 'Pausar' : 'Ativar'}
              </Button>
              <Button variant="ghost" size="sm" onClick={() => void handleDelete(s.id)}>
                <Trash2 className="h-3.5 w-3.5 text-destructive" />
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
