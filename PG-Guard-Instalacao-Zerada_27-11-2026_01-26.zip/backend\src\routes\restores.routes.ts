import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { pipeline } from 'node:stream/promises';
import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { env } from '../config/env';
import { getDatabase } from '../db/sqlite';
import { authenticateRequest, requirePermission } from '../security/auth';
import { executeRestoreSchema, resolveSafeBackupPath, resolveSafeFolderDir } from '../security/sanitizer';
import { getDatabaseAdapter } from '../adapters/registry';
import { getDecryptedConnection } from '../services/connections.service';
import { runQuickCommand, runTrackedExecution } from '../services/runner.service';
import { downloadFileFromSmb, listSmbDirectory } from '../services/smb.service';

const ALLOWED_EXTENSIONS = new Set(['.sql', '.tar', '.backup', '.dump', '.gz', '.archive', '.bak', '.dmp', '.json', '.fbk']);

/**
 * Registra as rotas de restauração (`psql` e `pg_restore`), upload de arquivos,
 * listagem de arquivos no servidor e inspeção prévia de índice (`--list`).
 *
 * @example
 * app.register(restoresRoutes, { prefix: '/api/restores' });
 */
export async function restoresRoutes(app: FastifyInstance): Promise<void> {
  app.addHook('preHandler', authenticateRequest);

  app.get('/files', { preHandler: [requirePermission('restore:read', 'restore:execute', 'schedules:read', 'schedules:manage', 'jobs:read')] }, async (request, reply) => {
    const query = request.query as { folder?: string };
    const folder = query.folder || 'backups';

    if (folder.startsWith('share:')) {
      const [, shareId, ...restParts] = folder.split(':');
      const subPath = restParts.join(':');
      try {
        const listed = await listSmbDirectory(shareId, subPath);
        return {
          files: listed.files.map((f) => ({
            name: f.name,
            isDirectory: false,
            sizeBytes: f.sizeBytes,
            modifiedAt: new Date().toISOString()
          }))
        };
      } catch (err) {
        return reply.status(400).send({ error: (err as Error).message });
      }
    }

    const folderDir = resolveSafeFolderDir(folder);
    if (!fs.existsSync(folderDir)) {
      return { files: [] };
    }

    const entries = fs.readdirSync(folderDir, { withFileTypes: true });
    const files = entries
      .filter((entry) => !entry.name.startsWith('.'))
      .map((entry) => {
        const fullPath = path.join(folderDir, entry.name);
        const stat = fs.statSync(fullPath);
        return {
          name: entry.name,
          isDirectory: entry.isDirectory(),
          sizeBytes: stat.size,
          modifiedAt: stat.mtime.toISOString()
        };
      })
      .sort((a, b) => b.modifiedAt.localeCompare(a.modifiedAt));

    return { files };
  });

  app.post('/upload', { preHandler: [requirePermission('restore:execute')] }, async (request, reply) => {
    const query = request.query as { folder?: string };
    const file = await request.file();
    if (!file) {
      return reply.status(400).send({ error: 'Nenhum arquivo enviado.' });
    }

    const cleanName = path.basename(file.filename).replace(/[^a-zA-Z0-9._-]/g, '_');
    const ext = path.extname(cleanName).toLowerCase();

    if (!ALLOWED_EXTENSIONS.has(ext)) {
      return reply.status(400).send({
        error: 'Extensão não permitida. Use .sql, .tar, .backup, .dump, .gz, .bak, .dmp, .json ou .fbk.'
      });
    }

    const targetPath = resolveSafeBackupPath(cleanName, query.folder || 'backups');
    await pipeline(file.file, fs.createWriteStream(targetPath));

    return reply.status(201).send({
      fileName: cleanName,
      sizeBytes: fs.statSync(targetPath).size
    });
  });

  app.post('/inspect', { preHandler: [requirePermission('restore:read', 'restore:execute')] }, async (request, reply) => {
    const bodySchema = z.object({
      fileName: z.string().min(1),
      sourceFolder: z.string().optional().default('backups')
    });
    const parsed = bodySchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Nome do arquivo é obrigatório.' });
    }

    try {
      const safePath = resolveSafeBackupPath(parsed.data.fileName, parsed.data.sourceFolder);
      if (!fs.existsSync(safePath)) {
        return reply.status(404).send({ error: 'Arquivo de backup não encontrado.' });
      }

      const adapter = getDatabaseAdapter('postgresql');
      if (!adapter.buildInspectCommand) {
        return reply.status(400).send({ error: 'Inspeção --list não suportada para este tipo.' });
      }
      const cmd = adapter.buildInspectCommand(safePath);
      const result = await runQuickCommand(cmd);

      if (result.exitCode !== 0) {
        return reply.status(400).send({
          error: 'Não foi possível inspecionar o arquivo (verifique se é formato Custom/Tar/Directory).',
          details: result.stderr
        });
      }

      const items = result.stdout.split(/\r?\n/).filter((line) => line && !line.startsWith(';'));
      return reply.send({ totalItems: items.length, toc: result.stdout });
    } catch (err) {
      return reply.status(400).send({ error: (err as Error).message });
    }
  });

  app.post('/execute', { preHandler: [requirePermission('restore:execute')] }, async (request, reply) => {
    const parsed = executeRestoreSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Parâmetros inválidos.', details: parsed.error.flatten() });
    }

    try {
      const isSmb = parsed.data.sourceFolder.startsWith('share:');
      let safePath: string;
      let tempSmbFile: string | null = null;

      if (isSmb) {
        const [, shareId, ...restParts] = parsed.data.sourceFolder.split(':');
        const subPath = restParts.join(':');
        const cleanFile = path.basename(parsed.data.fileName);
        tempSmbFile = path.join(env.BACKUP_DIR, `_tmp_smb_${crypto.randomUUID()}_${cleanFile}`);
        await downloadFileFromSmb(shareId, subPath, cleanFile, tempSmbFile);
        safePath = tempSmbFile;
      } else {
        safePath = resolveSafeBackupPath(parsed.data.fileName, parsed.data.sourceFolder);
        if (!fs.existsSync(safePath)) {
          return reply.status(404).send({ error: 'Arquivo de backup não encontrado.' });
        }
      }

      const { descriptor, password } = getDecryptedConnection(parsed.data.targetConnectionId);
      const adapter = getDatabaseAdapter(descriptor.engine);

      // Cria o banco automaticamente antes de restaurar caso ainda não exista (para motores que suportam)
      if (parsed.data.createDatabaseIfNotExists && !parsed.data.createFlag && adapter.buildCreateDatabaseCommand) {
        const listCmd = adapter.buildListDatabasesCommand(descriptor, password);
        const listRes = await runQuickCommand(listCmd);
        const existingDbs = listRes.exitCode === 0
          ? listRes.stdout.split(/\r?\n/).map((l) => l.trim()).filter(Boolean)
          : [];

        if (!existingDbs.includes(parsed.data.targetDatabase)) {
          const createCmd = adapter.buildCreateDatabaseCommand(
            descriptor,
            password,
            parsed.data.targetDatabase
          );
          const createRes = await runQuickCommand(createCmd);
          if (createRes.exitCode !== 0) {
            if (tempSmbFile && fs.existsSync(tempSmbFile)) fs.rmSync(tempSmbFile, { force: true });
            return reply.status(400).send({
              error: `Falha ao criar banco '${parsed.data.targetDatabase}' no destino.`,
              details: createRes.stderr
            });
          }
        }
      }

      const cmd = adapter.buildRestoreCommand(descriptor, password, parsed.data, safePath);
      const executionId = crypto.randomUUID();
      const db = getDatabase();

      db.prepare(`
        INSERT INTO executions (id, type, target_connection_id, database_name, status, command_preview, file_path)
        VALUES (?, 'restore', ?, ?, 'running', ?, ?)
      `).run(executionId, descriptor.id, parsed.data.targetDatabase, cmd.preview, parsed.data.fileName);

      void runTrackedExecution(executionId, cmd).then(() => {
        if (tempSmbFile && fs.existsSync(tempSmbFile)) {
          fs.rmSync(tempSmbFile, { force: true });
        }
      });

      return reply.status(202).send({
        executionId,
        commandPreview: cmd.preview,
        status: 'running'
      });
    } catch (err) {
      return reply.status(404).send({ error: (err as Error).message });
    }
  });

  // Executa diretamente um perfil de restauração salvo (suporta pegar o último backup por data/hora)
  app.post<{ Params: { id: string } }>('/profiles/:id/execute', { preHandler: [requirePermission('restore:execute')] }, async (request, reply) => {
    const db = getDatabase();
    const rp = db
      .prepare('SELECT * FROM restore_profiles WHERE id = ?')
      .get(request.params.id) as {
        id: string;
        name: string;
        source_folder: string;
        source_connection_id: string | null;
        source_database: string | null;
        use_latest_backup: number;
        file_name: string | null;
        target_connection_id: string;
        target_database: string;
        create_database_if_not_exists: number;
        restore_tool: 'pg_restore' | 'psql';
        options_json: string;
      } | undefined;

    if (!rp) {
      return reply.status(404).send({ error: 'Perfil de restauração não encontrado.' });
    }

    let resolvedPath = '';
    if (rp.use_latest_backup === 1) {
      const lastExec = db
        .prepare(`
          SELECT file_path FROM executions
          WHERE type = 'backup' AND status = 'success' AND file_path IS NOT NULL
            AND (? IS NULL OR source_connection_id = ?)
            AND (? IS NULL OR database_name = ?)
          ORDER BY started_at DESC
          LIMIT 1
        `)
        .get(rp.source_connection_id, rp.source_connection_id, rp.source_database, rp.source_database) as
        | { file_path: string }
        | undefined;

      if (!lastExec) {
        return reply.status(404).send({
          error: `Nenhum backup bem-sucedido encontrado para a base '${rp.source_database || ''}'.`
        });
      }
      resolvedPath = lastExec.file_path;
    } else if (rp.file_name) {
      resolvedPath = resolveSafeBackupPath(rp.file_name, rp.source_folder || 'backups');
    }

    if (!resolvedPath || !fs.existsSync(resolvedPath)) {
      return reply.status(404).send({ error: 'Arquivo de backup não encontrado no disco para este perfil.' });
    }

    const { descriptor, password } = getDecryptedConnection(rp.target_connection_id);
    const adapter = getDatabaseAdapter(descriptor.engine);
    const opts = JSON.parse(rp.options_json) as Record<string, unknown>;

    if (rp.create_database_if_not_exists === 1 && adapter.buildCreateDatabaseCommand) {
      const listCmd = adapter.buildListDatabasesCommand(descriptor, password);
      const listRes = await runQuickCommand(listCmd);
      const existingDbs = listRes.exitCode === 0
        ? listRes.stdout.split(/\r?\n/).map((l) => l.trim()).filter(Boolean)
        : [];
      if (!existingDbs.includes(rp.target_database)) {
        const createCmd = adapter.buildCreateDatabaseCommand(descriptor, password, rp.target_database);
        const createRes = await runQuickCommand(createCmd);
        if (createRes.exitCode !== 0) {
          return reply.status(400).send({ error: createRes.stderr });
        }
      }
    }

    const tool = resolvedPath.toLowerCase().endsWith('.sql') ? 'psql' : rp.restore_tool;
    const cmd = adapter.buildRestoreCommand(
      descriptor,
      password,
      { ...opts, targetDatabase: rp.target_database, restoreTool: tool },
      resolvedPath
    );

    const executionId = crypto.randomUUID();
    db.prepare(`
      INSERT INTO executions (id, type, target_connection_id, database_name, status, command_preview, file_path)
      VALUES (?, 'restore', ?, ?, 'running', ?, ?)
    `).run(executionId, descriptor.id, rp.target_database, cmd.preview, resolvedPath);

    void runTrackedExecution(executionId, cmd);
    return reply.status(202).send({ executionId, commandPreview: cmd.preview, status: 'running' });
  });

  // Perfis de Restauração salvos
  app.get('/profiles', { preHandler: [requirePermission('restore:read', 'restore:execute', 'schedules:read', 'schedules:manage', 'jobs:read')] }, async () => {
    const db = getDatabase();
    const profiles = db
      .prepare(`
        SELECT rp.*, tc.name as target_connection_name, tc.engine as target_engine
        FROM restore_profiles rp
        JOIN connections tc ON tc.id = rp.target_connection_id
        ORDER BY rp.name ASC
      `)
      .all();

    return { profiles };
  });

  app.post('/profiles', { preHandler: [requirePermission('restore:create', 'restore:execute')] }, async (request, reply) => {
    const schema = z.object({
      name: z.string().trim().min(2, 'Nome do perfil é obrigatório.').max(100),
      description: z.string().trim().max(300).optional(),
      sourceFolder: z.string().trim().max(120).default('backups'),
      sourceConnectionId: z.string().uuid().optional().nullable(),
      sourceDatabase: z.string().trim().max(260).optional().nullable(),
      useLatestBackup: z.boolean().default(false),
      fileName: z.string().trim().max(255).optional().nullable(),
      targetConnectionId: z.string().uuid(),
      targetDatabase: z.string().trim().min(1).max(260),
      createDatabaseIfNotExists: z.boolean().default(true),
      restoreTool: z.enum(['pg_restore', 'psql']).default('pg_restore'),
      options: z.record(z.unknown()).default({})
    });

    const parsed = schema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: parsed.error.issues[0]?.message || 'Dados inválidos.' });
    }

    const id = crypto.randomUUID();
    const db = getDatabase();
    db.prepare(`
      INSERT INTO restore_profiles (
        id, name, description, source_folder, source_connection_id, source_database,
        use_latest_backup, file_name, target_connection_id, target_database,
        create_database_if_not_exists, restore_tool, options_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      parsed.data.name,
      parsed.data.description ?? null,
      parsed.data.sourceFolder,
      parsed.data.sourceConnectionId ?? null,
      parsed.data.sourceDatabase ?? null,
      parsed.data.useLatestBackup ? 1 : 0,
      parsed.data.fileName ?? null,
      parsed.data.targetConnectionId,
      parsed.data.targetDatabase,
      parsed.data.createDatabaseIfNotExists ? 1 : 0,
      parsed.data.restoreTool,
      JSON.stringify(parsed.data.options)
    );

    return reply.status(201).send({ id, ...parsed.data });
  });

  app.delete<{ Params: { id: string } }>('/profiles/:id', { preHandler: [requirePermission('restore:delete', 'restore:execute')] }, async (request, reply) => {
    const db = getDatabase();
    const res = db.prepare('DELETE FROM restore_profiles WHERE id = ?').run(request.params.id);
    if (res.changes === 0) {
      return reply.status(404).send({ error: 'Perfil de restauração não encontrado.' });
    }
    return reply.send({ deleted: true });
  });
}
