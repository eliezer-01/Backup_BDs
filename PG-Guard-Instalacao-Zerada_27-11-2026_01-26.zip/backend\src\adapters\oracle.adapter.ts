import {
  formatCommandPreview,
  resolveRuntimeHost,
  type BuiltCommand,
  type ConnectionDescriptor,
  type DatabaseAdapter
} from './base.adapter';

/**
 * Adaptador modular para Oracle Database utilizando `sqlplus`, `expdp` e `impdp`.
 * Requer o Oracle Instant Client montado no container caso utilize execução nativa.
 *
 * @example
 * const adapter = new OracleAdapter();
 */
export class OracleAdapter implements DatabaseAdapter {
  readonly engine = 'oracle';

  private buildConnString(conn: ConnectionDescriptor, password: string, mask = false): string {
    const pwd = mask ? '***' : password;
    const service = conn.defaultDatabase || 'ORCL';
    return `${conn.username}/${pwd}@//${resolveRuntimeHost(conn.host)}:${conn.port}/${service}`;
  }

  buildTestConnectionCommand(conn: ConnectionDescriptor, password: string): BuiltCommand {
    const args = ['-S', this.buildConnString(conn, password)];
    const previewArgs = ['-S', this.buildConnString(conn, password, true)];
    return {
      binary: 'sqlplus',
      args,
      envVars: {},
      preview: formatCommandPreview('sqlplus', previewArgs)
    };
  }

  buildListDatabasesCommand(conn: ConnectionDescriptor, password: string): BuiltCommand {
    const service = conn.defaultDatabase || 'ORCL';
    return {
      binary: 'node',
      args: ['-e', `console.log(${JSON.stringify(service)})`],
      envVars: {},
      preview: `oracle://${conn.username}@${resolveRuntimeHost(conn.host)}:${conn.port}/${service}`
    };
  }

  buildBackupCommand(
    conn: ConnectionDescriptor,
    password: string,
    rawParams: Record<string, unknown>,
    outputPath: string
  ): BuiltCommand {
    const schema = (rawParams.databaseName as string) || conn.username;
    const args = [
      this.buildConnString(conn, password),
      `SCHEMAS=${schema}`,
      `DUMPFILE=${outputPath}`
    ];
    const previewArgs = [
      this.buildConnString(conn, password, true),
      `SCHEMAS=${schema}`,
      `DUMPFILE=${outputPath}`
    ];
    return {
      binary: 'expdp',
      args,
      envVars: {},
      preview: formatCommandPreview('expdp', previewArgs)
    };
  }

  buildRestoreCommand(
    conn: ConnectionDescriptor,
    password: string,
    rawParams: Record<string, unknown>,
    inputPath: string
  ): BuiltCommand {
    const targetSchema = (rawParams.targetDatabase as string) || conn.username;
    const args = [
      this.buildConnString(conn, password),
      `REMAP_SCHEMA=${conn.username}:${targetSchema}`,
      `DUMPFILE=${inputPath}`
    ];
    const previewArgs = [
      this.buildConnString(conn, password, true),
      `REMAP_SCHEMA=${conn.username}:${targetSchema}`,
      `DUMPFILE=${inputPath}`
    ];
    return {
      binary: 'impdp',
      args,
      envVars: {},
      preview: formatCommandPreview('impdp', previewArgs)
    };
  }
}
