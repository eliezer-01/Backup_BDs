import { useEffect, useState } from 'react';
import { BookmarkPlus, FolderOpen, Play, Terminal } from 'lucide-react';
import { apiRequest } from '../services/api';
import { Button, Card, Input, Select, Toggle } from '../components/ui';
import { LiveConsole } from '../components/LiveConsole';
import { FolderBrowserModal } from '../components/FolderBrowserModal';
import type { Connection } from './ConnectionsPage';

/**
 * Módulo visual de Backup (`pg_dump` e `pg_dumpall`) com Preview do Comando em tempo real,
 * filtros de objetos, paralelismo e criação de perfis reutilizáveis.
 *
 * @example
 * <BackupPage />
 */
export function BackupPage() {
  const [connections, setConnections] = useState<Connection[]>([]);
  const [databases, setDatabases] = useState<string[]>([]);
  const [connectionId, setConnectionId] = useState('');
  const [databaseName, setDatabaseName] = useState('');
  const [dumpType, setDumpType] = useState<'pg_dump' | 'pg_dumpall'>('pg_dump');

  const [format, setFormat] = useState<'custom' | 'tar' | 'plain' | 'directory'>('custom');
  const [jobs, setJobs] = useState(2);
  const [includeTablesText, setIncludeTablesText] = useState('');
  const [excludeSchemasText, setExcludeSchemasText] = useState('');
  const [includeBlobs, setIncludeBlobs] = useState(false);
  const [verbose, setVerbose] = useState(true);
  const [columnInserts, setColumnInserts] = useState(false);
  const [globalScope, setGlobalScope] = useState<'all' | 'globals-only' | 'roles-only' | 'tablespaces-only'>('globals-only');

  const [preview, setPreview] = useState('');
  const [activeExecId, setActiveExecId] = useState<string | null>(null);
  const [profileName, setProfileName] = useState('');
  const [targetFolder, setTargetFolder] = useState('backups');
  const [availableFolders, setAvailableFolders] = useState<string[]>(['backups', 'custom']);
  const [showFolderBrowser, setShowFolderBrowser] = useState(false);
  const [feedback, setFeedback] = useState('');

  const selectedConn = connections.find((c) => c.id === connectionId);
  const engine = selectedConn?.engine || 'postgresql';

  useEffect(() => {
    void apiRequest<{ connections: Connection[] }>('/api/connections').then((res) => {
      setConnections(res.connections);
      if (res.connections.length > 0) {
        setConnectionId(res.connections[0].id);
      }
    });
    void apiRequest<{ folders: string[] }>('/api/backups/folders')
      .then((res) => setAvailableFolders(res.folders))
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    if (!connectionId) return;
    void apiRequest<{ databases: string[] }>(`/api/connections/${connectionId}/databases`)
      .then((res) => {
        setDatabases(res.databases);
        if (res.databases.length > 0) setDatabaseName(res.databases[0]);
      })
      .catch(() => setDatabases([]));
  }, [connectionId]);

  const buildPayload = () => ({
    connectionId,
    databaseName: dumpType === 'pg_dump' ? databaseName : undefined,
    dumpType,
    targetFolder: targetFolder.trim() || 'backups',
    options: {
      format,
      jobs: format === 'directory' ? Number(jobs) : undefined,
      includeTables: includeTablesText.split(',').map((s) => s.trim()).filter(Boolean),
      excludeSchemas: excludeSchemasText.split(',').map((s) => s.trim()).filter(Boolean),
      includeBlobs,
      verbose,
      columnInserts: format === 'plain' ? columnInserts : false,
      globalScope
    }
  });

  useEffect(() => {
    if (!connectionId) return;
    void apiRequest<{ commandPreview: string }>('/api/backups/preview', {
      method: 'POST',
      body: JSON.stringify(buildPayload())
    })
      .then((res) => setPreview(res.commandPreview))
      .catch(() => setPreview(''));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    connectionId,
    databaseName,
    dumpType,
    format,
    jobs,
    includeTablesText,
    excludeSchemasText,
    includeBlobs,
    verbose,
    columnInserts,
    globalScope,
    targetFolder
  ]);

  async function handleExecuteBackup() {
    setFeedback('');
    try {
      const res = await apiRequest<{ executionId: string; fileName: string }>('/api/backups/execute', {
        method: 'POST',
        body: JSON.stringify(buildPayload())
      });
      setActiveExecId(res.executionId);
      setFeedback(`Backup iniciado em segundo plano (${res.fileName}). Acompanhe o console abaixo.`);
    } catch (err) {
      setFeedback((err as Error).message);
    }
  }

  async function handleSaveProfile() {
    if (!profileName.trim()) return;
    try {
      await apiRequest('/api/backups/profiles', {
        method: 'POST',
        body: JSON.stringify({
          name: profileName.trim(),
          ...buildPayload()
        })
      });
      setProfileName('');
      setFeedback('Perfil de backup salvo! Agora você pode agendá-lo na aba Agendamentos.');
    } catch (err) {
      setFeedback((err as Error).message);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Módulo de Backup</h2>
        <p className="text-sm text-muted-foreground">
          <strong>pg_dump</strong> exporta 1 banco completo (tabelas, dados, schemas, triggers, functions e views) ou apenas 1 tabela via filtro <code>-t</code>.{' '}
          <strong>pg_dumpall</strong> exporta configurações globais do servidor inteiro (usuários/roles e tablespaces).
        </p>
      </div>

      <Card className="space-y-5 p-5">
        <div className="grid gap-4 md:grid-cols-3">
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">Servidor de Origem</label>
            <Select value={connectionId} onChange={(e) => setConnectionId(e.target.value)}>
              {connections.map((c) => (
                <option key={c.id} value={c.id}>{c.name} [{c.engine}] ({c.host})</option>
              ))}
            </Select>
          </div>

          {engine === 'postgresql' ? (
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Tipo de Utilitário</label>
              <Select value={dumpType} onChange={(e) => setDumpType(e.target.value as 'pg_dump' | 'pg_dumpall')}>
                <option value="pg_dump">Banco Único (pg_dump)</option>
                <option value="pg_dumpall">Cluster Global (pg_dumpall)</option>
              </Select>
            </div>
          ) : (
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Motor Detectado</label>
              <div className="rounded-lg border border-border bg-muted/50 px-3 py-2 text-sm font-medium uppercase">
                {engine}
              </div>
            </div>
          )}

          {engine === 'rabbitmq' ? (
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Escopo RabbitMQ</label>
              <div className="rounded-lg border border-border bg-muted/50 px-3 py-2 text-xs text-muted-foreground">
                Exporta todas as queues, exchanges, bindings e vhosts (.json)
              </div>
            </div>
          ) : dumpType === 'pg_dump' || engine !== 'postgresql' ? (
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Banco de Dados</label>
              <Select value={databaseName} onChange={(e) => setDatabaseName(e.target.value)}>
                {databases.map((db) => (
                  <option key={db} value={db}>{db}</option>
                ))}
              </Select>
            </div>
          ) : (
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Escopo Global</label>
              <Select value={globalScope} onChange={(e) => setGlobalScope(e.target.value as typeof globalScope)}>
                <option value="globals-only">Apenas Globais (--globals-only)</option>
                <option value="roles-only">Apenas Roles/Usuários (--roles-only)</option>
                <option value="tablespaces-only">Apenas Tablespaces (--tablespaces-only)</option>
                <option value="all">Cluster Completo</option>
              </Select>
            </div>
          )}
        </div>

        {engine === 'postgresql' && dumpType === 'pg_dump' && (
          <>
            <div className="grid gap-4 md:grid-cols-3">
              <div>
                <label className="mb-1 block text-xs font-medium text-muted-foreground">Formato de Saída (-F)</label>
                <Select value={format} onChange={(e) => setFormat(e.target.value as typeof format)}>
                  <option value="custom">Custom (-Fc) — Recomendado</option>
                  <option value="tar">Tar (-Ft)</option>
                  <option value="plain">Plain SQL (-Fp)</option>
                  <option value="directory">Directory (-Fd)</option>
                </Select>
              </div>

              <div>
                <label className="mb-1 block text-xs font-medium text-muted-foreground">
                  Paralelismo (-j) {format !== 'directory' && '(Disponível em Directory -Fd)'}
                </label>
                <Input
                  type="number"
                  min={1}
                  max={16}
                  disabled={format !== 'directory'}
                  value={jobs}
                  onChange={(e) => setJobs(Number(e.target.value))}
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-medium text-muted-foreground">
                  Incluir Tabelas (-t, separadas por vírgula)
                </label>
                <Input
                  value={includeTablesText}
                  onChange={(e) => setIncludeTablesText(e.target.value)}
                  placeholder="Ex: *.pagar*, public.clientes"
                />
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-medium text-muted-foreground">
                  Excluir Schemas (-N, separados por vírgula)
                </label>
                <Input
                  value={excludeSchemasText}
                  onChange={(e) => setExcludeSchemasText(e.target.value)}
                  placeholder="Ex: auditoria, logs_temp"
                />
              </div>
            </div>

            <div className="grid gap-3 md:grid-cols-3">
              <Toggle
                checked={includeBlobs}
                onChange={setIncludeBlobs}
                label="Incluir Blobs (-b)"
                hint="Exporta Large Objects junto ao dump"
              />
              <Toggle
                checked={verbose}
                onChange={setVerbose}
                label="Modo Verbose (-v)"
                hint="Exibe progresso detalhado no console"
              />
              {format === 'plain' && (
                <Toggle
                  checked={columnInserts}
                  onChange={setColumnInserts}
                  label="Usar --column-inserts"
                  hint="Gera comandos INSERT com nomes das colunas"
                />
              )}
            </div>
          </>
        )}

        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">
              Pasta de Destino (<code>backups</code>, <code>custom</code> ou subpasta)
            </label>
            <div className="flex gap-2">
              <Input
                list="backup-folders-list"
                value={targetFolder}
                onChange={(e) => setTargetFolder(e.target.value)}
                placeholder="backups"
              />
              <Button type="button" variant="outline" onClick={() => setShowFolderBrowser(true)}>
                <FolderOpen className="h-4 w-4" />
                Browser
              </Button>
            </div>
            <datalist id="backup-folders-list">
              {availableFolders.map((f) => (
                <option key={f} value={f} />
              ))}
            </datalist>
          </div>
        </div>

        <FolderBrowserModal
          open={showFolderBrowser}
          initialPath={targetFolder}
          onClose={() => setShowFolderBrowser(false)}
          onSelect={(folder) => setTargetFolder(folder)}
        />

        <div className="rounded-lg border border-border bg-slate-950 p-3 text-xs text-emerald-400">
          <div className="mb-1 flex items-center gap-1.5 font-semibold text-slate-400">
            <Terminal className="h-3.5 w-3.5" />
            Preview do Comando (PGPASSWORD isolada em variável de ambiente):
          </div>
          <code className="break-all">{preview || 'Selecione uma conexão para visualizar o comando...'}</code>
        </div>

        {feedback && (
          <div className="rounded-lg bg-primary/10 p-3 text-xs text-primary">{feedback}</div>
        )}

        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border pt-4">
          <div className="flex items-center gap-2">
            <Input
              className="w-60"
              value={profileName}
              onChange={(e) => setProfileName(e.target.value)}
              placeholder="Nome do perfil (para agendar)"
            />
            <Button variant="outline" onClick={() => void handleSaveProfile()} disabled={!profileName.trim() || !connectionId}>
              <BookmarkPlus className="h-4 w-4" />
              Salvar Perfil
            </Button>
          </div>

          <Button onClick={() => void handleExecuteBackup()} disabled={!connectionId}>
            <Play className="h-4 w-4" />
            Executar Backup Agora
          </Button>
        </div>
      </Card>

      <LiveConsole filterExecutionId={activeExecId} />
    </div>
  );
}
