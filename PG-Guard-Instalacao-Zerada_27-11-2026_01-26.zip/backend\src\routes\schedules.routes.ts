import crypto from 'node:crypto';
import type { FastifyInstance } from 'fastify';
import cron from 'node-cron';
import { z } from 'zod';
import { getDatabase } from '../db/sqlite';
import { authenticateRequest, requirePermission } from '../security/auth';
import {
  computeNextRun,
  executeScheduledJob,
  registerScheduleTask,
  unregisterScheduleTask
} from '../services/scheduler.service';

const scheduleInputSchema = z.object({
  scheduleType: z.enum(['backup', 'restore']).default('backup'),
  profileId: z.string().uuid('ID do perfil de backup inválido.').optional().nullable(),
  restoreProfileId: z.string().uuid('ID do perfil de restauração inválido.').optional().nullable(),
  cronExpression: z
    .string()
    .trim()
    .refine((expr) => cron.validate(expr), 'Expressão Cron inválida (use 5 campos, ex: 0 2 * * *).'),
  isActive: z.boolean().default(true),
  retentionDaily: z.coerce.number().int().min(1).max(365).default(7),
  retentionWeekly: z.coerce.number().int().min(0).max(104).default(4),
  retentionMonthly: z.coerce.number().int().min(0).max(60).default(3),
  notifyEmailTo: z.string().trim().email('E-mail de alerta inválido.').optional().or(z.literal('')),
  notifyOnSuccess: z.boolean().default(true),
  notifyOnError: z.boolean().default(true)
});

/**
 * Registra as rotas de gerenciamento de agendamentos Cron e políticas de retenção.
 *
 * @example
 * app.register(schedulesRoutes, { prefix: '/api/schedules' });
 */
export async function schedulesRoutes(app: FastifyInstance): Promise<void> {
  app.addHook('preHandler', authenticateRequest);

  app.get('/', { preHandler: [requirePermission('schedules:read', 'schedules:manage')] }, async () => {
    const db = getDatabase();
    const schedules = db
      .prepare(`
        SELECT
          s.*,
          COALESCE(p.name, rp.name) as profile_name,
          COALESCE(p.database_name, rp.target_database) as database_name,
          COALESCE(p.dump_type, rp.restore_tool) as dump_type,
          COALESCE(c.name, tc.name) as connection_name
        FROM schedules s
        LEFT JOIN backup_profiles p ON p.id = s.profile_id
        LEFT JOIN connections c ON c.id = p.connection_id
        LEFT JOIN restore_profiles rp ON rp.id = s.restore_profile_id
        LEFT JOIN connections tc ON tc.id = rp.target_connection_id
        ORDER BY s.created_at DESC
      `)
      .all();

    return { schedules };
  });

  app.post('/', { preHandler: [requirePermission('schedules:create', 'schedules:manage')] }, async (request, reply) => {
    const parsed = scheduleInputSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Dados do agendamento inválidos.', details: parsed.error.flatten() });
    }

    const db = getDatabase();
    if (parsed.data.scheduleType === 'restore') {
      if (!parsed.data.restoreProfileId) {
        return reply.status(400).send({ error: 'Selecione um perfil de restauração.' });
      }
      const rp = db.prepare('SELECT id FROM restore_profiles WHERE id = ?').get(parsed.data.restoreProfileId);
      if (!rp) return reply.status(404).send({ error: 'Perfil de restauração não encontrado.' });
    } else {
      if (!parsed.data.profileId) {
        return reply.status(400).send({ error: 'Selecione um perfil de backup.' });
      }
      const profile = db.prepare('SELECT id FROM backup_profiles WHERE id = ?').get(parsed.data.profileId);
      if (!profile) return reply.status(404).send({ error: 'Perfil de backup não encontrado.' });
    }

    const id = crypto.randomUUID();
    const nextRun = parsed.data.isActive ? computeNextRun(parsed.data.cronExpression) : null;

    db.prepare(`
      INSERT INTO schedules (
        id, schedule_type, profile_id, restore_profile_id, cron_expression, is_active,
        retention_daily, retention_weekly, retention_monthly,
        notify_email_to, notify_on_success, notify_on_error, next_run_at
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      parsed.data.scheduleType,
      parsed.data.scheduleType === 'backup' ? (parsed.data.profileId ?? null) : null,
      parsed.data.scheduleType === 'restore' ? (parsed.data.restoreProfileId ?? null) : null,
      parsed.data.cronExpression,
      parsed.data.isActive ? 1 : 0,
      parsed.data.retentionDaily,
      parsed.data.retentionWeekly,
      parsed.data.retentionMonthly,
      parsed.data.notifyEmailTo || null,
      parsed.data.notifyOnSuccess ? 1 : 0,
      parsed.data.notifyOnError ? 1 : 0,
      nextRun
    );

    registerScheduleTask(id, parsed.data.cronExpression, parsed.data.isActive);

    return reply.status(201).send({ id, ...parsed.data, nextRunAt: nextRun });
  });

  app.put<{ Params: { id: string } }>('/:id', { preHandler: [requirePermission('schedules:update', 'schedules:manage')] }, async (request, reply) => {
    const parsed = scheduleInputSchema.partial().safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Dados inválidos.', details: parsed.error.flatten() });
    }

    const db = getDatabase();
    const existing = db
      .prepare('SELECT * FROM schedules WHERE id = ?')
      .get(request.params.id) as {
        id: string;
        cron_expression: string;
        is_active: number;
        retention_daily: number;
        retention_weekly: number;
        retention_monthly: number;
      } | undefined;

    if (!existing) {
      return reply.status(404).send({ error: 'Agendamento não encontrado.' });
    }

    const cronExpr = parsed.data.cronExpression ?? existing.cron_expression;
    const isActive = parsed.data.isActive ?? existing.is_active === 1;
    const nextRun = isActive ? computeNextRun(cronExpr) : null;

    db.prepare(`
      UPDATE schedules
      SET cron_expression = ?, is_active = ?, retention_daily = ?, retention_weekly = ?, retention_monthly = ?, next_run_at = ?, updated_at = datetime('now')
      WHERE id = ?
    `).run(
      cronExpr,
      isActive ? 1 : 0,
      parsed.data.retentionDaily ?? existing.retention_daily,
      parsed.data.retentionWeekly ?? existing.retention_weekly,
      parsed.data.retentionMonthly ?? existing.retention_monthly,
      nextRun,
      request.params.id
    );

    registerScheduleTask(request.params.id, cronExpr, isActive);

    return reply.send({ updated: true, nextRunAt: nextRun });
  });

  app.post<{ Params: { id: string } }>('/:id/run-now', { preHandler: [requirePermission('schedules:execute', 'schedules:manage')] }, async (request, reply) => {
    const executionId = await executeScheduledJob(request.params.id);
    if (!executionId) {
      return reply.status(404).send({ error: 'Agendamento não encontrado.' });
    }
    return reply.status(202).send({ executionId, status: 'running' });
  });

  app.delete<{ Params: { id: string } }>('/:id', { preHandler: [requirePermission('schedules:delete', 'schedules:manage')] }, async (request, reply) => {
    const db = getDatabase();
    unregisterScheduleTask(request.params.id);
    const res = db.prepare('DELETE FROM schedules WHERE id = ?').run(request.params.id);
    if (res.changes === 0) {
      return reply.status(404).send({ error: 'Agendamento não encontrado.' });
    }
    return reply.send({ deleted: true });
  });
}
