import fs from 'node:fs';
import path from 'node:path';
import { z } from 'zod';
import { env } from '../config/env';

/**
 * Expressão regular segura para identificadores de banco, usuário, schema e padrões de tabela.
 * Bloqueia caracteres perigosos de shell como `;`, `&`, `|`, `$`, `` ` ``, `>`, `<`, etc.
 */
const SAFE_IDENTIFIER_REGEX = /^[a-zA-Z0-9_.*-]+$/;

/**
 * Expressão regular segura para nomes/caminhos de banco (inclui Firebird `.fdb` com `:` e `/` ou `\`).
 */
const SAFE_DB_NAME_REGEX = /^[a-zA-Z0-9_.*:/\\ -]+$/;

/**
 * Expressão regular segura para hostnames e endereços IPv4/IPv6.
 */
const SAFE_HOST_REGEX = /^[a-zA-Z0-9.:_-]+$/;

/**
 * Esquema Zod para validação de cadastro/edição de conexões.
 *
 * @example
 * const dados = connectionInputSchema.parse(request.body);
 */
export const SUPPORTED_ENGINES = [
  'postgresql',
  'mysql',
  'mariadb',
  'sqlserver',
  'oracle',
  'mongodb',
  'rabbitmq',
  'firebird'
] as const;

export const connectionInputSchema = z.object({
  name: z.string().trim().min(2, 'Nome da conexão deve ter ao menos 2 caracteres').max(100),
  engine: z.enum(SUPPORTED_ENGINES).default('postgresql'),
  host: z.string().trim().min(1).max(255).regex(SAFE_HOST_REGEX, 'Host contém caracteres inválidos.'),
  port: z.coerce.number().int().min(1).max(65535).default(5432),
  username: z.string().trim().min(1).max(120).regex(SAFE_IDENTIFIER_REGEX, 'Usuário contém caracteres inválidos.'),
  password: z.string().min(1).max(500),
  default_database: z
    .string()
    .trim()
    .min(1)
    .max(260)
    .regex(SAFE_DB_NAME_REGEX, 'Nome/caminho do banco contém caracteres inválidos.')
    .default('postgres'),
  ssl_mode: z.enum(['disable', 'allow', 'prefer', 'require', 'verify-ca', 'verify-full']).default('prefer')
});

/**
 * Esquema Zod para opções de backup via `pg_dump` e `pg_dumpall`.
 *
 * @example
 * const opcoes = backupOptionsSchema.parse({ format: 'custom', verbose: true });
 */
export const backupOptionsSchema = z.object({
  format: z.enum(['custom', 'tar', 'plain', 'directory']).default('custom'),
  jobs: z.coerce.number().int().min(1).max(16).optional(),
  includeTables: z
    .array(z.string().trim().min(1).max(120).regex(SAFE_IDENTIFIER_REGEX, 'Padrão de tabela inválido.'))
    .default([]),
  excludeSchemas: z
    .array(z.string().trim().min(1).max(120).regex(SAFE_IDENTIFIER_REGEX, 'Nome de schema inválido.'))
    .default([]),
  includeBlobs: z.boolean().default(false),
  verbose: z.boolean().default(true),
  columnInserts: z.boolean().default(false),
  // Opções exclusivas do pg_dumpall
  globalScope: z.enum(['all', 'globals-only', 'roles-only', 'tablespaces-only']).default('all')
});

/**
 * Esquema Zod para solicitação de execução de backup.
 */
export const executeBackupSchema = z.object({
  connectionId: z.string().uuid('ID de conexão inválido.'),
  databaseName: z
    .string()
    .trim()
    .min(1)
    .max(260)
    .regex(SAFE_DB_NAME_REGEX, 'Nome do banco inválido.')
    .optional(),
  dumpType: z.enum(['pg_dump', 'pg_dumpall']).default('pg_dump'),
  options: backupOptionsSchema.default({}),
  profileName: z.string().trim().max(100).optional(),
  targetFolder: z.string().trim().max(120).default('backups')
});

/**
 * Esquema Zod para solicitação de restauração (`pg_restore` ou `psql`).
 */
export const executeRestoreSchema = z.object({
  targetConnectionId: z.string().uuid('ID da conexão de destino inválido.'),
  targetDatabase: z
    .string()
    .trim()
    .min(1)
    .max(260)
    .regex(SAFE_DB_NAME_REGEX, 'Nome do banco de destino inválido.'),
  createDatabaseIfNotExists: z.boolean().default(true),
  fileName: z.string().trim().min(1).max(255),
  sourceFolder: z.string().trim().max(120).default('backups'),
  restoreTool: z.enum(['pg_restore', 'psql']).default('pg_restore'),
  // Opções psql
  onErrorStop: z.boolean().default(true),
  // Opções pg_restore
  verbose: z.boolean().default(true),
  clean: z.boolean().default(false),
  noAcl: z.boolean().default(false),
  noOwner: z.boolean().default(false),
  createFlag: z.boolean().default(false),
  section: z.enum(['all', 'pre-data', 'data', 'post-data']).default('all')
});

/**
 * Resolve uma chave de pasta segura (`backups`, `backups/sub`, `custom`, `custom/sub`)
 * garantindo que nunca escape dos diretórios autorizados (`BACKUP_DIR` ou `CUSTOM_BACKUP_DIR`).
 *
 * @example
 * const dir = resolveSafeFolderDir('custom/clientes');
 */
export function resolveSafeFolderDir(folderKey = 'backups'): string {
  const normalized = folderKey.replace(/\\/g, '/').replace(/^\/+|\/+$/g, '') || 'backups';
  const [rootKey, ...rest] = normalized.split('/');

  let baseDir: string;
  if (rootKey === 'custom') {
    baseDir = path.resolve(env.CUSTOM_BACKUP_DIR);
  } else if (rootKey === 'backups') {
    baseDir = path.resolve(env.BACKUP_DIR);
  } else {
    throw new Error('Pasta raiz inválida. Utilize "backups" ou "custom".');
  }

  const cleanSub = rest
    .filter((seg) => seg && seg !== '.' && seg !== '..')
    .map((seg) => seg.replace(/[^a-zA-Z0-9_-]/g, '_'));

  const targetDir = cleanSub.length > 0 ? path.resolve(baseDir, ...cleanSub) : baseDir;

  if (!targetDir.startsWith(baseDir + path.sep) && targetDir !== baseDir) {
    throw new Error('Acesso negado: pasta fora dos diretórios permitidos.');
  }

  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
  }

  return targetDir;
}

/**
 * Resolve e valida um caminho de arquivo dentro de uma pasta segura de backups (`backups` ou `custom`).
 * Previne ataques de Directory Traversal (`../../etc/passwd`).
 *
 * @param fileName Nome do arquivo ou subdiretório relativo.
 * @param folderKey Pasta alvo (`backups`, `custom`, ou subpasta).
 * @example
 * const caminhoSeguro = resolveSafeBackupPath('oficial_2026.backup', 'custom/diario');
 */
export function resolveSafeBackupPath(fileName: string, folderKey = 'backups'): string {
  const cleanName = path.basename(fileName);
  if (!cleanName || cleanName === '.' || cleanName === '..') {
    throw new Error('Nome de arquivo inválido.');
  }

  const baseDir = resolveSafeFolderDir(folderKey);
  const resolved = path.resolve(baseDir, cleanName);

  if (!resolved.startsWith(baseDir + path.sep) && resolved !== baseDir) {
    throw new Error('Acesso negado: caminho fora do diretório de backups.');
  }

  return resolved;
}
