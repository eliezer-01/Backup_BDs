PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS roles (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  permissions_json TEXT NOT NULL,
  is_system INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role_id TEXT,
  is_master INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS connections (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  engine TEXT NOT NULL DEFAULT 'postgresql',
  host TEXT NOT NULL,
  port INTEGER NOT NULL DEFAULT 5432,
  username TEXT NOT NULL,
  password_encrypted TEXT NOT NULL,
  password_iv TEXT NOT NULL,
  password_tag TEXT NOT NULL,
  default_database TEXT NOT NULL DEFAULT 'postgres',
  ssl_mode TEXT NOT NULL DEFAULT 'prefer',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS smtp_settings (
  id TEXT PRIMARY KEY,
  host TEXT NOT NULL,
  port INTEGER NOT NULL DEFAULT 587,
  secure INTEGER NOT NULL DEFAULT 0,
  username TEXT NOT NULL,
  password_encrypted TEXT NOT NULL,
  password_iv TEXT NOT NULL,
  password_tag TEXT NOT NULL,
  from_email TEXT NOT NULL,
  from_name TEXT NOT NULL DEFAULT 'PG Guard Alertas',
  allow_self_signed INTEGER NOT NULL DEFAULT 0,
  subject_success TEXT NOT NULL DEFAULT '[PG Guard] ✅ SUCESSO - {{perfil}} ({{banco}})',
  subject_error TEXT NOT NULL DEFAULT '[PG Guard] ❌ FALHA - {{perfil}} ({{banco}})',
  custom_message TEXT,
  body_fields_json TEXT NOT NULL DEFAULT '{"perfil":true,"conexao":true,"banco":true,"data_hora":true,"duracao":true,"tamanho":true,"arquivo":true,"erro":true}',
  job_email_config_json TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS backup_profiles (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  connection_id TEXT NOT NULL,
  database_name TEXT,
  dump_type TEXT NOT NULL CHECK (dump_type IN ('pg_dump', 'pg_dumpall')),
  options_json TEXT NOT NULL,
  target_folder TEXT NOT NULL DEFAULT 'backups',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (connection_id) REFERENCES connections(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS schedules (
  id TEXT PRIMARY KEY,
  schedule_type TEXT NOT NULL DEFAULT 'backup' CHECK (schedule_type IN ('backup', 'restore')),
  profile_id TEXT,
  restore_profile_id TEXT,
  cron_expression TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  retention_daily INTEGER NOT NULL DEFAULT 7,
  retention_weekly INTEGER NOT NULL DEFAULT 4,
  retention_monthly INTEGER NOT NULL DEFAULT 3,
  notify_email_to TEXT,
  notify_on_success INTEGER NOT NULL DEFAULT 1,
  notify_on_error INTEGER NOT NULL DEFAULT 1,
  last_run_at TEXT,
  next_run_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (profile_id) REFERENCES backup_profiles(id) ON DELETE CASCADE,
  FOREIGN KEY (restore_profile_id) REFERENCES restore_profiles(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS executions (
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL CHECK (type IN ('backup', 'restore')),
  profile_id TEXT,
  source_connection_id TEXT,
  target_connection_id TEXT,
  database_name TEXT,
  status TEXT NOT NULL CHECK (status IN ('running', 'success', 'error')),
  command_preview TEXT NOT NULL,
  file_path TEXT,
  file_size_bytes INTEGER,
  started_at TEXT NOT NULL DEFAULT (datetime('now')),
  finished_at TEXT,
  duration_ms INTEGER,
  error_message TEXT,
  log_output TEXT,
  FOREIGN KEY (profile_id) REFERENCES backup_profiles(id) ON DELETE SET NULL,
  FOREIGN KEY (source_connection_id) REFERENCES connections(id) ON DELETE SET NULL,
  FOREIGN KEY (target_connection_id) REFERENCES connections(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS jobs (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  cron_expression TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  stop_on_error INTEGER NOT NULL DEFAULT 1,
  notify_email_to TEXT,
  notify_on_success INTEGER NOT NULL DEFAULT 1,
  notify_on_error INTEGER NOT NULL DEFAULT 1,
  last_run_at TEXT,
  next_run_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS job_steps (
  id TEXT PRIMARY KEY,
  job_id TEXT NOT NULL,
  step_order INTEGER NOT NULL,
  step_type TEXT NOT NULL CHECK (step_type IN ('backup', 'restore')),
  profile_id TEXT,
  restore_profile_id TEXT,
  source_connection_id TEXT,
  source_database TEXT,
  target_connection_id TEXT,
  target_database TEXT,
  use_previous_backup INTEGER NOT NULL DEFAULT 1,
  restore_options_json TEXT,
  FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
  FOREIGN KEY (profile_id) REFERENCES backup_profiles(id) ON DELETE CASCADE,
  FOREIGN KEY (source_connection_id) REFERENCES connections(id) ON DELETE SET NULL,
  FOREIGN KEY (target_connection_id) REFERENCES connections(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS restore_profiles (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  source_folder TEXT NOT NULL DEFAULT 'backups',
  source_connection_id TEXT,
  source_database TEXT,
  use_latest_backup INTEGER NOT NULL DEFAULT 0,
  file_name TEXT,
  target_connection_id TEXT NOT NULL,
  target_database TEXT NOT NULL,
  create_database_if_not_exists INTEGER NOT NULL DEFAULT 1,
  restore_tool TEXT NOT NULL DEFAULT 'pg_restore',
  options_json TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (source_connection_id) REFERENCES connections(id) ON DELETE SET NULL,
  FOREIGN KEY (target_connection_id) REFERENCES connections(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS network_shares (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  unc_path TEXT NOT NULL,
  domain TEXT,
  username TEXT NOT NULL,
  password_encrypted TEXT NOT NULL,
  password_iv TEXT NOT NULL,
  password_tag TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
