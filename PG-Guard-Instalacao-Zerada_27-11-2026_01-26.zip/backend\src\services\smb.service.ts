import { spawn } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { getDatabase } from '../db/sqlite';
import { decryptSecret } from '../security/crypto';

export interface NetworkShareRow {
  id: string;
  name: string;
  unc_path: string;
  domain: string | null;
  username: string;
  password_encrypted: string;
  password_iv: string;
  password_tag: string;
}

export interface SmbDescriptor {
  uncPath: string;
  domain?: string | null;
  username: string;
  password: string;
}

/**
 * Normaliza um caminho UNC Windows (`\\servidor\pasta`) para o formato SMB (`//servidor/pasta`).
 */
export function normalizeUncPath(raw: string): string {
  return raw.trim().replace(/\\/g, '/').replace(/\/+$/, '');
}

/**
 * Busca um compartilhamento de rede no SQLite e descriptografa sua senha em memória.
 */
export function getDecryptedShare(shareId: string): SmbDescriptor {
  const db = getDatabase();
  const row = db
    .prepare('SELECT * FROM network_shares WHERE id = ?')
    .get(shareId) as NetworkShareRow | undefined;

  if (!row) {
    throw new Error('Compartilhamento de rede não encontrado.');
  }

  return {
    uncPath: normalizeUncPath(row.unc_path),
    domain: row.domain,
    username: row.username,
    password: decryptSecret({
      encrypted: row.password_encrypted,
      iv: row.password_iv,
      tag: row.password_tag
    })
  };
}

/**
 * Executa um comando `smbclient` usando arquivo de credenciais temporário (`-A`, modo 0600)
 * que é apagado imediatamente após o uso, evitando expor senhas AD na linha de comando.
 */
async function runSmbClient(
  desc: SmbDescriptor,
  smbCommand: string
): Promise<{ exitCode: number; stdout: string; stderr: string }> {
  const authFile = path.join(os.tmpdir(), `smb_auth_${crypto.randomUUID()}.conf`);
  const lines = [
    `username=${desc.username}`,
    `password=${desc.password}`
  ];
  if (desc.domain) {
    lines.push(`domain=${desc.domain}`);
  }

  fs.writeFileSync(authFile, lines.join('\n') + '\n', { mode: 0o600 });

  try {
    return await new Promise((resolve, reject) => {
      const child = spawn(
        'smbclient',
        [normalizeUncPath(desc.uncPath), '-A', authFile, '-c', smbCommand],
        { shell: false }
      );

      let stdout = '';
      let stderr = '';

      child.stdout.on('data', (c: Buffer) => { stdout += c.toString('utf8'); });
      child.stderr.on('data', (c: Buffer) => { stderr += c.toString('utf8'); });
      child.on('error', (err) => reject(new Error(`Falha ao executar smbclient: ${err.message}`)));
      child.on('close', (code) => resolve({ exitCode: code ?? 1, stdout, stderr }));
    });
  } finally {
    if (fs.existsSync(authFile)) {
      fs.unlinkSync(authFile);
    }
  }
}

function sanitizeSubPath(subPath: string): string {
  return subPath
    .replace(/\\/g, '/')
    .split('/')
    .map((s) => s.trim())
    .filter((s) => s && s !== '.' && s !== '..')
    .join('/');
}

/**
 * Testa a conectividade e autenticação (usuário local ou AD) em um compartilhamento SMB.
 */
export async function testSmbConnection(desc: SmbDescriptor): Promise<{ ok: boolean; message: string }> {
  const res = await runSmbClient(desc, 'ls');
  if (res.exitCode === 0) {
    return { ok: true, message: 'Conexão de rede autenticada com sucesso!' };
  }
  return { ok: false, message: (res.stderr || res.stdout || 'Falha ao conectar na rede.').trim() };
}

/**
 * Lista diretórios e arquivos de uma subpasta dentro de um compartilhamento SMB.
 */
export async function listSmbDirectory(
  shareId: string,
  subPath = ''
): Promise<{
  directories: Array<{ name: string; fullPath: string }>;
  files: Array<{ name: string; sizeBytes: number }>;
}> {
  const desc = getDecryptedShare(shareId);
  const cleanSub = sanitizeSubPath(subPath);
  const cmd = cleanSub ? `cd "${cleanSub.replace(/"/g, '')}"; ls` : 'ls';

  const res = await runSmbClient(desc, cmd);
  if (res.exitCode !== 0) {
    throw new Error((res.stderr || res.stdout || 'Erro ao listar pasta de rede.').trim());
  }

  const directories: Array<{ name: string; fullPath: string }> = [];
  const files: Array<{ name: string; sizeBytes: number }> = [];

  for (const rawLine of res.stdout.split(/\r?\n/)) {
    const match = rawLine.match(/^\s{2}(.+?)\s{2,}([A-Z]*)\s+(\d+)\s+\w{3}\s+\w{3}\s+\d+\s+[\d:]+\s+\d{4}$/);
    if (!match) continue;
    const entryName = match[1].trim();
    const attrs = match[2];
    const size = Number(match[3]) || 0;

    if (entryName === '.' || entryName === '..') continue;

    if (attrs.includes('D')) {
      const nextSub = cleanSub ? `${cleanSub}/${entryName}` : entryName;
      directories.push({ name: entryName, fullPath: `share:${shareId}:${nextSub}` });
    } else {
      files.push({ name: entryName, sizeBytes: size });
    }
  }

  return {
    directories: directories.sort((a, b) => a.name.localeCompare(b.name)),
    files: files.sort((a, b) => a.name.localeCompare(b.name))
  };
}

/**
 * Cria uma nova pasta dentro do compartilhamento de rede SMB.
 */
export async function createSmbDirectory(shareId: string, subPath: string, folderName: string): Promise<string> {
  const desc = getDecryptedShare(shareId);
  const cleanSub = sanitizeSubPath(subPath);
  const cleanNew = folderName.replace(/[^a-zA-Z0-9_.-]/g, '_');
  const cmd = cleanSub ? `cd "${cleanSub}"; mkdir "${cleanNew}"` : `mkdir "${cleanNew}"`;

  const res = await runSmbClient(desc, cmd);
  if (res.exitCode !== 0) {
    throw new Error((res.stderr || res.stdout || 'Erro ao criar pasta na rede.').trim());
  }

  const nextSub = cleanSub ? `${cleanSub}/${cleanNew}` : cleanNew;
  return `share:${shareId}:${nextSub}`;
}

/**
 * Envia um arquivo local gerado pelo backup para o compartilhamento de rede SMB.
 */
export async function uploadFileToSmb(
  shareId: string,
  subPath: string,
  localFilePath: string,
  remoteFileName: string
): Promise<void> {
  const desc = getDecryptedShare(shareId);
  const cleanSub = sanitizeSubPath(subPath);
  const cmd = cleanSub
    ? `cd "${cleanSub}"; put "${localFilePath}" "${remoteFileName}"`
    : `put "${localFilePath}" "${remoteFileName}"`;

  const res = await runSmbClient(desc, cmd);
  if (res.exitCode !== 0) {
    throw new Error(`Falha ao enviar backup para a rede: ${(res.stderr || res.stdout).trim()}`);
  }
}

/**
 * Baixa um arquivo de backup do compartilhamento de rede SMB para pasta temporária local antes de restaurar.
 */
export async function downloadFileFromSmb(
  shareId: string,
  subPath: string,
  remoteFileName: string,
  localDestPath: string
): Promise<void> {
  const desc = getDecryptedShare(shareId);
  const cleanSub = sanitizeSubPath(subPath);
  const cmd = cleanSub
    ? `cd "${cleanSub}"; get "${remoteFileName}" "${localDestPath}"`
    : `get "${remoteFileName}" "${localDestPath}"`;

  const res = await runSmbClient(desc, cmd);
  if (res.exitCode !== 0) {
    throw new Error(`Falha ao baixar arquivo da rede: ${(res.stderr || res.stdout).trim()}`);
  }
}
