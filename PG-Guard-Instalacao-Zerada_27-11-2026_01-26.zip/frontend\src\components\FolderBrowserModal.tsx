import { useEffect, useState } from 'react';
import { ArrowLeft, Folder, FolderPlus, Network, PlugZap, X } from 'lucide-react';
import { apiRequest } from '../services/api';
import { Button, Card, Input } from './ui';

interface BrowseDir {
  name: string;
  fullPath: string;
  label: string;
}

interface BrowseResponse {
  currentPath: string;
  parentPath: string | null;
  directories: BrowseDir[];
}

/**
 * Navegador visual de pastas estilo Windows Explorer (local e rede SMB/Active Directory).
 * Permite navegar em pastas do servidor e compartilhamentos de rede, testar credenciais AD
 * e criar subpastas antes de selecionar o destino.
 *
 * @example
 * <FolderBrowserModal
 *   open={showBrowser}
 *   initialPath={targetFolder}
 *   onClose={() => setShowBrowser(false)}
 *   onSelect={(folder) => setTargetFolder(folder)}
 * />
 */
export function FolderBrowserModal({
  open,
  initialPath = '',
  onClose,
  onSelect
}: {
  open: boolean;
  initialPath?: string;
  onClose: () => void;
  onSelect: (folderPath: string) => void;
}) {
  const [currentPath, setCurrentPath] = useState(initialPath);
  const [parentPath, setParentPath] = useState<string | null>(null);
  const [directories, setDirectories] = useState<BrowseDir[]>([]);
  const [newFolderName, setNewFolderName] = useState('');
  const [error, setError] = useState('');

  // Cadastro rápido de compartilhamento de rede SMB / AD
  const [showAddShare, setShowAddShare] = useState(false);
  const [shareName, setShareName] = useState('');
  const [uncPath, setUncPath] = useState('');
  const [domain, setDomain] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [shareMsg, setShareMsg] = useState<{ ok: boolean; text: string } | null>(null);

  async function browse(targetPath: string) {
    setError('');
    try {
      const res = await apiRequest<BrowseResponse>(
        `/api/backups/browse?path=${encodeURIComponent(targetPath)}`
      );
      setCurrentPath(res.currentPath);
      setParentPath(res.parentPath);
      setDirectories(res.directories);
    } catch (err) {
      setError((err as Error).message);
    }
  }

  useEffect(() => {
    if (open) {
      void browse(initialPath || '');
    }
  }, [open, initialPath]);

  async function handleCreateFolder() {
    if (!newFolderName.trim()) return;
    setError('');
    try {
      const parent = currentPath || 'backups';
      const res = await apiRequest<{ fullPath: string }>('/api/backups/folders', {
        method: 'POST',
        body: JSON.stringify({ parentPath: parent, folderName: newFolderName.trim() })
      });
      setNewFolderName('');
      await browse(res.fullPath);
    } catch (err) {
      setError((err as Error).message);
    }
  }

  async function handleTestShare() {
    setShareMsg(null);
    try {
      const res = await apiRequest<{ ok: boolean; message: string }>('/api/shares/test-preview', {
        method: 'POST',
        body: JSON.stringify({ uncPath, domain, username, password })
      });
      setShareMsg({ ok: res.ok, text: res.message });
    } catch (err) {
      setShareMsg({ ok: false, text: (err as Error).message });
    }
  }

  async function handleSaveShare() {
    setShareMsg(null);
    try {
      const created = await apiRequest<{ id: string }>('/api/shares', {
        method: 'POST',
        body: JSON.stringify({ name: shareName, uncPath, domain, username, password })
      });
      setShareName('');
      setUncPath('');
      setDomain('');
      setUsername('');
      setPassword('');
      setShowAddShare(false);
      await browse(`share:${created.id}:`);
    } catch (err) {
      setShareMsg({ ok: false, text: (err as Error).message });
    }
  }

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
      <Card className="max-h-[90vh] w-full max-w-xl space-y-4 overflow-y-auto p-5">
        <div className="flex items-center justify-between border-b border-border pb-3">
          <div className="flex items-center gap-2 font-semibold">
            <Folder className="h-5 w-5 text-primary" />
            <span>Navegador de Pastas e Rede (Browser)</span>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-muted px-3 py-2 text-xs">
          <div className="truncate">
            Caminho: <code className="font-bold">{currentPath || '/ (Raízes e Rede)'}</code>
          </div>
          <div className="flex gap-1.5">
            {!currentPath && (
              <Button type="button" variant="outline" size="sm" onClick={() => setShowAddShare(!showAddShare)}>
                <Network className="h-3.5 w-3.5" />
                {showAddShare ? 'Fechar Rede' : '+ Pasta de Rede (SMB/AD)'}
              </Button>
            )}
            {parentPath !== null && (
              <Button type="button" variant="outline" size="sm" onClick={() => void browse(parentPath)}>
                <ArrowLeft className="h-3.5 w-3.5" />
                Voltar
              </Button>
            )}
          </div>
        </div>

        {showAddShare && (
          <Card className="space-y-3 border-primary/40 bg-muted/20 p-4">
            <div className="text-xs font-semibold">Conectar Compartilhamento de Rede (Windows / Samba / AD)</div>
            <div className="grid gap-2 md:grid-cols-2">
              <Input value={shareName} onChange={(e) => setShareName(e.target.value)} placeholder="Nome (ex: NAS Empresa)" />
              <Input value={uncPath} onChange={(e) => setUncPath(e.target.value)} placeholder="Caminho (ex: \\192.168.1.10\backups)" />
              <Input value={domain} onChange={(e) => setDomain(e.target.value)} placeholder="Domínio AD (opcional)" />
              <Input value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Usuário" />
              <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Senha (criptografada AES-256-GCM)" />
            </div>
            {shareMsg && (
              <div className={`rounded p-2 text-xs ${shareMsg.ok ? 'bg-emerald-500/15 text-emerald-600' : 'bg-destructive/15 text-destructive'}`}>
                {shareMsg.text}
              </div>
            )}
            <div className="flex flex-wrap items-center gap-2">
              <Button type="button" variant="outline" size="sm" onClick={() => void handleTestShare()} disabled={!uncPath || !username || !password}>
                <PlugZap className="h-3.5 w-3.5" />
                Testar Acesso
              </Button>
              <Button type="button" size="sm" onClick={() => void handleSaveShare()} disabled={!shareName || !uncPath || !username || !password}>
                Salvar Rede e Abrir
              </Button>
              <span className="text-[11px] text-muted-foreground">
                Salve para autenticar backups e agendamentos futuros.
              </span>
            </div>
          </Card>
        )}

        <div className="max-h-56 divide-y divide-border overflow-y-auto rounded-lg border border-border">
          {directories.length === 0 ? (
            <div className="p-4 text-center text-xs text-muted-foreground">
              Nenhuma subpasta aqui dentro. Você pode selecionar esta pasta ou criar uma nova abaixo.
            </div>
          ) : (
            directories.map((dir) => (
              <button
                key={dir.fullPath}
                type="button"
                onClick={() => void browse(dir.fullPath)}
                className="flex w-full items-center gap-2.5 px-3 py-2.5 text-left text-sm hover:bg-muted/50"
              >
                <Folder className="h-4 w-4 text-amber-500" />
                <span>{dir.label}</span>
              </button>
            ))
          )}
        </div>

        <div className="flex gap-2">
          <Input
            value={newFolderName}
            onChange={(e) => setNewFolderName(e.target.value)}
            placeholder={currentPath ? `Nova subpasta dentro de ${currentPath}...` : 'Nova subpasta em backups/...'}
          />
          <Button type="button" variant="outline" onClick={() => void handleCreateFolder()} disabled={!newFolderName.trim()}>
            <FolderPlus className="h-4 w-4" />
            Criar
          </Button>
        </div>

        {error && <div className="rounded-lg bg-destructive/15 p-2.5 text-xs text-destructive">{error}</div>}

        <div className="flex justify-end gap-2 border-t border-border pt-3">
          <Button type="button" variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button
            type="button"
            disabled={!currentPath}
            onClick={() => {
              onSelect(currentPath || 'backups');
              onClose();
            }}
          >
            Selecionar esta Pasta
          </Button>
        </div>
      </Card>
    </div>
  );
}
