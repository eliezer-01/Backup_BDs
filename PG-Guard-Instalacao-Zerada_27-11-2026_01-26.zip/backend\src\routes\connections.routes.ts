import crypto from 'node:crypto';
import type { SQLInputValue } from 'node:sqlite';
import type { FastifyInstance } from 'fastify';
import { getDatabase } from '../db/sqlite';
import { authenticateRequest, requirePermission } from '../security/auth';
import { encryptSecret } from '../security/crypto';
import { connectionInputSchema } from '../security/sanitizer';
import { getDatabaseAdapter } from '../adapters/registry';
import { getDecryptedConnection } from '../services/connections.service';
import { runQuickCommand } from '../services/runner.service';

/**
 * Registra as rotas de gerenciamento de conexões (locais e remotas),
 * teste de conectividade e listagem automática de bancos de dados.
 *
 * @example
 * app.register(connectionsRoutes, { prefix: '/api/connections' });
 */
export async function connectionsRoutes(app: FastifyInstance): Promise<void> {
  app.addHook('preHandler', authenticateRequest);

  app.get('/', { preHandler: [requirePermission('connections:read')] }, async () => {
    const db = getDatabase();
    const rows = db
      .prepare(`
        SELECT id, name, engine, host, port, username, default_database, ssl_mode, created_at, updated_at
        FROM connections
        ORDER BY name ASC
      `)
      .all();

    return { connections: rows };
  });

  app.post('/discover', { preHandler: [requirePermission('connections:create', 'connections:write', 'connections:read')] }, async (request, reply) => {
    const discoverSchema = connectionInputSchema.omit({ name: true });
    const parsed = discoverSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Dados inválidos.', details: parsed.error.flatten() });
    }

    const d = parsed.data;
    const adapter = getDatabaseAdapter(d.engine);
    const descriptor = {
      id: 'preview',
      name: 'preview',
      engine: d.engine,
      host: d.host,
      port: d.port,
      username: d.username,
      defaultDatabase: d.default_database || 'postgres',
      sslMode: d.ssl_mode
    };

    const cmd = adapter.buildListDatabasesCommand(descriptor, d.password);
    const result = await runQuickCommand(cmd);

    if (result.exitCode !== 0) {
      return reply.status(400).send({
        ok: false,
        error: result.stderr || 'Não foi possível conectar ao servidor.'
      });
    }

    const databases = result.stdout
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean);

    return reply.send({ ok: true, databases });
  });

  app.post('/', { preHandler: [requirePermission('connections:create', 'connections:write')] }, async (request, reply) => {
    const parsed = connectionInputSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Dados inválidos.', details: parsed.error.flatten() });
    }

    const data = parsed.data;
    const { encrypted, iv, tag } = encryptSecret(data.password);
    const id = crypto.randomUUID();
    const db = getDatabase();

    db.prepare(`
      INSERT INTO connections (id, name, engine, host, port, username, password_encrypted, password_iv, password_tag, default_database, ssl_mode)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      data.name,
      data.engine,
      data.host,
      data.port,
      data.username,
      encrypted,
      iv,
      tag,
      data.default_database,
      data.ssl_mode
    );

    return reply.status(201).send({
      id,
      name: data.name,
      engine: data.engine,
      host: data.host,
      port: data.port,
      username: data.username,
      default_database: data.default_database,
      ssl_mode: data.ssl_mode
    });
  });

  app.put<{ Params: { id: string } }>('/:id', { preHandler: [requirePermission('connections:update', 'connections:write')] }, async (request, reply) => {
    const partialSchema = connectionInputSchema.partial().extend({
      password: connectionInputSchema.shape.password.optional()
    });
    const parsed = partialSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Dados inválidos.', details: parsed.error.flatten() });
    }

    const db = getDatabase();
    const existing = db.prepare('SELECT id FROM connections WHERE id = ?').get(request.params.id);
    if (!existing) {
      return reply.status(404).send({ error: 'Conexão não encontrada.' });
    }

    const data = parsed.data;
    const fields: string[] = [];
    const values: SQLInputValue[] = [];

    if (data.name !== undefined) { fields.push('name = ?'); values.push(data.name); }
    if (data.host !== undefined) { fields.push('host = ?'); values.push(data.host); }
    if (data.port !== undefined) { fields.push('port = ?'); values.push(data.port); }
    if (data.username !== undefined) { fields.push('username = ?'); values.push(data.username); }
    if (data.default_database !== undefined) { fields.push('default_database = ?'); values.push(data.default_database); }
    if (data.ssl_mode !== undefined) { fields.push('ssl_mode = ?'); values.push(data.ssl_mode); }

    if (data.password) {
      const { encrypted, iv, tag } = encryptSecret(data.password);
      fields.push('password_encrypted = ?', 'password_iv = ?', 'password_tag = ?');
      values.push(encrypted, iv, tag);
    }

    if (fields.length > 0) {
      fields.push("updated_at = datetime('now')");
      values.push(request.params.id);
      db.prepare(`UPDATE connections SET ${fields.join(', ')} WHERE id = ?`).run(...values);
    }

    return reply.send({ updated: true });
  });

  app.delete<{ Params: { id: string } }>('/:id', { preHandler: [requirePermission('connections:delete', 'connections:write')] }, async (request, reply) => {
    const db = getDatabase();
    const result = db.prepare('DELETE FROM connections WHERE id = ?').run(request.params.id);
    if (result.changes === 0) {
      return reply.status(404).send({ error: 'Conexão não encontrada.' });
    }
    return reply.send({ deleted: true });
  });

  app.post<{ Params: { id: string } }>('/:id/test', { preHandler: [requirePermission('connections:read')] }, async (request, reply) => {
    try {
      const { descriptor, password } = getDecryptedConnection(request.params.id);
      const adapter = getDatabaseAdapter(descriptor.engine);
      const cmd = adapter.buildTestConnectionCommand(descriptor, password);
      const result = await runQuickCommand(cmd);

      if (result.exitCode === 0) {
        return reply.send({ ok: true, message: 'Conexão estabelecida com sucesso!' });
      }
      return reply.status(400).send({
        ok: false,
        message: result.stderr || 'Não foi possível conectar ao servidor.'
      });
    } catch (err) {
      return reply.status(404).send({ ok: false, message: (err as Error).message });
    }
  });

  app.get<{ Params: { id: string } }>('/:id/databases', { preHandler: [requirePermission('connections:read')] }, async (request, reply) => {
    try {
      const { descriptor, password } = getDecryptedConnection(request.params.id);
      const adapter = getDatabaseAdapter(descriptor.engine);
      const cmd = adapter.buildListDatabasesCommand(descriptor, password);
      const result = await runQuickCommand(cmd);

      if (result.exitCode !== 0) {
        return reply.status(400).send({
          error: 'Erro ao listar bancos de dados.',
          details: result.stderr
        });
      }

      const databases = result.stdout
        .split(/\r?\n/)
        .map((line) => line.trim())
        .filter(Boolean);

      return reply.send({ databases });
    } catch (err) {
      return reply.status(404).send({ error: (err as Error).message });
    }
  });
}
