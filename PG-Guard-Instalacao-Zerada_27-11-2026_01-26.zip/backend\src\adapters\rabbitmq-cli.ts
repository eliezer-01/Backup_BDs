import fs from 'node:fs';

/**
 * Executor CLI isolado para RabbitMQ Management API (`/api/overview`, `/api/vhosts`, `/api/definitions`).
 * Recebe a senha exclusivamente pela variável de ambiente `RABBIT_PASSWORD`.
 */
async function main(): Promise<void> {
  const [, , action, baseUrl, username, filePath] = process.argv;
  const password = process.env.RABBIT_PASSWORD || '';
  const authHeader = `Basic ${Buffer.from(`${username}:${password}`).toString('base64')}`;

  const headers: Record<string, string> = {
    Authorization: authHeader,
    'Content-Type': 'application/json'
  };

  if (action === 'test') {
    const res = await fetch(`${baseUrl}/api/overview`, { headers });
    if (!res.ok) {
      console.error(`Erro HTTP ${res.status}: ${await res.text()}`);
      process.exit(1);
    }
    const data = (await res.json()) as { rabbitmq_version?: string };
    console.log(`RabbitMQ ${data.rabbitmq_version || 'OK'} conectado!`);
    return;
  }

  if (action === 'list-vhosts') {
    const res = await fetch(`${baseUrl}/api/vhosts`, { headers });
    if (!res.ok) {
      console.error(`Erro HTTP ${res.status}: ${await res.text()}`);
      process.exit(1);
    }
    const vhosts = (await res.json()) as Array<{ name: string }>;
    for (const v of vhosts) {
      console.log(v.name === '/' ? 'default (/)' : v.name);
    }
    return;
  }

  if (action === 'backup') {
    const res = await fetch(`${baseUrl}/api/definitions`, { headers });
    if (!res.ok) {
      console.error(`Erro HTTP ${res.status}: ${await res.text()}`);
      process.exit(1);
    }
    const body = await res.text();
    fs.writeFileSync(filePath, body, 'utf-8');
    console.log(`Definições do RabbitMQ exportadas para ${filePath}`);
    return;
  }

  if (action === 'restore') {
    const content = fs.readFileSync(filePath, 'utf-8');
    const res = await fetch(`${baseUrl}/api/definitions`, {
      method: 'POST',
      headers,
      body: content
    });
    if (!res.ok) {
      console.error(`Erro HTTP ${res.status}: ${await res.text()}`);
      process.exit(1);
    }
    console.log('Definições (queues, exchanges, bindings e vhosts) restauradas no RabbitMQ!');
    return;
  }

  console.error(`Ação desconhecida: ${action}`);
  process.exit(1);
}

main().catch((err) => {
  console.error((err as Error).message);
  process.exit(1);
});
