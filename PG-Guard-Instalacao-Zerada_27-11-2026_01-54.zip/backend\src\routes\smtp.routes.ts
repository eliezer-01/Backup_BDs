import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { getDatabase } from '../db/sqlite';
import { authenticateRequest, requirePermission } from '../security/auth';
import { encryptSecret } from '../security/crypto';
import {
  DEFAULT_BODY_FIELDS,
  DEFAULT_JOB_EMAIL_CONFIG,
  parseJobEmailConfig,
  sendTestAlertEmail,
  type SmtpSettingsRow
} from '../services/email.service';

const smtpSchema = z.object({
  host: z.string().trim().min(1),
  port: z.coerce.number().int().min(1).max(65535).default(587),
  secure: z.boolean().default(false),
  username: z.string().trim().min(1),
  password: z.string().optional(),
  fromEmail: z.string().email(),
  fromName: z.string().trim().min(1).default('PG Guard Alertas'),
  allowSelfSigned: z.boolean().default(false),
  subjectSuccess: z.string().trim().min(1).max(200).default('[PG Guard] ✅ SUCESSO - {{perfil}} ({{banco}})'),
  subjectError: z.string().trim().min(1).max(200).default('[PG Guard] ❌ FALHA - {{perfil}} ({{banco}})'),
  customMessage: z.string().max(1000).optional().default(''),
  bodyFields: z
    .object({
      perfil: z.boolean().default(true),
      conexao: z.boolean().default(true),
      banco: z.boolean().default(true),
      data_hora: z.boolean().default(true),
      duracao: z.boolean().default(true),
      tamanho: z.boolean().default(true),
      arquivo: z.boolean().default(true),
      erro: z.boolean().default(true)
    })
    .default(DEFAULT_BODY_FIELDS),
  jobEmailConfig: z
    .object({
      subjectSuccess: z.string().trim().min(1).max(200).default(DEFAULT_JOB_EMAIL_CONFIG.subjectSuccess),
      subjectError: z.string().trim().min(1).max(200).default(DEFAULT_JOB_EMAIL_CONFIG.subjectError),
      customMessage: z.string().max(1000).optional().default(''),
      fields: z
        .object({
          etapa: z.boolean().default(true),
          alvo: z.boolean().default(true),
          status: z.boolean().default(true),
          data_hora: z.boolean().default(true),
          duracao: z.boolean().default(true),
          detalhes: z.boolean().default(true)
        })
        .default(DEFAULT_JOB_EMAIL_CONFIG.fields)
    })
    .default(DEFAULT_JOB_EMAIL_CONFIG)
});

/**
 * Registra as rotas de configuração segura do servidor SMTP (senha criptografada AES-256-GCM),
 * personalização de assunto/mensagem/campos e envio de e-mail de teste.
 *
 * @example
 * app.register(smtpRoutes, { prefix: '/api/smtp' });
 */
export async function smtpRoutes(app: FastifyInstance): Promise<void> {
  app.addHook('preHandler', authenticateRequest);
  app.addHook('preHandler', requirePermission('smtp:manage', 'users:manage'));

  app.get('/', async () => {
    const db = getDatabase();
    const row = db
      .prepare(`
        SELECT host, port, secure, username, from_email, from_name, allow_self_signed,
               subject_success, subject_error, custom_message, body_fields_json, job_email_config_json, updated_at
        FROM smtp_settings WHERE id = 'default'
      `)
      .get() as Omit<SmtpSettingsRow, 'id' | 'password_encrypted' | 'password_iv' | 'password_tag'> | undefined;

    let bodyFields = DEFAULT_BODY_FIELDS;
    if (row?.body_fields_json) {
      try {
        bodyFields = { ...DEFAULT_BODY_FIELDS, ...JSON.parse(row.body_fields_json) };
      } catch {
        bodyFields = DEFAULT_BODY_FIELDS;
      }
    }

    return {
      configured: Boolean(row),
      settings: row
        ? {
            host: row.host,
            port: row.port,
            secure: row.secure === 1,
            username: row.username,
            fromEmail: row.from_email,
            fromName: row.from_name,
            allowSelfSigned: row.allow_self_signed === 1,
            subjectSuccess: row.subject_success,
            subjectError: row.subject_error,
            customMessage: row.custom_message || '',
            bodyFields,
            jobEmailConfig: parseJobEmailConfig(row.job_email_config_json)
          }
        : null
    };
  });

  app.put('/', async (request, reply) => {
    const parsed = smtpSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Dados SMTP inválidos.', details: parsed.error.flatten() });
    }

    const db = getDatabase();
    const existing = db
      .prepare("SELECT password_encrypted, password_iv, password_tag FROM smtp_settings WHERE id = 'default'")
      .get() as { password_encrypted: string; password_iv: string; password_tag: string } | undefined;

    if (!existing && !parsed.data.password) {
      return reply.status(400).send({ error: 'Informe a senha/token SMTP na primeira configuração.' });
    }

    const enc = parsed.data.password
      ? encryptSecret(parsed.data.password)
      : {
          encrypted: existing!.password_encrypted,
          iv: existing!.password_iv,
          tag: existing!.password_tag
        };

    db.prepare(`
      INSERT INTO smtp_settings (
        id, host, port, secure, username, password_encrypted, password_iv, password_tag,
        from_email, from_name, allow_self_signed, subject_success, subject_error, custom_message, body_fields_json, job_email_config_json, updated_at
      )
      VALUES ('default', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
      ON CONFLICT(id) DO UPDATE SET
        host = excluded.host,
        port = excluded.port,
        secure = excluded.secure,
        username = excluded.username,
        password_encrypted = excluded.password_encrypted,
        password_iv = excluded.password_iv,
        password_tag = excluded.password_tag,
        from_email = excluded.from_email,
        from_name = excluded.from_name,
        allow_self_signed = excluded.allow_self_signed,
        subject_success = excluded.subject_success,
        subject_error = excluded.subject_error,
        custom_message = excluded.custom_message,
        body_fields_json = excluded.body_fields_json,
        job_email_config_json = excluded.job_email_config_json,
        updated_at = datetime('now')
    `).run(
      parsed.data.host,
      parsed.data.port,
      parsed.data.secure ? 1 : 0,
      parsed.data.username,
      enc.encrypted,
      enc.iv,
      enc.tag,
      parsed.data.fromEmail,
      parsed.data.fromName,
      parsed.data.allowSelfSigned ? 1 : 0,
      parsed.data.subjectSuccess,
      parsed.data.subjectError,
      parsed.data.customMessage || null,
      JSON.stringify(parsed.data.bodyFields),
      JSON.stringify(parsed.data.jobEmailConfig)
    );

    return reply.send({ saved: true });
  });

  app.post('/test', async (request, reply) => {
    const schema = z.object({
      to: z.string().email('Informe um e-mail de destino válido.'),
      alertType: z.enum(['individual', 'job']).default('individual')
    });
    const parsed = schema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: parsed.error.issues[0]?.message || 'E-mail inválido.' });
    }

    try {
      await sendTestAlertEmail(parsed.data.to, parsed.data.alertType);
      return reply.send({ ok: true, message: `E-mail de teste (${parsed.data.alertType === 'job' ? 'Job' : 'Individual'}) enviado para ${parsed.data.to}!` });
    } catch (err) {
      return reply.status(400).send({
        ok: false,
        error: `${(err as Error).message} — Aviso: salve a configuração SMTP antes de clicar em "Testar Envio".`
      });
    }
  });
}
