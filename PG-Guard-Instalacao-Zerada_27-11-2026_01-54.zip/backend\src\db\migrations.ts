import crypto from 'node:crypto';
import type { DatabaseSync } from 'node:sqlite';
import { env } from '../config/env';
import { ALL_PERMISSIONS } from '../security/permissions';

interface Migration {
  version: number;
  name: string;
  up: (db: DatabaseSync) => void;
}

/**
 * Verifica se uma coluna já existe em uma tabela do SQLite usando `PRAGMA table_info`.
 * Útil para tornar migrations `ALTER TABLE ADD COLUMN` 100% idempotentes.
 *
 * @param db Instância ativa do SQLite.
 * @param tableName Nome da tabela.
 * @param columnName Nome da coluna a verificar.
 * @example
 * if (!hasColumn(db, 'connections', 'notes')) {
 *   db.exec('ALTER TABLE connections ADD COLUMN notes TEXT;');
 * }
 */
export function hasColumn(db: DatabaseSync, tableName: string, columnName: string): boolean {
  const columns = db.prepare(`PRAGMA table_info(${tableName})`).all() as Array<{ name: string }>;
  return columns.some((col) => col.name === columnName);
}

/**
 * Lista ordenada de migrations incrementais do banco SQLite.
 * Ao atualizar o sistema com uma pasta nova, novas tabelas ou colunas adicionadas aqui
 * serão aplicadas automaticamente na inicialização sem perder dados existentes.
 */
const MIGRATIONS: Migration[] = [
  {
    version: 1,
    name: 'baseline_schema_inicial',
    up: () => {
      // Schema base já garantido pelo schema.sql (CREATE TABLE IF NOT EXISTS)
    }
  },
  {
    version: 2,
    name: 'add_rbac_roles_and_user_role_id',
    up: (db) => {
      db.exec(`
        CREATE TABLE IF NOT EXISTS roles (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL UNIQUE,
          description TEXT,
          permissions_json TEXT NOT NULL,
          is_system INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
      `);

      if (!hasColumn(db, 'users', 'role_id')) {
        db.exec('ALTER TABLE users ADD COLUMN role_id TEXT;');
      }

      const existingAdmin = db
        .prepare("SELECT id FROM roles WHERE name = 'Administrador'")
        .get() as { id: string } | undefined;

      const adminRoleId = existingAdmin?.id ?? crypto.randomUUID();
      if (!existingAdmin) {
        db.prepare(
          'INSERT INTO roles (id, name, description, permissions_json, is_system) VALUES (?, ?, ?, ?, 1)'
        ).run(
          adminRoleId,
          'Administrador',
          'Acesso total a todas as funcionalidades do sistema',
          JSON.stringify(ALL_PERMISSIONS)
        );
      }

      db.prepare('UPDATE users SET role_id = ? WHERE role_id IS NULL').run(adminRoleId);

      // Perfis iniciais de exemplo (editáveis pelo administrador)
      const presetRoles = [
        {
          name: 'Auditor (Somente Consulta)',
          description: 'Consulta histórico, console ao vivo e status dos backups',
          permissions: ['connections:read', 'logs:read', 'logs:download']
        },
        {
          name: 'Operador de Restauração',
          description: 'Permite restaurar backups e acompanhar os logs',
          permissions: ['connections:read', 'restore:execute', 'logs:read']
        },
        {
          name: 'Gestor de Agendamentos',
          description: 'Cria perfis de backup, agenda rotinas Cron e acompanha logs',
          permissions: ['connections:read', 'backup:profiles', 'schedules:manage', 'logs:read']
        }
      ];

      for (const preset of presetRoles) {
        const exists = db.prepare('SELECT id FROM roles WHERE name = ?').get(preset.name);
          if (!exists) {
            db.prepare(
              'INSERT INTO roles (id, name, description, permissions_json, is_system) VALUES (?, ?, ?, ?, 0)'
            ).run(
              crypto.randomUUID(),
              preset.name,
              preset.description,
              JSON.stringify(preset.permissions)
            );
          }
        }
      }
    },
  {
    version: 3,
    name: 'add_is_master_to_users',
    up: (db) => {
      if (!hasColumn(db, 'users', 'is_master')) {
        db.exec('ALTER TABLE users ADD COLUMN is_master INTEGER NOT NULL DEFAULT 0;');
      }

      const hasMaster = db.prepare('SELECT id FROM users WHERE is_master = 1').get();
      if (!hasMaster) {
        const adminUser = db
          .prepare('SELECT id FROM users WHERE username = ?')
          .get(env.ADMIN_USER) as { id: string } | undefined;

        if (adminUser) {
          db.prepare('UPDATE users SET is_master = 1 WHERE id = ?').run(adminUser.id);
        } else {
          const firstAdmin = db
            .prepare(`
              SELECT u.id FROM users u
              JOIN roles r ON r.id = u.role_id
              WHERE r.is_system = 1
              ORDER BY u.created_at ASC LIMIT 1
            `)
            .get() as { id: string } | undefined;
          if (firstAdmin) {
            db.prepare('UPDATE users SET is_master = 1 WHERE id = ?').run(firstAdmin.id);
          }
        }
      }
    }
  },
  {
    version: 4,
    name: 'ensure_env_admin_is_master',
    up: (db) => {
      const envAdmin = db
        .prepare('SELECT id FROM users WHERE username = ?')
        .get(env.ADMIN_USER) as { id: string } | undefined;

      if (envAdmin) {
        db.prepare('UPDATE users SET is_master = 0 WHERE id != ?').run(envAdmin.id);
        db.prepare('UPDATE users SET is_master = 1 WHERE id = ?').run(envAdmin.id);
      }
    }
  },
  {
    version: 5,
    name: 'add_smtp_folders_and_schedule_alerts',
    up: (db) => {
      db.exec(`
        CREATE TABLE IF NOT EXISTS smtp_settings (
          id TEXT PRIMARY KEY,
          host TEXT NOT NULL,
          port INTEGER NOT NULL DEFAULT 587,
          secure INTEGER NOT NULL DEFAULT 0,
          username TEXT NOT NULL,
          password_encrypted TEXT NOT NULL,
          password_iv TEXT NOT NULL,
          password_tag TEXT NOT NULL,
          from_email TEXT NOT NULL,
          from_name TEXT NOT NULL DEFAULT 'PG Guard Alertas',
          allow_self_signed INTEGER NOT NULL DEFAULT 0,
          updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
      `);

      if (!hasColumn(db, 'backup_profiles', 'target_folder')) {
        db.exec("ALTER TABLE backup_profiles ADD COLUMN target_folder TEXT NOT NULL DEFAULT 'backups';");
      }
      if (!hasColumn(db, 'schedules', 'notify_email_to')) {
        db.exec('ALTER TABLE schedules ADD COLUMN notify_email_to TEXT;');
      }
      if (!hasColumn(db, 'schedules', 'notify_on_success')) {
        db.exec('ALTER TABLE schedules ADD COLUMN notify_on_success INTEGER NOT NULL DEFAULT 1;');
      }
      if (!hasColumn(db, 'schedules', 'notify_on_error')) {
        db.exec('ALTER TABLE schedules ADD COLUMN notify_on_error INTEGER NOT NULL DEFAULT 1;');
      }
    }
  },
  {
    version: 6,
    name: 'add_sequential_jobs_and_steps',
    up: (db) => {
      db.exec(`
        CREATE TABLE IF NOT EXISTS jobs (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          description TEXT,
          cron_expression TEXT NOT NULL,
          is_active INTEGER NOT NULL DEFAULT 1,
          stop_on_error INTEGER NOT NULL DEFAULT 1,
          notify_email_to TEXT,
          notify_on_success INTEGER NOT NULL DEFAULT 1,
          notify_on_error INTEGER NOT NULL DEFAULT 1,
          last_run_at TEXT,
          next_run_at TEXT,
          created_at TEXT NOT NULL DEFAULT (datetime('now')),
          updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS job_steps (
          id TEXT PRIMARY KEY,
          job_id TEXT NOT NULL,
          step_order INTEGER NOT NULL,
          step_type TEXT NOT NULL CHECK (step_type IN ('backup', 'restore')),
          profile_id TEXT,
          source_connection_id TEXT,
          source_database TEXT,
          target_connection_id TEXT,
          target_database TEXT,
          use_previous_backup INTEGER NOT NULL DEFAULT 1,
          restore_options_json TEXT,
          FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
          FOREIGN KEY (profile_id) REFERENCES backup_profiles(id) ON DELETE CASCADE,
          FOREIGN KEY (source_connection_id) REFERENCES connections(id) ON DELETE SET NULL,
          FOREIGN KEY (target_connection_id) REFERENCES connections(id) ON DELETE SET NULL
        );
      `);
    }
  },
  {
    version: 7,
    name: 'add_restore_profiles_table',
    up: (db) => {
      db.exec(`
        CREATE TABLE IF NOT EXISTS restore_profiles (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          description TEXT,
          source_folder TEXT NOT NULL DEFAULT 'backups',
          source_connection_id TEXT,
          source_database TEXT,
          use_latest_backup INTEGER NOT NULL DEFAULT 0,
          file_name TEXT,
          target_connection_id TEXT NOT NULL,
          target_database TEXT NOT NULL,
          create_database_if_not_exists INTEGER NOT NULL DEFAULT 1,
          restore_tool TEXT NOT NULL DEFAULT 'pg_restore',
          options_json TEXT NOT NULL,
          created_at TEXT NOT NULL DEFAULT (datetime('now')),
          updated_at TEXT NOT NULL DEFAULT (datetime('now')),
          FOREIGN KEY (source_connection_id) REFERENCES connections(id) ON DELETE SET NULL,
          FOREIGN KEY (target_connection_id) REFERENCES connections(id) ON DELETE CASCADE
        );
      `);
    }
  },
  {
    version: 8,
    name: 'add_network_shares_table',
    up: (db) => {
      db.exec(`
        CREATE TABLE IF NOT EXISTS network_shares (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          unc_path TEXT NOT NULL,
          domain TEXT,
          username TEXT NOT NULL,
          password_encrypted TEXT NOT NULL,
          password_iv TEXT NOT NULL,
          password_tag TEXT NOT NULL,
          created_at TEXT NOT NULL DEFAULT (datetime('now')),
          updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
      `);
    }
  },
  {
    version: 9,
    name: 'add_restore_schedules_and_job_restore_profile',
    up: (db) => {
      if (!hasColumn(db, 'job_steps', 'restore_profile_id')) {
        db.exec('ALTER TABLE job_steps ADD COLUMN restore_profile_id TEXT;');
      }

      if (!hasColumn(db, 'schedules', 'schedule_type')) {
        db.exec(`
          CREATE TABLE schedules_new (
            id TEXT PRIMARY KEY,
            schedule_type TEXT NOT NULL DEFAULT 'backup' CHECK (schedule_type IN ('backup', 'restore')),
            profile_id TEXT,
            restore_profile_id TEXT,
            cron_expression TEXT NOT NULL,
            is_active INTEGER NOT NULL DEFAULT 1,
            retention_daily INTEGER NOT NULL DEFAULT 7,
            retention_weekly INTEGER NOT NULL DEFAULT 4,
            retention_monthly INTEGER NOT NULL DEFAULT 3,
            notify_email_to TEXT,
            notify_on_success INTEGER NOT NULL DEFAULT 1,
            notify_on_error INTEGER NOT NULL DEFAULT 1,
            last_run_at TEXT,
            next_run_at TEXT,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY (profile_id) REFERENCES backup_profiles(id) ON DELETE CASCADE,
            FOREIGN KEY (restore_profile_id) REFERENCES restore_profiles(id) ON DELETE CASCADE
          );
          INSERT INTO schedules_new (
            id, schedule_type, profile_id, cron_expression, is_active,
            retention_daily, retention_weekly, retention_monthly,
            notify_email_to, notify_on_success, notify_on_error,
            last_run_at, next_run_at, created_at, updated_at
          )
          SELECT
            id, 'backup', profile_id, cron_expression, is_active,
            retention_daily, retention_weekly, retention_monthly,
            notify_email_to, notify_on_success, notify_on_error,
            last_run_at, next_run_at, created_at, updated_at
          FROM schedules;
          DROP TABLE schedules;
          ALTER TABLE schedules_new RENAME TO schedules;
        `);
      }
    }
  },
  {
    version: 10,
    name: 'add_smtp_template_customization',
    up: (db) => {
      if (!hasColumn(db, 'smtp_settings', 'subject_success')) {
        db.exec("ALTER TABLE smtp_settings ADD COLUMN subject_success TEXT NOT NULL DEFAULT '[PG Guard] ✅ SUCESSO - {{perfil}} ({{banco}})';");
      }
      if (!hasColumn(db, 'smtp_settings', 'subject_error')) {
        db.exec("ALTER TABLE smtp_settings ADD COLUMN subject_error TEXT NOT NULL DEFAULT '[PG Guard] ❌ FALHA - {{perfil}} ({{banco}})';");
      }
      if (!hasColumn(db, 'smtp_settings', 'custom_message')) {
        db.exec('ALTER TABLE smtp_settings ADD COLUMN custom_message TEXT;');
      }
      if (!hasColumn(db, 'smtp_settings', 'body_fields_json')) {
        db.exec(
          'ALTER TABLE smtp_settings ADD COLUMN body_fields_json TEXT NOT NULL DEFAULT \'{"perfil":true,"conexao":true,"banco":true,"data_hora":true,"duracao":true,"tamanho":true,"arquivo":true,"erro":true}\';'
        );
      }
    }
  },
  {
    version: 11,
    name: 'add_job_email_config_json',
    up: (db) => {
      if (!hasColumn(db, 'smtp_settings', 'job_email_config_json')) {
        db.exec('ALTER TABLE smtp_settings ADD COLUMN job_email_config_json TEXT;');
      }
    }
  }
];

/**
 * Executa todas as migrations pendentes no SQLite com controle transacional
 * e registro na tabela `schema_migrations`.
 *
 * @param db Instância conectada do `DatabaseSync`.
 * @example
 * runPendingMigrations(db);
 */
export function runPendingMigrations(db: DatabaseSync): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      applied_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  const appliedRows = db
    .prepare('SELECT version FROM schema_migrations')
    .all() as Array<{ version: number }>;
  const appliedVersions = new Set(appliedRows.map((r) => r.version));

  for (const migration of MIGRATIONS) {
    if (appliedVersions.has(migration.version)) {
      continue;
    }

    db.exec('BEGIN TRANSACTION;');
    try {
      migration.up(db);
      db.prepare('INSERT INTO schema_migrations (version, name) VALUES (?, ?)').run(
        migration.version,
        migration.name
      );
      db.exec('COMMIT;');
      console.log(`🗄️  Migration v${migration.version} (${migration.name}) aplicada com sucesso.`);
    } catch (err) {
      db.exec('ROLLBACK;');
      throw new Error(`Falha ao aplicar migration v${migration.version} (${migration.name}): ${(err as Error).message}`);
    }
  }
}
