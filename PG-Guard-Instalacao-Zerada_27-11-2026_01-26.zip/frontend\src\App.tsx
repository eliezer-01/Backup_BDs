import { useEffect, useState } from 'react';
import {
  Activity,
  CalendarClock,
  DatabaseBackup,
  HardDriveUpload,
  LogOut,
  Moon,
  PanelLeftClose,
  PanelLeftOpen,
  Server,
  ShieldCheck,
  Sun,
  UserCog,
  Workflow
} from 'lucide-react';
import { apiRequest, getAuthToken, setAuthToken } from './services/api';
import { Button, cn } from './components/ui';
import { LoginPage } from './pages/LoginPage';
import { ConnectionsPage } from './pages/ConnectionsPage';
import { BackupPage } from './pages/BackupPage';
import { RestorePage } from './pages/RestorePage';
import { SchedulesPage } from './pages/SchedulesPage';
import { JobsPage } from './pages/JobsPage';
import { LogsPage } from './pages/LogsPage';
import { UsersPage } from './pages/UsersPage';

type TabKey = 'connections' | 'backup' | 'restore' | 'schedules' | 'jobs' | 'logs' | 'users';

interface AuthUser {
  id: string;
  username: string;
  roleName: string;
  permissions: string[];
  isMaster?: boolean;
}

/**
 * Componente raiz da aplicação: gerencia autenticação JWT, permissões RBAC,
 * tema escuro/claro e navegação entre os módulos do painel.
 */
export function App() {
  const [authenticated, setAuthenticated] = useState<boolean>(() => Boolean(getAuthToken()));
  const [user, setUser] = useState<AuthUser | null>(null);
  const [activeTab, setActiveTab] = useState<TabKey>('connections');
  const [darkMode, setDarkMode] = useState<boolean>(() => localStorage.getItem('pg_guard_theme') === 'dark');
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(() => localStorage.getItem('pg_guard_sidebar') === 'collapsed');

  useEffect(() => {
    localStorage.setItem('pg_guard_sidebar', sidebarCollapsed ? 'collapsed' : 'expanded');
  }, [sidebarCollapsed]);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
    localStorage.setItem('pg_guard_theme', darkMode ? 'dark' : 'light');
  }, [darkMode]);

  useEffect(() => {
    const onExpired = () => {
      setAuthenticated(false);
      setUser(null);
    };
    window.addEventListener('auth-expired', onExpired);
    return () => window.removeEventListener('auth-expired', onExpired);
  }, []);

  useEffect(() => {
    if (!authenticated) return;
    void apiRequest<{ user: AuthUser }>('/api/auth/me')
      .then((res) => setUser(res.user))
      .catch(() => setAuthenticated(false));
  }, [authenticated]);

  if (!authenticated) {
    return <LoginPage onLoginSuccess={() => setAuthenticated(true)} />;
  }

  const perms = new Set(user?.permissions ?? []);
  const hasAny = (...keys: string[]) => keys.some((k) => perms.has(k));
  const allNavItems: Array<{ key: TabKey; label: string; icon: typeof Server; show: boolean }> = [
    { key: 'connections', label: 'Conexões', icon: Server, show: hasAny('connections:read', 'connections:create', 'connections:update', 'connections:delete') },
    { key: 'backup', label: 'Backup', icon: DatabaseBackup, show: hasAny('backup:read', 'backup:execute', 'backup:create', 'backup:profiles') },
    { key: 'restore', label: 'Restauração', icon: HardDriveUpload, show: hasAny('restore:read', 'restore:execute', 'restore:create') },
    { key: 'schedules', label: 'Agendamentos', icon: CalendarClock, show: hasAny('schedules:read', 'schedules:manage', 'schedules:create') },
    { key: 'jobs', label: 'Jobs (Pipelines)', icon: Workflow, show: hasAny('jobs:read', 'schedules:manage', 'jobs:create') },
    { key: 'logs', label: 'Histórico e Logs', icon: Activity, show: hasAny('logs:read', 'logs:download') },
    { key: 'users', label: 'Conta e Acessos', icon: UserCog, show: true }
  ];

  const visibleNav = allNavItems.filter((item) => item.show);
  const currentTab = visibleNav.some((n) => n.key === activeTab)
    ? activeTab
    : (visibleNav[0]?.key ?? 'users');

  return (
    <div className="flex min-h-screen flex-col md:h-screen md:flex-row md:overflow-hidden">
      <aside
        className={cn(
          'flex w-full shrink-0 flex-col justify-between border-b border-border bg-card p-3 transition-all duration-200 md:h-screen md:border-b-0 md:border-r',
          sidebarCollapsed ? 'md:w-20' : 'md:w-64'
        )}
      >
        <div className="overflow-y-auto overflow-x-hidden">
          <div className={cn('mb-5 flex flex-col gap-2 px-1', sidebarCollapsed && 'items-center')}>
            <div className="flex items-center gap-2.5">
              <ShieldCheck className="h-7 w-7 shrink-0 text-primary" />
              {!sidebarCollapsed && (
                <div>
                  <div className="text-base font-bold leading-tight">PG Guard</div>
                  <div className="text-[11px] text-muted-foreground">
                    {user ? `${user.username} (${user.isMaster ? 'Master' : user.roleName})` : 'PostgreSQL Suite'}
                  </div>
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              className={cn(
                'hidden items-center gap-2 rounded-lg border border-border px-2.5 py-1.5 text-xs text-muted-foreground hover:bg-muted hover:text-foreground md:flex',
                sidebarCollapsed ? 'justify-center px-2' : 'w-full justify-center'
              )}
              title={sidebarCollapsed ? 'Expandir menu' : 'Encolher menu'}
            >
              {sidebarCollapsed ? <PanelLeftOpen className="h-4 w-4 shrink-0" /> : <PanelLeftClose className="h-4 w-4 shrink-0" />}
              {!sidebarCollapsed && <span>Recolher menu</span>}
            </button>
          </div>

          <nav className="space-y-1">
            {visibleNav.map((item) => {
              const Icon = item.icon;
              const active = currentTab === item.key;
              return (
                <button
                  key={item.key}
                  onClick={() => setActiveTab(item.key)}
                  title={item.label}
                  className={cn(
                    'flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition',
                    sidebarCollapsed && 'md:justify-center md:px-2',
                    active
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                  )}
                >
                  <Icon className="h-4 w-4 shrink-0" />
                  {!sidebarCollapsed && <span className="truncate">{item.label}</span>}
                </button>
              );
            })}
          </nav>
        </div>

        <div
          className={cn(
            'mt-4 flex shrink-0 items-center justify-between gap-2 border-t border-border pt-3',
            sidebarCollapsed && 'md:flex-col'
          )}
        >
          <Button
            variant="outline"
            size="sm"
            onClick={() => setDarkMode(!darkMode)}
            title={darkMode ? 'Mudar para tema claro' : 'Mudar para tema escuro'}
            className={sidebarCollapsed ? 'w-full justify-center px-2' : ''}
          >
            {darkMode ? <Sun className="h-4 w-4 shrink-0" /> : <Moon className="h-4 w-4 shrink-0" />}
            {!sidebarCollapsed && (darkMode ? 'Claro' : 'Escuro')}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            title="Sair do sistema"
            className={sidebarCollapsed ? 'w-full justify-center px-2' : ''}
            onClick={() => {
              setAuthToken(null);
              setAuthenticated(false);
              setUser(null);
            }}
          >
            <LogOut className="h-4 w-4 shrink-0" />
            {!sidebarCollapsed && 'Sair'}
          </Button>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto p-4 md:p-8">
        <div className="mx-auto max-w-6xl">
          {currentTab === 'connections' && <ConnectionsPage />}
          {currentTab === 'backup' && <BackupPage />}
          {currentTab === 'restore' && <RestorePage />}
          {currentTab === 'schedules' && <SchedulesPage />}
          {currentTab === 'jobs' && <JobsPage />}
          {currentTab === 'logs' && <LogsPage />}
          {currentTab === 'users' && (
            <UsersPage
              canManageUsers={perms.has('users:manage')}
              isMaster={Boolean(user?.isMaster)}
              userPermissions={user?.permissions ?? []}
            />
          )}
        </div>
      </main>
    </div>
  );
}

export default App;
