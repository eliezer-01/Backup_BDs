import fs from 'node:fs';
import path from 'node:path';
import { getDatabase } from '../db/sqlite';
import { resolveSafeBackupPath } from '../security/sanitizer';

export interface RetentionConfig {
  daily: number;
  weekly: number;
  monthly: number;
}

interface ExecutionFileRow {
  id: string;
  file_path: string;
  started_at: string;
}

/**
 * Calcula a chave de semana ISO (`YYYY-Www`) para agrupar backups semanais.
 *
 * @param date Objeto Date da execução do backup.
 * @example
 * getIsoWeekKey(new Date('2026-11-25T10:00:00Z')); // "2026-W48"
 */
function getIsoWeekKey(date: Date): string {
  const temp = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
  const dayNum = temp.getUTCDay() || 7;
  temp.setUTCDate(temp.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(temp.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil(((temp.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
  return `${temp.getUTCFullYear()}-W${String(weekNo).padStart(2, '0')}`;
}

/**
 * Aplica a política de rotação de backups (GFS simplificado: Diário, Semanal e Mensal)
 * para um perfil específico, removendo do disco os arquivos antigos excedentes.
 *
 * Mantém o arquivo mais recente de cada balde até atingir os limites configurados:
 * - `daily`: últimos X dias distintos
 * - `weekly`: últimas Y semanas distintas
 * - `monthly`: últimos Z meses distintos
 *
 * @param profileId UUID do perfil de backup.
 * @param config Quantidade de retenção diária, semanal e mensal.
 * @returns Quantidade de arquivos mantidos e removidos.
 * @example
 * const resultado = applyRetentionPolicy('uuid-perfil', { daily: 7, weekly: 4, monthly: 3 });
 */
export function applyRetentionPolicy(
  profileId: string,
  config: RetentionConfig
): { kept: number; removed: number; removedFiles: string[] } {
  const db = getDatabase();
  const rows = db
    .prepare(`
      SELECT id, file_path, started_at
      FROM executions
      WHERE profile_id = ? AND type = 'backup' AND status = 'success' AND file_path IS NOT NULL
      ORDER BY started_at DESC
    `)
    .all(profileId) as unknown as ExecutionFileRow[];

  const keptIds = new Set<string>();
  const dailyBuckets = new Set<string>();
  const weeklyBuckets = new Set<string>();
  const monthlyBuckets = new Set<string>();

  for (const row of rows) {
    const dt = new Date(row.started_at.includes('T') ? row.started_at : `${row.started_at}Z`);
    if (Number.isNaN(dt.getTime())) continue;

    const dayKey = dt.toISOString().slice(0, 10); // YYYY-MM-DD
    const weekKey = getIsoWeekKey(dt); // YYYY-Www
    const monthKey = dt.toISOString().slice(0, 7); // YYYY-MM

    let shouldKeep = false;

    if (dailyBuckets.size < config.daily && !dailyBuckets.has(dayKey)) {
      dailyBuckets.add(dayKey);
      shouldKeep = true;
    }

    if (weeklyBuckets.size < config.weekly && !weeklyBuckets.has(weekKey)) {
      weeklyBuckets.add(weekKey);
      shouldKeep = true;
    }

    if (monthlyBuckets.size < config.monthly && !monthlyBuckets.has(monthKey)) {
      monthlyBuckets.add(monthKey);
      shouldKeep = true;
    }

    if (shouldKeep) {
      keptIds.add(row.id);
    }
  }

  const removedFiles: string[] = [];

  for (const row of rows) {
    if (keptIds.has(row.id)) continue;

    try {
      const fileName = path.basename(row.file_path);
      const safePath = resolveSafeBackupPath(fileName);
      if (fs.existsSync(safePath)) {
        fs.rmSync(safePath, { recursive: true, force: true });
        removedFiles.push(fileName);
      }
      db.prepare('UPDATE executions SET file_path = NULL WHERE id = ?').run(row.id);
    } catch (err) {
      console.error(`Erro ao remover backup expirado (${row.file_path}):`, err);
    }
  }

  return {
    kept: keptIds.size,
    removed: removedFiles.length,
    removedFiles
  };
}
