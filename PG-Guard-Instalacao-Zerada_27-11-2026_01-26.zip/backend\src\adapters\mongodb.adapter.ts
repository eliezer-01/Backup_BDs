import {
  formatCommandPreview,
  resolveRuntimeHost,
  type BuiltCommand,
  type ConnectionDescriptor,
  type DatabaseAdapter
} from './base.adapter';

/**
 * Adaptador modular para MongoDB utilizando `mongodump` e `mongorestore`
 * no formato compactado `--archive=<arquivo> --gzip`.
 *
 * @example
 * const adapter = new MongoDbAdapter();
 */
export class MongoDbAdapter implements DatabaseAdapter {
  readonly engine = 'mongodb';

  private authArgs(conn: ConnectionDescriptor, password: string, maskPassword = false): string[] {
    return [
      '--host', resolveRuntimeHost(conn.host),
      '--port', String(conn.port),
      '--username', conn.username,
      '--password', maskPassword ? '***' : password,
      '--authenticationDatabase', conn.defaultDatabase || 'admin'
    ];
  }

  buildTestConnectionCommand(conn: ConnectionDescriptor, password: string): BuiltCommand {
    const args = [...this.authArgs(conn, password), '--quiet', '--archive=/dev/null', '--db', conn.defaultDatabase || 'admin'];
    const previewArgs = [...this.authArgs(conn, password, true), '--quiet', '--archive=/dev/null', '--db', conn.defaultDatabase || 'admin'];
    return {
      binary: 'mongodump',
      args,
      envVars: {},
      preview: formatCommandPreview('mongodump', previewArgs)
    };
  }

  buildListDatabasesCommand(conn: ConnectionDescriptor, password: string): BuiltCommand {
    // mongodump não lista bancos diretamente; retorna o banco padrão configurado para seleção
    const db = conn.defaultDatabase || 'admin';
    return {
      binary: 'node',
      args: ['-e', `console.log(${JSON.stringify(db)})`],
      envVars: {},
      preview: `mongodb://${conn.username}@${resolveRuntimeHost(conn.host)}:${conn.port}/${db}`
    };
  }

  buildBackupCommand(
    conn: ConnectionDescriptor,
    password: string,
    rawParams: Record<string, unknown>,
    outputPath: string
  ): BuiltCommand {
    const dbName = (rawParams.databaseName as string) || conn.defaultDatabase || 'admin';
    const args = [
      ...this.authArgs(conn, password),
      '--db', dbName,
      `--archive=${outputPath}`,
      '--gzip'
    ];
    const previewArgs = [
      ...this.authArgs(conn, password, true),
      '--db', dbName,
      `--archive=${outputPath}`,
      '--gzip'
    ];

    return {
      binary: 'mongodump',
      args,
      envVars: {},
      preview: formatCommandPreview('mongodump', previewArgs)
    };
  }

  buildRestoreCommand(
    conn: ConnectionDescriptor,
    password: string,
    rawParams: Record<string, unknown>,
    inputPath: string
  ): BuiltCommand {
    const targetDb = (rawParams.targetDatabase as string) || conn.defaultDatabase || 'admin';
    const args = [
      ...this.authArgs(conn, password),
      `--archive=${inputPath}`,
      '--gzip',
      '--nsFrom', '*.*',
      '--nsTo', `${targetDb}.*`
    ];
    if (rawParams.clean) {
      args.push('--drop');
    }

    const previewArgs = [
      ...this.authArgs(conn, password, true),
      `--archive=${inputPath}`,
      '--gzip',
      '--nsFrom', '*.*',
      '--nsTo', `${targetDb}.*`,
      ...(rawParams.clean ? ['--drop'] : [])
    ];

    return {
      binary: 'mongorestore',
      args,
      envVars: {},
      preview: formatCommandPreview('mongorestore', previewArgs)
    };
  }
}
