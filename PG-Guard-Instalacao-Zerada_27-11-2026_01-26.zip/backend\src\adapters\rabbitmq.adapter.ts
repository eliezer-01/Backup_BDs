import path from 'node:path';
import {
  formatCommandPreview,
  resolveRuntimeHost,
  type BuiltCommand,
  type ConnectionDescriptor,
  type DatabaseAdapter
} from './base.adapter';

/**
 * Adaptador modular para RabbitMQ utilizando a Management HTTP API
 * (`/api/definitions` para backup e restauração de filas, exchanges e bindings).
 * A senha é isolada na variável de ambiente `RABBIT_PASSWORD`.
 *
 * @example
 * const adapter = new RabbitMqAdapter();
 */
export class RabbitMqAdapter implements DatabaseAdapter {
  readonly engine = 'rabbitmq';

  private buildBaseUrl(conn: ConnectionDescriptor): string {
    const protocol = conn.sslMode === 'require' || conn.sslMode === 'verify-full' ? 'https' : 'http';
    return `${protocol}://${resolveRuntimeHost(conn.host)}:${conn.port}`;
  }

  private cliPath(): string {
    return path.resolve(__dirname, 'rabbitmq-cli.js');
  }

  buildTestConnectionCommand(conn: ConnectionDescriptor, password: string): BuiltCommand {
    const url = this.buildBaseUrl(conn);
    const args = [this.cliPath(), 'test', url, conn.username];
    return {
      binary: 'node',
      args,
      envVars: { RABBIT_PASSWORD: password },
      preview: formatCommandPreview('rabbitmq-api', ['test', url, conn.username])
    };
  }

  buildListDatabasesCommand(conn: ConnectionDescriptor, password: string): BuiltCommand {
    const url = this.buildBaseUrl(conn);
    const args = [this.cliPath(), 'list-vhosts', url, conn.username];
    return {
      binary: 'node',
      args,
      envVars: { RABBIT_PASSWORD: password },
      preview: formatCommandPreview('rabbitmq-api', ['list-vhosts', url, conn.username])
    };
  }

  buildBackupCommand(
    conn: ConnectionDescriptor,
    password: string,
    _rawParams: Record<string, unknown>,
    outputPath: string
  ): BuiltCommand {
    const url = this.buildBaseUrl(conn);
    const args = [this.cliPath(), 'backup', url, conn.username, outputPath];
    return {
      binary: 'node',
      args,
      envVars: { RABBIT_PASSWORD: password },
      preview: formatCommandPreview('rabbitmq-api', ['backup', `${url}/api/definitions`, outputPath])
    };
  }

  buildRestoreCommand(
    conn: ConnectionDescriptor,
    password: string,
    _rawParams: Record<string, unknown>,
    inputPath: string
  ): BuiltCommand {
    const url = this.buildBaseUrl(conn);
    const args = [this.cliPath(), 'restore', url, conn.username, inputPath];
    return {
      binary: 'node',
      args,
      envVars: { RABBIT_PASSWORD: password },
      preview: formatCommandPreview('rabbitmq-api', ['restore', `${url}/api/definitions`, inputPath])
    };
  }
}
