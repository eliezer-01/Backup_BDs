import {
  formatCommandPreview,
  resolveRuntimeHost,
  type BuiltCommand,
  type ConnectionDescriptor,
  type DatabaseAdapter
} from './base.adapter';

/**
 * Adaptador modular para Microsoft SQL Server utilizando `sqlcmd`.
 * A senha é repassada de forma isolada via variável de ambiente `SQLCMDPASSWORD`.
 *
 * @example
 * const adapter = new SqlServerAdapter();
 */
export class SqlServerAdapter implements DatabaseAdapter {
  readonly engine = 'sqlserver';

  private buildEnv(password: string): Record<string, string> {
    return { SQLCMDPASSWORD: password };
  }

  private baseArgs(conn: ConnectionDescriptor): string[] {
    return [
      '-S', `${resolveRuntimeHost(conn.host)},${conn.port}`,
      '-U', conn.username,
      '-C' // TrustServerCertificate para ambientes locais/TLS autoassinado
    ];
  }

  buildTestConnectionCommand(conn: ConnectionDescriptor, password: string): BuiltCommand {
    const args = [...this.baseArgs(conn), '-d', conn.defaultDatabase || 'master', '-Q', 'SELECT 1;'];
    return {
      binary: 'sqlcmd',
      args,
      envVars: this.buildEnv(password),
      preview: formatCommandPreview('sqlcmd', args)
    };
  }

  buildListDatabasesCommand(conn: ConnectionDescriptor, password: string): BuiltCommand {
    const args = [
      ...this.baseArgs(conn),
      '-d', 'master',
      '-h', '-1',
      '-W',
      '-Q',
      'SET NOCOUNT ON; SELECT name FROM sys.databases WHERE database_id > 4 ORDER BY name;'
    ];
    return {
      binary: 'sqlcmd',
      args,
      envVars: this.buildEnv(password),
      preview: formatCommandPreview('sqlcmd', args)
    };
  }

  buildCreateDatabaseCommand(
    conn: ConnectionDescriptor,
    password: string,
    targetDatabase: string
  ): BuiltCommand {
    const safeDb = targetDatabase.replace(/[\[\]]/g, '');
    const args = [
      ...this.baseArgs(conn),
      '-d', 'master',
      '-Q',
      `IF DB_ID(N'${safeDb}') IS NULL CREATE DATABASE [${safeDb}];`
    ];
    return {
      binary: 'sqlcmd',
      args,
      envVars: this.buildEnv(password),
      preview: formatCommandPreview('sqlcmd', args)
    };
  }

  buildBackupCommand(
    conn: ConnectionDescriptor,
    password: string,
    rawParams: Record<string, unknown>,
    outputPath: string
  ): BuiltCommand {
    const dbName = ((rawParams.databaseName as string) || conn.defaultDatabase || 'master').replace(/[\[\]]/g, '');
    const args = [
      ...this.baseArgs(conn),
      '-d', 'master',
      '-Q',
      `BACKUP DATABASE [${dbName}] TO DISK = N'${outputPath}' WITH INIT, COMPRESSION, STATS = 10;`
    ];
    return {
      binary: 'sqlcmd',
      args,
      envVars: this.buildEnv(password),
      preview: formatCommandPreview('sqlcmd', args)
    };
  }

  buildRestoreCommand(
    conn: ConnectionDescriptor,
    password: string,
    rawParams: Record<string, unknown>,
    inputPath: string
  ): BuiltCommand {
    const targetDb = ((rawParams.targetDatabase as string) || conn.defaultDatabase).replace(/[\[\]]/g, '');
    const replaceClause = rawParams.clean ? ', REPLACE' : '';
    const args = [
      ...this.baseArgs(conn),
      '-d', 'master',
      '-Q',
      `RESTORE DATABASE [${targetDb}] FROM DISK = N'${inputPath}' WITH RECOVERY${replaceClause}, STATS = 10;`
    ];
    return {
      binary: 'sqlcmd',
      args,
      envVars: this.buildEnv(password),
      preview: formatCommandPreview('sqlcmd', args)
    };
  }
}
