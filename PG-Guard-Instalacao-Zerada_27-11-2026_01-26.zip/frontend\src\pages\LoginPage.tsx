import { useState, type FormEvent } from 'react';
import { Lock, ShieldCheck } from 'lucide-react';
import { apiRequest, setAuthToken } from '../services/api';
import { Button, Card, Input } from '../components/ui';

/**
 * Tela de login obrigatória do painel. Autentica via JWT e armazena o token localmente.
 *
 * @example
 * <LoginPage onLoginSuccess={(user) => setUser(user)} />
 */
export function LoginPage({
  onLoginSuccess
}: {
  onLoginSuccess: (username: string) => void;
}) {
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const data = await apiRequest<{ token: string; user: { username: string } }>(
        '/api/auth/login',
        {
          method: 'POST',
          body: JSON.stringify({ username, password })
        }
      );
      setAuthToken(data.token);
      onLoginSuccess(data.user.username);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md p-6">
        <div className="mb-6 flex flex-col items-center text-center">
          <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <ShieldCheck className="h-7 w-7" />
          </div>
          <h1 className="text-xl font-bold">PG Guard</h1>
          <p className="text-sm text-muted-foreground">
            Gerenciador Seguro de Backups e Restaurações
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">Usuário</label>
            <Input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="admin"
              required
            />
          </div>

          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">Senha</label>
            <Input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
            />
          </div>

          {error && (
            <div className="rounded-lg bg-destructive/15 p-3 text-xs text-destructive">
              {error}
            </div>
          )}

          <Button type="submit" className="w-full" disabled={loading}>
            <Lock className="h-4 w-4" />
            {loading ? 'Autenticando...' : 'Entrar no Painel'}
          </Button>
        </form>
      </Card>
    </div>
  );
}
