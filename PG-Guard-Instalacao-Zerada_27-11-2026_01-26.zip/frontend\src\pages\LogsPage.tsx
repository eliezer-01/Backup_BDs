import { useEffect, useState } from 'react';
import { Download, Eye, RefreshCw } from 'lucide-react';
import { apiRequest, downloadBackupFile } from '../services/api';
import { Badge, Button, Card } from '../components/ui';
import { LiveConsole } from '../components/LiveConsole';

interface ExecutionRow {
  id: string;
  type: 'backup' | 'restore';
  database_name: string | null;
  status: 'running' | 'success' | 'error';
  command_preview: string;
  file_path: string | null;
  file_size_bytes: number | null;
  started_at: string;
  duration_ms: number | null;
  source_connection_name: string | null;
  target_connection_name: string | null;
}

/**
 * Tela de Monitoramento, Console em Tempo Real e Histórico de Execuções com download.
 *
 * @example
 * <LogsPage />
 */
export function LogsPage() {
  const [executions, setExecutions] = useState<ExecutionRow[]>([]);
  const [selectedLog, setSelectedLog] = useState<string | null>(null);

  async function loadExecutions() {
    const res = await apiRequest<{ executions: ExecutionRow[] }>('/api/executions');
    setExecutions(res.executions);
  }

  useEffect(() => {
    void loadExecutions();
  }, []);

  async function handleViewLog(id: string) {
    const res = await apiRequest<{ execution: { log_output: string | null; error_message: string | null } }>(
      `/api/executions/${id}`
    );
    setSelectedLog(res.execution.log_output || res.execution.error_message || 'Sem saída registrada.');
  }

  async function handleDownload(row: ExecutionRow) {
    if (!row.file_path) return;
    const parts = row.file_path.split(/[\\/]/);
    const fileName = parts[parts.length - 1] || 'backup.backup';
    try {
      await downloadBackupFile(row.id, fileName);
    } catch (err) {
      alert((err as Error).message);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Monitoramento e Histórico</h2>
          <p className="text-sm text-muted-foreground">
            Acompanhe execuções ao vivo e faça download dos arquivos de backup gerados.
          </p>
        </div>
        <Button variant="outline" onClick={() => void loadExecutions()}>
          <RefreshCw className="h-4 w-4" />
          Atualizar
        </Button>
      </div>

      <LiveConsole />

      {selectedLog !== null && (
        <Card className="p-4">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-sm font-semibold">Log Completo da Execução</span>
            <Button variant="ghost" size="sm" onClick={() => setSelectedLog(null)}>
              Fechar
            </Button>
          </div>
          <pre className="max-h-64 overflow-auto rounded-lg bg-slate-950 p-3 font-mono text-xs text-slate-200">
            {selectedLog}
          </pre>
        </Card>
      )}

      <Card className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-border bg-muted/50 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Tipo</th>
              <th className="px-4 py-3">Conexão / Banco</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Duração</th>
              <th className="px-4 py-3">Tamanho</th>
              <th className="px-4 py-3">Data</th>
              <th className="px-4 py-3 text-right">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {executions.map((row) => (
              <tr key={row.id} className="hover:bg-muted/30">
                <td className="px-4 py-3 font-medium">
                  {row.type === 'backup' ? 'Backup' : 'Restauração'}
                </td>
                <td className="px-4 py-3">
                  <div className="font-medium">{row.source_connection_name || row.target_connection_name || '-'}</div>
                  <div className="text-xs text-muted-foreground">{row.database_name}</div>
                </td>
                <td className="px-4 py-3">
                  <Badge tone={row.status}>
                    {row.status === 'success' ? 'Sucesso' : row.status === 'error' ? 'Erro' : 'Executando'}
                  </Badge>
                </td>
                <td className="px-4 py-3 text-xs">
                  {row.duration_ms !== null ? `${(row.duration_ms / 1000).toFixed(2)}s` : '-'}
                </td>
                <td className="px-4 py-3 text-xs">
                  {row.file_size_bytes !== null ? `${(row.file_size_bytes / 1024 / 1024).toFixed(2)} MB` : '-'}
                </td>
                <td className="px-4 py-3 text-xs text-muted-foreground">
                  {new Date(row.started_at.includes('T') ? row.started_at : `${row.started_at}Z`).toLocaleString('pt-BR')}
                </td>
                <td className="px-4 py-3 text-right">
                  <div className="inline-flex gap-1">
                    <Button variant="ghost" size="sm" onClick={() => void handleViewLog(row.id)}>
                      <Eye className="h-3.5 w-3.5" />
                      Log
                    </Button>
                    {row.type === 'backup' && row.file_path && row.status === 'success' && (
                      <Button variant="outline" size="sm" onClick={() => void handleDownload(row)}>
                        <Download className="h-3.5 w-3.5" />
                        Baixar
                      </Button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
