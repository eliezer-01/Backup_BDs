@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion

title PG Guard - Instalador, Atualizador e Inicializador (Windows)
cd /d "%~dp0"

echo ========================================================================
echo   PG Guard - Instalacao, Atualizacao e Inicializacao (Windows)
echo ========================================================================
echo.

set "DOCKER_BIN=C:\Program Files\Docker\Docker\resources\bin"
set "DOCKER_EXE=C:\Program Files\Docker\Docker\Docker Desktop.exe"
if not exist "atualizacao" mkdir "atualizacao"

:: 1. Garante que docker.exe esteja no PATH ou instala via winget
where docker >nul 2>&1
if %errorlevel% equ 0 goto VERIFICA_DAEMON

if exist "%DOCKER_BIN%\docker.exe" (
    set "PATH=%DOCKER_BIN%;%PATH%"
    goto VERIFICA_DAEMON
)

echo [0/5] Docker Desktop nao encontrado. Verificando WSL2 antes de instalar o Docker...
wsl --status >nul 2>&1
if %errorlevel% neq 0 (
    echo [0/5] WSL2 nao esta ativo/instalado. Instalando WSL2 (obrigatorio para o Docker Desktop)...
    wsl --install --no-distribution
    if !errorlevel! neq 0 (
        echo [AVISO] Nao foi possivel concluir a instalacao automatica do WSL2.
        echo         Tente executar este .bat como Administrador ou rode: wsl --install
    ) else (
        echo [OK] WSL2 instalado! Pode ser necessario reiniciar o Windows antes do Docker iniciar.
    )
)

echo [0/5] Instalando Docker Desktop automaticamente via winget...
where winget >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERRO] winget nao encontrado para instalar o Docker automaticamente.
    echo Baixe e instale manualmente em: https://www.docker.com/products/docker-desktop/
    pause
    exit /b 1
)

winget install -e --id Docker.DockerDesktop --accept-package-agreements --accept-source-agreements
if %errorlevel% neq 0 (
    echo [ERRO] Falha ao instalar o Docker Desktop via winget.
    pause
    exit /b 1
)

if exist "%DOCKER_BIN%\docker.exe" (
    set "PATH=%DOCKER_BIN%;%PATH%"
) else (
    echo.
    echo [AVISO] Docker Desktop instalado, mas exige reinicializacao do Windows
    echo         para concluir a configuracao do WSL2/Hyper-V.
    echo         Reinicie o computador e execute este .bat novamente.
    pause
    exit /b 0
)

:VERIFICA_DAEMON
:: 2. Verifica se o Docker Desktop esta rodando; se nao estiver, inicia e aguarda ficar pronto
docker info >nul 2>&1
if %errorlevel% equ 0 goto DOCKER_PRONTO

echo [0/5] Iniciando Docker Desktop automaticamente...
if not exist "%DOCKER_EXE%" (
    echo [ERRO] Executavel do Docker Desktop nao encontrado em "%DOCKER_EXE%".
    pause
    exit /b 1
)

start "" "%DOCKER_EXE%"
set /a TENTATIVAS=0

:AGUARDAR_DOCKER
set /a TENTATIVAS+=1
if !TENTATIVAS! gtr 40 (
    echo.
    echo [ERRO] O Docker Desktop demorou mais que o esperado para iniciar.
    echo        Verifique se ele esta pedindo aceite de termos ou reinicializacao do Windows.
    pause
    exit /b 1
)
echo        Aguardando motor do Docker iniciar (!TENTATIVAS!/40)...
timeout /t 3 /nobreak >nul
docker info >nul 2>&1
if %errorlevel% neq 0 goto AGUARDAR_DOCKER

:DOCKER_PRONTO
echo [OK] Docker Desktop pronto!

:: Verifica se o Docker Desktop esta configurado para iniciar automaticamente com o Windows
set "AUTO_START_OK=0"
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "Docker Desktop" >nul 2>&1
if %errorlevel% equ 0 set "AUTO_START_OK=1"
if "!AUTO_START_OK!"=="0" (
    for /f "usebackq delims=" %%A in (`powershell -NoProfile -Command "$s = Join-Path $env:APPDATA 'Docker\settings-store.json'; if (-not (Test-Path $s)) { $s = Join-Path $env:APPDATA 'Docker\settings.json' }; if (Test-Path $s) { try { $j = Get-Content $s -Raw | ConvertFrom-Json; if ($j.AutoStart -eq $true -or $j.autoStart -eq $true) { '1' } else { '0' } } catch { '0' } } else { '0' }"`) do set "AUTO_START_OK=%%A"
)

if "!AUTO_START_OK!"=="1" (
    echo [OK] Inicializacao automatica com o Windows ja esta ATIVA.
    goto APOS_AUTOSTART
)

echo.
echo [AVISO] O Docker Desktop NAO esta configurado para iniciar com o Windows.
echo         Sem isso, agendamentos automaticos nao rodam se a maquina reiniciar.
set "RESP_AUTO=N"
set /p "RESP_AUTO=Deseja ativar a inicializacao automatica ao ligar o Windows? (S/N) [N]: "
if /i "!RESP_AUTO!"=="S" (
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "Docker Desktop" /t REG_SZ /d "\"%DOCKER_EXE%\"" /f >nul 2>&1
    if !errorlevel! equ 0 (
        echo [OK] Inicializacao automatica ativada! Ao ligar o Windows, o sistema subira sozinho.
    ) else (
        echo [AVISO] Nao foi possivel gravar no registro. Ative manualmente nas configuracoes do Docker Desktop.
    )
) else (
    echo [OK] Mantido como inicializacao manual.
)

:APOS_AUTOSTART

:: Limpa cache de build residual do Docker se houver pouco espaco ou residuo antigo
docker builder prune -f >nul 2>&1
docker image prune -f >nul 2>&1

:: 3. Verifica atualizacoes na pasta .\atualizacao\ ou via argumento arrastado (%~1)
set "UPDATE_SRC=%~1"
set "FROM_DEFAULT_DIR=0"
set "HAS_UPDATE_FILES=0"
set "NEEDS_BUILD=0"

if /i "%~1"=="--rebuild" (
    set "UPDATE_SRC="
    set "NEEDS_BUILD=1"
)

if "%UPDATE_SRC%"=="" (
    for /f "usebackq delims=" %%C in (`powershell -NoProfile -Command "@(Get-ChildItem -Path 'atualizacao' -Force | Where-Object { $_.Name -ne 'LEIA-ME.txt' }).Count"`) do set "HAS_UPDATE_FILES=%%C"
    if !HAS_UPDATE_FILES! gtr 0 (
        set "UPDATE_SRC=%~dp0atualizacao"
        set "FROM_DEFAULT_DIR=1"
    )
)

if not "%UPDATE_SRC%"=="" (
    set "UPDATE_SRC=%UPDATE_SRC:"=%"
    if not exist "!UPDATE_SRC!" (
        echo [ERRO] Pasta de atualizacao nao encontrada: "!UPDATE_SRC!"
        pause
        exit /b 1
    )

    echo [1/5] Mudancas detectadas em "!UPDATE_SRC!". Substituindo arquivos...
    set "NEEDS_BUILD=1"

    :: Mantem apenas 1 backup de seguranca mais recente do SQLite (remove .bak antigos para nao encher o disco)
    if exist "data\db\app.sqlite.bak" del /f /q "data\db\app.sqlite.bak" >nul 2>&1
    if exist "data\db\app.sqlite" copy /y "data\db\app.sqlite" "data\db\app.sqlite.bak" >nul

    robocopy "!UPDATE_SRC!" "." /E /XD data node_modules dist .git atualizacao /XF .env *.sqlite LEIA-ME.txt /NFL /NDL /NJH /NJS >nul
    if !errorlevel! geq 8 (
        echo [ERRO] Falha ao copiar arquivos da pasta de atualizacao.
        pause
        exit /b 1
    )

    if "!FROM_DEFAULT_DIR!"=="1" (
        powershell -NoProfile -Command "Get-ChildItem -Path 'atualizacao' -Force | Where-Object { $_.Name -ne 'LEIA-ME.txt' } | Remove-Item -Recurse -Force"
        echo [OK] Pasta .\atualizacao\ limpa apos aplicar as mudancas.
    )
    echo [OK] Arquivos atualizados mantendo seus dados e senhas!
) else (
    echo [1/5] Nenhuma atualizacao nova em .\atualizacao\. Apenas iniciando o sistema...
)

:: 4. Verifica/cria .env na 1a vez ou mescla novas variaveis do .env.example sem sobrescrever as atuais
if not exist ".env" (
    echo [2/5] Primeira instalacao detectada. Gerando arquivo .env seguro...
    set "NEEDS_BUILD=1"
    if not exist ".env.example" (
        echo [ERRO] Arquivo .env.example nao encontrado.
        pause
        exit /b 1
    )

    for /f "usebackq delims=" %%K in (`powershell -NoProfile -Command "$b = New-Object byte[] 32; [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b); ($b | ForEach-Object { $_.ToString('x2') }) -join ''"`) do set "GEN_MASTER_KEY=%%K"
    for /f "usebackq delims=" %%J in (`powershell -NoProfile -Command "$b = New-Object byte[] 24; [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b); [Convert]::ToBase64String($b)"`) do set "GEN_JWT_SECRET=%%J"

    powershell -NoProfile -Command ^
        "$content = Get-Content '.env.example' -Raw;" ^
        "$content = $content -replace 'MASTER_ENCRYPTION_KEY=.*', ('MASTER_ENCRYPTION_KEY=' + '!GEN_MASTER_KEY!');" ^
        "$content = $content -replace 'JWT_SECRET=.*', ('JWT_SECRET=' + '!GEN_JWT_SECRET!');" ^
        "$content = $content -replace 'CUSTOM_BACKUP_HOST_DIR=.*', 'CUSTOM_BACKUP_HOST_DIR=C:\';" ^
        "[System.IO.File]::WriteAllText((Join-Path (Get-Location) '.env'), $content, [System.Text.UTF8Encoding]::new($false))"

    echo [OK] Arquivo .env criado com chaves criptograficas aleatorias!
) else (
    echo [2/5] Arquivo .env preservado.
    if exist ".env.example" (
        powershell -NoProfile -Command ^
            "$envLines = Get-Content '.env';" ^
            "$existingKeys = @{};" ^
            "foreach ($l in $envLines) { if ($l -match '^\s*([A-Za-z0-9_]+)\s*=') { $existingKeys[$matches[1]] = $true } };" ^
            "$added = @();" ^
            "foreach ($ex in Get-Content '.env.example') { if ($ex -match '^\s*([A-Za-z0-9_]+)\s*=' -and -not $existingKeys.ContainsKey($matches[1])) { $added += $ex } };" ^
            "if ($added.Count -gt 0) { Add-Content -Path '.env' -Value (\"`n# Novas variaveis adicionadas na atualizacao`n\" + ($added -join \"`n\")); Write-Host ('[OK] ' + $added.Count + ' nova(s) variavel(is) adicionada(s) ao .env') }"
    )
)

:: 5. Garante diretorios persistentes de banco SQLite e backups
if not exist "data\db" mkdir "data\db"
if not exist "data\backups" mkdir "data\backups"

:: Verifica se as imagens ja existem localmente; se nao existirem, precisa buildar
for /f "usebackq delims=" %%I in (`powershell -NoProfile -Command "@(docker compose images -q 2>$null | Where-Object { $_ -ne '' }).Count"`) do set "IMG_COUNT=%%I"
if "!IMG_COUNT!"=="" set "IMG_COUNT=0"
if !IMG_COUNT! lss 2 set "NEEDS_BUILD=1"

:: Detecta automaticamente se houve alteracao em codigo/Dockerfile desde o ultimo build
for /f "usebackq delims=" %%H in (`powershell -NoProfile -Command "$files = Get-ChildItem -Path 'backend','frontend','docker-compose.yml' -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.FullName -notmatch '\\(node_modules|dist)\\' } | Sort-Object FullName; $raw = ($files | ForEach-Object { $_.FullName + $_.Length + $_.LastWriteTimeUtc.Ticks }) -join '|'; $bytes = [System.Text.Encoding]::UTF8.GetBytes($raw); $sha = [System.Security.Cryptography.SHA256]::Create().ComputeHash($bytes); ($sha | ForEach-Object { $_.ToString('x2') }) -join ''"`) do set "CURRENT_HASH=%%H"
set "LAST_HASH="
if exist "data\.last_build_hash" set /p LAST_HASH=<"data\.last_build_hash"
if not "!CURRENT_HASH!"=="!LAST_HASH!" set "NEEDS_BUILD=1"

:: 6. Sobe os containers (so recompila quando necessario para nao consumir disco)
if "!NEEDS_BUILD!"=="1" (
    echo [3/5] Construindo/atualizando imagens e iniciando os containers...
    docker compose up -d --build --remove-orphans
) else (
    echo [3/5] Imagens ja prontas. Iniciando containers sem gastar disco extra...
    docker compose up -d --remove-orphans
)

if %errorlevel% neq 0 (
    echo.
    echo [ERRO] Falha ao iniciar os containers.
    pause
    exit /b 1
)

if "!NEEDS_BUILD!"=="1" (
    >"data\.last_build_hash" echo !CURRENT_HASH!
)

:: 7. Limpa imagens antigas e cache de build para nao deixar residuos no disco
echo [4/5] Limpando residuos e cache de build do Docker...
docker image prune -f >nul 2>&1
docker builder prune -f >nul 2>&1

:: Descobre a porta configurada no .env (padrao 8080)
set "APP_PORT=8080"
for /f "usebackq tokens=1,* delims==" %%A in (".env") do (
    if /i "%%A"=="APP_PORT" set "APP_PORT=%%B"
)

:: 8. Aguarda o sistema responder antes de abrir no navegador
echo [5/5] Aguardando sistema iniciar em http://localhost:%APP_PORT% ...
powershell -NoProfile -Command ^
    "for ($i = 1; $i -le 20; $i++) { try { $r = Invoke-WebRequest -Uri 'http://localhost:%APP_PORT%/api/health' -UseBasicParsing -TimeoutSec 2; if ($r.StatusCode -eq 200) { exit 0 } } catch {}; Start-Sleep -Seconds 2 }"

echo.
echo ========================================================================
echo   Sistema iniciado e rodando com sucesso!
echo   Acesse: http://localhost:%APP_PORT%
echo ========================================================================
echo.
docker compose ps
echo.

start "" "http://localhost:%APP_PORT%"
pause
