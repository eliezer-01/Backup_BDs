import path from 'node:path';
import { z } from 'zod';

/**
 * Esquema de validação estrita das variáveis de ambiente.
 * Garante que o sistema não inicialize sem a chave mestra AES-256-GCM ou segredo JWT.
 *
 * @example
 * // No arquivo .env:
 * // MASTER_ENCRYPTION_KEY=0123... (64 caracteres hex)
 * // JWT_SECRET=segredo_super_seguro
 */
const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.coerce.number().int().min(1).max(65535).default(3001),
  TZ: z.string().min(1).default('America/Sao_Paulo'),
  DB_PATH: z.string().min(1).default(path.resolve(process.cwd(), '../data/db/app.sqlite')),
  BACKUP_DIR: z.string().min(1).default(path.resolve(process.cwd(), '../data/backups')),
  CUSTOM_BACKUP_DIR: z.string().min(1).default(path.resolve(process.cwd(), '../data/custom')),
  MASTER_ENCRYPTION_KEY: z
    .string()
    .regex(/^[0-9a-fA-F]{64}$/, 'MASTER_ENCRYPTION_KEY deve conter exatamente 64 caracteres hexadecimais (32 bytes).'),
  JWT_SECRET: z.string().min(16, 'JWT_SECRET deve ter pelo menos 16 caracteres.'),
  ADMIN_USER: z.string().min(3).default('admin'),
  ADMIN_PASSWORD: z.string().min(6, 'ADMIN_PASSWORD deve ter pelo menos 6 caracteres.')
});

const parsed = envSchema.safeParse(process.env);

if (!parsed.success) {
  console.error('❌ Erro na validação das variáveis de ambiente (.env):');
  for (const issue of parsed.error.issues) {
    console.error(`  - ${issue.path.join('.')}: ${issue.message}`);
  }
  process.exit(1);
}

/**
 * Configurações validadas e imutáveis da aplicação.
 */
export const env = parsed.data;
