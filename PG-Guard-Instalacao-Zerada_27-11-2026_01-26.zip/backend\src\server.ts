import Fastify from 'fastify';
import cors from '@fastify/cors';
import jwt from '@fastify/jwt';
import multipart from '@fastify/multipart';
import websocket from '@fastify/websocket';
import { env } from './config/env';
import { getDatabase } from './db/sqlite';
import { ensureInitialAdminUser } from './security/auth';
import { registerWsClient } from './services/runner.service';
import { authRoutes } from './routes/auth.routes';
import { connectionsRoutes } from './routes/connections.routes';
import { backupsRoutes } from './routes/backups.routes';
import { restoresRoutes } from './routes/restores.routes';
import { executionsRoutes } from './routes/executions.routes';
import { schedulesRoutes } from './routes/schedules.routes';
import { usersRoutes } from './routes/users.routes';
import { smtpRoutes } from './routes/smtp.routes';
import { jobsRoutes } from './routes/jobs.routes';
import { sharesRoutes } from './routes/shares.routes';
import { initScheduler } from './services/scheduler.service';
import { initJobsScheduler } from './services/jobs.service';

/**
 * Inicializa o servidor Fastify com plugins de segurança, WebSocket em tempo real
 * e todas as rotas da API REST.
 */
async function bootstrap(): Promise<void> {
  getDatabase();
  ensureInitialAdminUser();

  const app = Fastify({ logger: true });

  await app.register(cors, {
    origin: true,
    credentials: true
  });

  await app.register(jwt, {
    secret: env.JWT_SECRET
  });

  await app.register(multipart, {
    limits: {
      fileSize: 1024 * 1024 * 1024 * 5 // Limite de 5 GB para upload de backups
    }
  });

  await app.register(websocket);

  // Rota WebSocket autenticada via query string (?token=...) para streaming de logs
  app.get('/ws/logs', { websocket: true }, (socket, request) => {
    const query = request.query as { token?: string };
    if (!query.token) {
      socket.close(1008, 'Token ausente');
      return;
    }

    try {
      app.jwt.verify(query.token);
      registerWsClient(socket);
    } catch {
      socket.close(1008, 'Token inválido');
    }
  });

  app.get('/api/health', async () => ({ status: 'ok', timestamp: new Date().toISOString() }));

  await app.register(authRoutes, { prefix: '/api/auth' });
  await app.register(connectionsRoutes, { prefix: '/api/connections' });
  await app.register(backupsRoutes, { prefix: '/api/backups' });
  await app.register(restoresRoutes, { prefix: '/api/restores' });
  await app.register(executionsRoutes, { prefix: '/api/executions' });
  await app.register(schedulesRoutes, { prefix: '/api/schedules' });
  await app.register(usersRoutes, { prefix: '/api/users' });
  await app.register(smtpRoutes, { prefix: '/api/smtp' });
  await app.register(jobsRoutes, { prefix: '/api/jobs' });
  await app.register(sharesRoutes, { prefix: '/api/shares' });

  initScheduler();
  initJobsScheduler();

  await app.listen({ port: env.PORT, host: '0.0.0.0' });
  console.log(`🚀 Backend rodando na porta ${env.PORT}`);
}

bootstrap().catch((err) => {
  console.error('Erro fatal ao iniciar servidor:', err);
  process.exit(1);
});
