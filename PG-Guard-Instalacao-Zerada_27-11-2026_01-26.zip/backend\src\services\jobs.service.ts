import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import cron, { type ScheduledTask } from 'node-cron';
import { env } from '../config/env';
import { getDatabase } from '../db/sqlite';
import { getDatabaseAdapter } from '../adapters/registry';
import { buildBackupFileName } from '../routes/backups.routes';
import { resolveSafeFolderDir } from '../security/sanitizer';
import { getDecryptedConnection } from './connections.service';
import { sendJobAlertEmail, type JobStepReport } from './email.service';
import { runQuickCommand, runTrackedExecution } from './runner.service';
import { computeNextRun } from './scheduler.service';

interface JobRow {
  id: string;
  name: string;
  cron_expression: string;
  is_active: number;
  stop_on_error: number;
  notify_email_to: string | null;
  notify_on_success: number;
  notify_on_error: number;
}

interface JobStepRow {
  id: string;
  job_id: string;
  step_order: number;
  step_type: 'backup' | 'restore';
  profile_id: string | null;
  restore_profile_id: string | null;
  source_connection_id: string | null;
  source_database: string | null;
  target_connection_id: string | null;
  target_database: string | null;
  use_previous_backup: number;
  restore_options_json: string | null;
}

interface ProfileJoinRow {
  id: string;
  name: string;
  connection_id: string;
  database_name: string | null;
  dump_type: 'pg_dump' | 'pg_dumpall';
  options_json: string;
  target_folder: string | null;
}

const activeJobTasks = new Map<string, ScheduledTask>();

/**
 * Executa todas as etapas de um Job sequencialmente (backups e/ou restaurações)
 * e envia 1 único e-mail consolidado ao término com o status de cada etapa.
 *
 * @param jobId UUID do Job cadastrado.
 * @example
 * void executeJob('uuid-do-job');
 */
export async function executeJob(jobId: string): Promise<void> {
  const db = getDatabase();
  const job = db.prepare('SELECT * FROM jobs WHERE id = ?').get(jobId) as JobRow | undefined;
  if (!job) return;

  const steps = db
    .prepare('SELECT * FROM job_steps WHERE job_id = ? ORDER BY step_order ASC')
    .all(jobId) as unknown as JobStepRow[];

  if (steps.length === 0) return;

  const nextRun = computeNextRun(job.cron_expression);
  db.prepare("UPDATE jobs SET last_run_at = datetime('now'), next_run_at = ?, updated_at = datetime('now') WHERE id = ?").run(
    nextRun,
    job.id
  );

  const jobStartMs = Date.now();
  const reports: JobStepReport[] = [];
  let lastGeneratedBackupPath: string | null = null;
  let allSuccess = true;

  for (const step of steps) {
    const stepStartMs = Date.now();

    if (step.step_type === 'backup') {
      const profile = step.profile_id
        ? (db.prepare('SELECT * FROM backup_profiles WHERE id = ?').get(step.profile_id) as ProfileJoinRow | undefined)
        : undefined;

      if (!profile) {
        allSuccess = false;
        reports.push({
          order: step.step_order,
          type: 'backup',
          label: 'Perfil não encontrado',
          success: false,
          durationMs: Date.now() - stepStartMs,
          detail: 'O perfil de backup vinculado a esta etapa foi removido.'
        });
        if (job.stop_on_error === 1) break;
        continue;
      }

      try {
        const { descriptor, password } = getDecryptedConnection(profile.connection_id);
        const adapter = getDatabaseAdapter(descriptor.engine);
        const options = JSON.parse(profile.options_json) as Record<string, unknown>;
        const format = typeof options.format === 'string' ? options.format : 'custom';
        const fileName = buildBackupFileName(
          profile.database_name || profile.name,
          profile.dump_type,
          format,
          descriptor.engine
        );
        const targetDir = resolveSafeFolderDir(profile.target_folder || 'backups');
        const outputPath = path.join(targetDir, fileName);

        const cmd = adapter.buildBackupCommand(
          descriptor,
          password,
          { databaseName: profile.database_name ?? undefined, dumpType: profile.dump_type, options },
          outputPath
        );

        const execId = crypto.randomUUID();
        db.prepare(`
          INSERT INTO executions (id, type, profile_id, source_connection_id, database_name, status, command_preview, file_path)
          VALUES (?, 'backup', ?, ?, ?, 'running', ?, ?)
        `).run(
          execId,
          profile.id,
          descriptor.id,
          profile.dump_type === 'pg_dumpall' ? 'CLUSTER_GLOBAL' : (profile.database_name || descriptor.defaultDatabase),
          cmd.preview,
          outputPath
        );

        const res = await runTrackedExecution(execId, cmd, outputPath);
        if (res.success) {
          lastGeneratedBackupPath = outputPath;
        } else {
          allSuccess = false;
        }

        reports.push({
          order: step.step_order,
          type: 'backup',
          label: `${profile.name} (${descriptor.name}/${profile.database_name || 'Cluster'})`,
          success: res.success,
          durationMs: Date.now() - stepStartMs,
          detail: res.success ? `Arquivo: ${fileName}` : `Erro código ${res.exitCode}`
        });

        if (!res.success && job.stop_on_error === 1) break;
      } catch (err) {
        allSuccess = false;
        reports.push({
          order: step.step_order,
          type: 'backup',
          label: profile.name,
          success: false,
          durationMs: Date.now() - stepStartMs,
          detail: (err as Error).message
        });
        if (job.stop_on_error === 1) break;
      }
    } else if (step.step_type === 'restore') {
      let targetConnId = step.target_connection_id;
      let targetDb = step.target_database;
      try {
        let inputPath: string | null = null;
        let rOpts = step.restore_options_json ? (JSON.parse(step.restore_options_json) as Record<string, unknown>) : {};
        let usePrev = step.use_previous_backup === 1;
        let srcConnId = step.source_connection_id;
        let srcDb = step.source_database;

        if (step.restore_profile_id) {
          const rp = db
            .prepare('SELECT * FROM restore_profiles WHERE id = ?')
            .get(step.restore_profile_id) as {
              source_folder: string;
              source_connection_id: string | null;
              source_database: string | null;
              use_latest_backup: number;
              file_name: string | null;
              target_connection_id: string;
              target_database: string;
              create_database_if_not_exists: number;
              options_json: string;
            } | undefined;

          if (!rp) {
            throw new Error('Perfil de restauração vinculado à etapa não foi encontrado.');
          }
          targetConnId = rp.target_connection_id;
          targetDb = rp.target_database;
          usePrev = false;
          srcConnId = rp.source_connection_id;
          srcDb = rp.source_database;
          rOpts = { ...JSON.parse(rp.options_json), createDatabaseIfNotExists: rp.create_database_if_not_exists === 1 };
          if (rp.use_latest_backup !== 1 && rp.file_name) {
            inputPath = path.join(resolveSafeFolderDir(rp.source_folder || 'backups'), path.basename(rp.file_name));
          }
        }

        if (!inputPath && usePrev && lastGeneratedBackupPath) {
          inputPath = lastGeneratedBackupPath;
        } else if (!inputPath) {
          // Busca o último backup bem-sucedido daquela base/conexão no histórico
          const lastExec = db
            .prepare(`
              SELECT file_path FROM executions
              WHERE type = 'backup' AND status = 'success' AND file_path IS NOT NULL
                AND (? IS NULL OR source_connection_id = ?)
                AND (? IS NULL OR database_name = ?)
              ORDER BY started_at DESC
              LIMIT 1
            `)
            .get(srcConnId, srcConnId, srcDb, srcDb) as { file_path: string } | undefined;

          if (lastExec) {
            inputPath = lastExec.file_path;
          }
        }

        if (!inputPath || !fs.existsSync(inputPath)) {
          throw new Error(
            `Nenhum arquivo de backup válido encontrado para restaurar (${srcDb || 'etapa anterior'}).`
          );
        }

        if (!targetConnId || !targetDb) {
          throw new Error('Conexão ou banco de destino não configurado para restauração.');
        }

        const { descriptor, password } = getDecryptedConnection(targetConnId);
        const adapter = getDatabaseAdapter(descriptor.engine);
        const createIfNotExists = rOpts.createDatabaseIfNotExists !== false;

        if (createIfNotExists && adapter.buildCreateDatabaseCommand) {
          const listCmd = adapter.buildListDatabasesCommand(descriptor, password);
          const listRes = await runQuickCommand(listCmd);
          const existingDbs = listRes.exitCode === 0
            ? listRes.stdout.split(/\r?\n/).map((l) => l.trim()).filter(Boolean)
            : [];

          if (!existingDbs.includes(targetDb)) {
            const createCmd = adapter.buildCreateDatabaseCommand(descriptor, password, targetDb);
            const createRes = await runQuickCommand(createCmd);
            if (createRes.exitCode !== 0) {
              throw new Error(`Falha ao criar banco destino '${targetDb}': ${createRes.stderr}`);
            }
          }
        }

        const restoreTool = inputPath.toLowerCase().endsWith('.sql') ? 'psql' : 'pg_restore';
        const cmd = adapter.buildRestoreCommand(
          descriptor,
          password,
          {
            targetDatabase: targetDb,
            restoreTool,
            verbose: true,
            clean: rOpts.clean ?? true,
            noOwner: rOpts.noOwner ?? true,
            onErrorStop: true
          },
          inputPath
        );

        const execId = crypto.randomUUID();
        db.prepare(`
          INSERT INTO executions (id, type, target_connection_id, database_name, status, command_preview, file_path)
          VALUES (?, 'restore', ?, ?, 'running', ?, ?)
        `).run(execId, descriptor.id, targetDb, cmd.preview, inputPath);

        const res = await runTrackedExecution(execId, cmd);
        if (!res.success) allSuccess = false;

        reports.push({
          order: step.step_order,
          type: 'restore',
          label: `${descriptor.name} → ${targetDb}`,
          success: res.success,
          durationMs: Date.now() - stepStartMs,
          detail: res.success
            ? `Restaurado de: ${path.basename(inputPath)}`
            : `Erro código ${res.exitCode}`
        });

        if (!res.success && job.stop_on_error === 1) break;
      } catch (err) {
        allSuccess = false;
        reports.push({
          order: step.step_order,
          type: 'restore',
          label: `Restauração → ${targetDb || '?'}`,
          success: false,
          durationMs: Date.now() - stepStartMs,
          detail: (err as Error).message
        });
        if (job.stop_on_error === 1) break;
      }
    }
  }

  if (job.notify_email_to) {
    const shouldNotify =
      (allSuccess && job.notify_on_success === 1) ||
      (!allSuccess && job.notify_on_error === 1);

    if (shouldNotify) {
      await sendJobAlertEmail({
        to: job.notify_email_to,
        jobName: job.name,
        allSuccess,
        totalDurationMs: Date.now() - jobStartMs,
        steps: reports
      }).catch((err) => console.error('Erro ao enviar alerta consolidado do Job:', err));
    }
  }
}

export function registerJobTask(jobId: string, cronExpression: string, isActive: boolean): void {
  unregisterJobTask(jobId);
  if (!isActive) return;

  const task = cron.schedule(
    cronExpression,
    () => {
      void executeJob(jobId);
    },
    { timezone: env.TZ }
  );
  activeJobTasks.set(jobId, task);
}

export function unregisterJobTask(jobId: string): void {
  const existing = activeJobTasks.get(jobId);
  if (existing) {
    existing.stop();
    activeJobTasks.delete(jobId);
  }
}

export function initJobsScheduler(): void {
  const db = getDatabase();
  const rows = db
    .prepare('SELECT id, cron_expression, is_active FROM jobs WHERE is_active = 1')
    .all() as unknown as Array<{ id: string; cron_expression: string; is_active: number }>;

  for (const row of rows) {
    if (cron.validate(row.cron_expression)) {
      registerJobTask(row.id, row.cron_expression, row.is_active === 1);
    }
  }
  console.log(`🧩 Jobs sequenciais carregados: ${activeJobTasks.size} ativo(s).`);
}
