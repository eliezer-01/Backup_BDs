import { getDatabase } from '../db/sqlite';
import { decryptSecret } from '../security/crypto';
import type { ConnectionDescriptor } from '../adapters/base.adapter';

export interface ConnectionRow {
  id: string;
  name: string;
  engine: string;
  host: string;
  port: number;
  username: string;
  password_encrypted: string;
  password_iv: string;
  password_tag: string;
  default_database: string;
  ssl_mode: string;
  created_at: string;
  updated_at: string;
}

/**
 * Busca uma conexão no SQLite e descriptografa sua senha exclusivamente em memória.
 * Nunca retorna a senha em respostas HTTP.
 *
 * @param connectionId UUID da conexão cadastrada.
 * @returns Descritor da conexão e senha em texto plano para uso imediato em `PGPASSWORD`.
 * @example
 * const { descriptor, password } = getDecryptedConnection('uuid-da-conexao');
 */
export function getDecryptedConnection(connectionId: string): {
  descriptor: ConnectionDescriptor;
  password: string;
} {
  const db = getDatabase();
  const row = db
    .prepare('SELECT * FROM connections WHERE id = ?')
    .get(connectionId) as ConnectionRow | undefined;

  if (!row) {
    throw new Error('Conexão não encontrada.');
  }

  const password = decryptSecret({
    encrypted: row.password_encrypted,
    iv: row.password_iv,
    tag: row.password_tag
  });

  return {
    descriptor: {
      id: row.id,
      name: row.name,
      engine: row.engine,
      host: row.host,
      port: row.port,
      username: row.username,
      defaultDatabase: row.default_database,
      sslMode: row.ssl_mode
    },
    password
  };
}
