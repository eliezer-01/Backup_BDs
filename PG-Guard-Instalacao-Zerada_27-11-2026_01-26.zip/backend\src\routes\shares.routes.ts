import crypto from 'node:crypto';
import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { getDatabase } from '../db/sqlite';
import { authenticateRequest, requirePermission } from '../security/auth';
import { encryptSecret } from '../security/crypto';
import { getDecryptedShare, normalizeUncPath, testSmbConnection } from '../services/smb.service';

const shareSchema = z.object({
  name: z.string().trim().min(2, 'Nome identificador é obrigatório.').max(100),
  uncPath: z.string().trim().min(4, 'Caminho UNC é obrigatório (ex: \\\\servidor\\backups).').max(255),
  domain: z.string().trim().max(120).optional().default(''),
  username: z.string().trim().min(1, 'Usuário é obrigatório.').max(120),
  password: z.string().min(1, 'Senha é obrigatória.').max(500)
});

/**
 * Registra as rotas de gerenciamento seguro de compartilhamentos de rede (SMB/AD),
 * criptografando senhas com AES-256-GCM e permitindo testar antes de salvar.
 *
 * @example
 * app.register(sharesRoutes, { prefix: '/api/shares' });
 */
export async function sharesRoutes(app: FastifyInstance): Promise<void> {
  app.addHook('preHandler', authenticateRequest);

  app.get('/', async () => {
    const db = getDatabase();
    const shares = db
      .prepare('SELECT id, name, unc_path, domain, username, created_at FROM network_shares ORDER BY name ASC')
      .all();
    return { shares };
  });

  app.post('/test-preview', { preHandler: [requirePermission('connections:create', 'connections:write')] }, async (request, reply) => {
    const parsed = shareSchema.omit({ name: true }).safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: parsed.error.issues[0]?.message || 'Dados inválidos.' });
    }

    const res = await testSmbConnection({
      uncPath: normalizeUncPath(parsed.data.uncPath),
      domain: parsed.data.domain || null,
      username: parsed.data.username,
      password: parsed.data.password
    });

    if (res.ok) return reply.send(res);
    return reply.status(400).send(res);
  });

  app.post('/', { preHandler: [requirePermission('connections:create', 'connections:write')] }, async (request, reply) => {
    const parsed = shareSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: parsed.error.issues[0]?.message || 'Dados inválidos.' });
    }

    const enc = encryptSecret(parsed.data.password);
    const id = crypto.randomUUID();
    const db = getDatabase();

    db.prepare(`
      INSERT INTO network_shares (id, name, unc_path, domain, username, password_encrypted, password_iv, password_tag)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      parsed.data.name,
      normalizeUncPath(parsed.data.uncPath),
      parsed.data.domain || null,
      parsed.data.username,
      enc.encrypted,
      enc.iv,
      enc.tag
    );

    return reply.status(201).send({ id, name: parsed.data.name, unc_path: normalizeUncPath(parsed.data.uncPath) });
  });

  app.post<{ Params: { id: string } }>('/:id/test', async (request, reply) => {
    try {
      const desc = getDecryptedShare(request.params.id);
      const res = await testSmbConnection(desc);
      if (res.ok) return reply.send(res);
      return reply.status(400).send(res);
    } catch (err) {
      return reply.status(404).send({ ok: false, message: (err as Error).message });
    }
  });

  app.delete<{ Params: { id: string } }>('/:id', { preHandler: [requirePermission('connections:delete', 'connections:write')] }, async (request, reply) => {
    const db = getDatabase();
    const res = db.prepare('DELETE FROM network_shares WHERE id = ?').run(request.params.id);
    if (res.changes === 0) return reply.status(404).send({ error: 'Compartilhamento não encontrado.' });
    return reply.send({ deleted: true });
  });
}
