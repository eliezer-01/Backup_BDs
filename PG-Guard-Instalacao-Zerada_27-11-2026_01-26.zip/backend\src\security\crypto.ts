import crypto from 'node:crypto';
import { env } from '../config/env';

const ALGORITHM = 'aes-256-gcm';
const KEY_BUFFER = Buffer.from(env.MASTER_ENCRYPTION_KEY, 'hex');

export interface EncryptedPayload {
  encrypted: string;
  iv: string;
  tag: string;
}

/**
 * Criptografa uma senha ou segredo em texto plano usando AES-256-GCM.
 * Gera um vetor de inicialização (IV) aleatório de 12 bytes a cada chamada.
 *
 * @param plainText Texto sensível a ser protegido antes de salvar no SQLite.
 * @returns Objeto contendo `encrypted`, `iv` e `tag` em hexadecimal.
 * @example
 * const payload = encryptSecret('MinhaSenha@123');
 * // Salvar payload.encrypted, payload.iv e payload.tag no banco SQLite.
 */
export function encryptSecret(plainText: string): EncryptedPayload {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGORITHM, KEY_BUFFER, iv);

  const encrypted = Buffer.concat([
    cipher.update(plainText, 'utf8'),
    cipher.final()
  ]);

  const tag = cipher.getAuthTag();

  return {
    encrypted: encrypted.toString('hex'),
    iv: iv.toString('hex'),
    tag: tag.toString('hex')
  };
}

/**
 * Descriptografa um segredo armazenado no SQLite usando AES-256-GCM.
 * Valida a integridade dos dados através da tag de autenticação.
 *
 * @param payload Estrutura com `encrypted`, `iv` e `tag` em hexadecimal.
 * @returns Texto original descriptografado (usado apenas em memória para repassar ao `PGPASSWORD`).
 * @example
 * const senha = decryptSecret({ encrypted, iv, tag });
 */
export function decryptSecret(payload: EncryptedPayload): string {
  const decipher = crypto.createDecipheriv(
    ALGORITHM,
    KEY_BUFFER,
    Buffer.from(payload.iv, 'hex')
  );

  decipher.setAuthTag(Buffer.from(payload.tag, 'hex'));

  const decrypted = Buffer.concat([
    decipher.update(Buffer.from(payload.encrypted, 'hex')),
    decipher.final()
  ]);

  return decrypted.toString('utf8');
}
