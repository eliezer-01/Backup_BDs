import fs from 'node:fs';

const IS_DOCKER = fs.existsSync('/.dockerenv');

/**
 * Converte `127.0.0.1`, `localhost` ou `::1` para `host.docker.internal` quando
 * o backend está executando dentro de um container Docker, permitindo acessar
 * bancos instalados diretamente na máquina hospedeira (Windows/macOS/Linux).
 *
 * @example
 * resolveRuntimeHost('127.0.0.1'); // 'host.docker.internal' (dentro do Docker)
 */
export function resolveRuntimeHost(host: string): string {
  if (IS_DOCKER && (host === '127.0.0.1' || host === 'localhost' || host === '::1')) {
    return 'host.docker.internal';
  }
  return host;
}

/**
 * Formata o preview legível do comando para exibição na interface gráfica.
 * Nunca inclui senhas ou variáveis de ambiente sensíveis.
 */
export function formatCommandPreview(binary: string, args: string[]): string {
  const escaped = args.map((arg) => (arg.includes(' ') ? `"${arg}"` : arg));
  return `${binary} ${escaped.join(' ')}`;
}

/**
 * Representa os dados descriptografados em memória necessários para montar
 * comandos e variáveis de ambiente de um provedor de banco de dados.
 */
export interface ConnectionDescriptor {
  id: string;
  name: string;
  engine: string;
  host: string;
  port: number;
  username: string;
  defaultDatabase: string;
  sslMode: string;
}

/**
 * Estrutura padronizada de comando pronto para execução segura via `spawn`.
 * Nunca utiliza string concatenada de shell.
 */
export interface BuiltCommand {
  binary: string;
  args: string[];
  envVars: Record<string, string>;
  preview: string;
}

/**
 * Interface modular que todo adaptador de banco de dados ou serviço
 * (PostgreSQL, MySQL, MariaDB, SQL Server, Oracle, MongoDB, RabbitMQ) deve implementar.
 *
 * @example
 * const adapter = getDatabaseAdapter('mysql');
 * const cmd = adapter.buildTestConnectionCommand(conn, senha);
 */
export interface DatabaseAdapter {
  readonly engine: string;

  /** Monta o comando para testar conectividade com o servidor. */
  buildTestConnectionCommand(conn: ConnectionDescriptor, password: string): BuiltCommand;

  /** Monta o comando para listar bancos de dados/vhosts disponíveis no servidor. */
  buildListDatabasesCommand(conn: ConnectionDescriptor, password: string): BuiltCommand;

  /** Opcional: cria um banco de dados no servidor destino antes da restauração. */
  buildCreateDatabaseCommand?(
    conn: ConnectionDescriptor,
    password: string,
    targetDatabase: string
  ): BuiltCommand;

  /** Monta o comando de backup para o motor. */
  buildBackupCommand(
    conn: ConnectionDescriptor,
    password: string,
    params: Record<string, unknown>,
    outputPath: string
  ): BuiltCommand;

  /** Monta o comando de restauração para o motor. */
  buildRestoreCommand(
    conn: ConnectionDescriptor,
    password: string,
    params: Record<string, unknown>,
    inputPath: string
  ): BuiltCommand;

  /** Monta o comando para inspecionar o índice (TOC) de um arquivo de backup, quando suportado. */
  buildInspectCommand?(inputPath: string): BuiltCommand;
}
