import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import cron, { type ScheduledTask } from 'node-cron';
import cronParser from 'cron-parser';
import { env } from '../config/env';
import { getDatabase } from '../db/sqlite';
import { getDatabaseAdapter } from '../adapters/registry';
import { buildBackupFileName } from '../routes/backups.routes';
import { resolveSafeBackupPath, resolveSafeFolderDir } from '../security/sanitizer';
import { getDecryptedConnection } from './connections.service';
import { sendBackupAlertEmail } from './email.service';
import { applyRetentionPolicy } from './retention.service';
import { runQuickCommand, runTrackedExecution } from './runner.service';

interface ScheduleJoinRow {
  id: string;
  profile_id: string;
  cron_expression: string;
  is_active: number;
  retention_daily: number;
  retention_weekly: number;
  retention_monthly: number;
  notify_email_to: string | null;
  notify_on_success: number;
  notify_on_error: number;
  profile_name: string;
  connection_id: string;
  database_name: string | null;
  dump_type: 'pg_dump' | 'pg_dumpall';
  options_json: string;
  target_folder: string | null;
}

/** Mapa de tarefas Cron ativas indexadas pelo ID do agendamento. */
const activeTasks = new Map<string, ScheduledTask>();

/**
 * Calcula a próxima data/hora de execução em ISO-8601 a partir de uma expressão Cron.
 *
 * @param expression Expressão Cron padrão de 5 campos (ex: `'0 2 * * *'`).
 * @example
 * const proxima = computeNextRun('0 2 * * *');
 */
export function computeNextRun(expression: string): string | null {
  try {
    const interval = cronParser.parseExpression(expression, { tz: env.TZ });
    return interval.next().toDate().toISOString();
  } catch {
    return null;
  }
}

/**
 * Executa um agendamento específico (disparado pelo Cron ou manualmente via "Executar Agora")
 * e aplica a política de retenção ao finalizar com sucesso.
 *
 * @param scheduleId UUID do agendamento cadastrado.
 * @example
 * await executeScheduledJob('uuid-do-agendamento');
 */
export async function executeScheduledJob(scheduleId: string): Promise<string | null> {
  const db = getDatabase();
  const baseSched = db
    .prepare('SELECT * FROM schedules WHERE id = ?')
    .get(scheduleId) as {
      id: string;
      schedule_type: 'backup' | 'restore';
      profile_id: string | null;
      restore_profile_id: string | null;
      cron_expression: string;
      retention_daily: number;
      retention_weekly: number;
      retention_monthly: number;
      notify_email_to: string | null;
      notify_on_success: number;
      notify_on_error: number;
    } | undefined;

  if (!baseSched) return null;

  const nextRun = computeNextRun(baseSched.cron_expression);
  db.prepare(`
    UPDATE schedules
    SET last_run_at = datetime('now'), next_run_at = ?, updated_at = datetime('now')
    WHERE id = ?
  `).run(nextRun, baseSched.id);

  if (baseSched.schedule_type === 'restore' && baseSched.restore_profile_id) {
    const rp = db
      .prepare('SELECT * FROM restore_profiles WHERE id = ?')
      .get(baseSched.restore_profile_id) as {
        id: string;
        name: string;
        source_folder: string;
        source_connection_id: string | null;
        source_database: string | null;
        use_latest_backup: number;
        file_name: string | null;
        target_connection_id: string;
        target_database: string;
        create_database_if_not_exists: number;
        restore_tool: 'pg_restore' | 'psql';
        options_json: string;
      } | undefined;

    if (!rp) return null;

    let resolvedPath = '';
    if (rp.use_latest_backup === 1) {
      const lastExec = db
        .prepare(`
          SELECT file_path FROM executions
          WHERE type = 'backup' AND status = 'success' AND file_path IS NOT NULL
            AND (? IS NULL OR source_connection_id = ?)
            AND (? IS NULL OR database_name = ?)
          ORDER BY started_at DESC
          LIMIT 1
        `)
        .get(rp.source_connection_id, rp.source_connection_id, rp.source_database, rp.source_database) as
        | { file_path: string }
        | undefined;
      resolvedPath = lastExec?.file_path || '';
    } else if (rp.file_name) {
      resolvedPath = resolveSafeBackupPath(rp.file_name, rp.source_folder || 'backups');
    }

    if (!resolvedPath || !fs.existsSync(resolvedPath)) {
      return null;
    }

    const { descriptor, password } = getDecryptedConnection(rp.target_connection_id);
    const adapter = getDatabaseAdapter(descriptor.engine);
    const opts = JSON.parse(rp.options_json) as Record<string, unknown>;

    if (rp.create_database_if_not_exists === 1 && adapter.buildCreateDatabaseCommand) {
      const listCmd = adapter.buildListDatabasesCommand(descriptor, password);
      const listRes = await runQuickCommand(listCmd);
      const existingDbs = listRes.exitCode === 0
        ? listRes.stdout.split(/\r?\n/).map((l) => l.trim()).filter(Boolean)
        : [];
      if (!existingDbs.includes(rp.target_database)) {
        const createCmd = adapter.buildCreateDatabaseCommand(descriptor, password, rp.target_database);
        await runQuickCommand(createCmd);
      }
    }

    const tool = resolvedPath.toLowerCase().endsWith('.sql') ? 'psql' : rp.restore_tool;
    const cmd = adapter.buildRestoreCommand(
      descriptor,
      password,
      { ...opts, targetDatabase: rp.target_database, restoreTool: tool },
      resolvedPath
    );

    const executionId = crypto.randomUUID();
    db.prepare(`
      INSERT INTO executions (id, type, target_connection_id, database_name, status, command_preview, file_path)
      VALUES (?, 'restore', ?, ?, 'running', ?, ?)
    `).run(executionId, descriptor.id, rp.target_database, cmd.preview, resolvedPath);

    const startedMs = Date.now();
    void runTrackedExecution(executionId, cmd).then(async (res) => {
      if (baseSched.notify_email_to) {
        const shouldNotify =
          (res.success && baseSched.notify_on_success === 1) ||
          (!res.success && baseSched.notify_on_error === 1);
        if (shouldNotify) {
          await sendBackupAlertEmail({
            to: baseSched.notify_email_to,
            profileName: `Restauração: ${rp.name}`,
            connectionName: descriptor.name,
            engine: descriptor.engine,
            databaseName: rp.target_database,
            success: res.success,
            durationMs: Date.now() - startedMs,
            filePath: resolvedPath
          }).catch((err) => console.error('Erro ao enviar alerta de restauração:', err));
        }
      }
    });

    return executionId;
  }

  const row = db
    .prepare(`
      SELECT
        s.id, s.profile_id, s.cron_expression, s.is_active,
        s.retention_daily, s.retention_weekly, s.retention_monthly,
        s.notify_email_to, s.notify_on_success, s.notify_on_error,
        p.name as profile_name, p.connection_id, p.database_name, p.dump_type, p.options_json, p.target_folder
      FROM schedules s
      JOIN backup_profiles p ON p.id = s.profile_id
      WHERE s.id = ?
    `)
    .get(scheduleId) as unknown as ScheduleJoinRow | undefined;

  if (!row) return null;

  const { descriptor, password } = getDecryptedConnection(row.connection_id);
  const adapter = getDatabaseAdapter(descriptor.engine);
  const options = JSON.parse(row.options_json) as Record<string, unknown>;
  const format = typeof options.format === 'string' ? options.format : 'custom';

  const fileName = buildBackupFileName(
    row.database_name || row.profile_name,
    row.dump_type,
    format,
    descriptor.engine
  );
  const targetDir = resolveSafeFolderDir(row.target_folder || 'backups');
  const outputPath = path.join(targetDir, fileName);

  const cmd = adapter.buildBackupCommand(
    descriptor,
    password,
    {
      databaseName: row.database_name ?? undefined,
      dumpType: row.dump_type,
      options
    },
    outputPath
  );

  const executionId = crypto.randomUUID();
  db.prepare(`
    INSERT INTO executions (id, type, profile_id, source_connection_id, database_name, status, command_preview, file_path)
    VALUES (?, 'backup', ?, ?, ?, 'running', ?, ?)
  `).run(
    executionId,
    row.profile_id,
    descriptor.id,
    row.dump_type === 'pg_dumpall' ? 'CLUSTER_GLOBAL' : (row.database_name || descriptor.defaultDatabase),
    cmd.preview,
    outputPath
  );

  db.prepare(`
    UPDATE schedules
    SET last_run_at = datetime('now'), next_run_at = ?, updated_at = datetime('now')
    WHERE id = ?
  `).run(nextRun, row.id);

  const startedMs = Date.now();
  // Executa em segundo plano, aplica rotação se sucesso e dispara alerta por e-mail
  void runTrackedExecution(executionId, cmd, outputPath).then(async (res) => {
    if (res.success) {
      const retention = applyRetentionPolicy(row.profile_id, {
        daily: row.retention_daily,
        weekly: row.retention_weekly,
        monthly: row.retention_monthly
      });
      if (retention.removed > 0) {
        console.log(
          `🧹 Rotação aplicada no perfil '${row.profile_name}': ${retention.removed} backup(s) antigo(s) removido(s).`
        );
      }
    }

    if (row.notify_email_to) {
      const shouldNotify =
        (res.success && row.notify_on_success === 1) ||
        (!res.success && row.notify_on_error === 1);

      if (shouldNotify) {
        const execRow = db
          .prepare('SELECT file_size_bytes, error_message FROM executions WHERE id = ?')
          .get(executionId) as { file_size_bytes: number | null; error_message: string | null } | undefined;

        await sendBackupAlertEmail({
          to: row.notify_email_to,
          profileName: row.profile_name,
          connectionName: descriptor.name,
          engine: descriptor.engine,
          databaseName: row.database_name || descriptor.defaultDatabase,
          success: res.success,
          durationMs: Date.now() - startedMs,
          filePath: outputPath,
          fileSizeBytes: execRow?.file_size_bytes,
          errorMessage: execRow?.error_message
        }).catch((err) => {
          console.error('Erro ao enviar e-mail de alerta:', err);
        });
      }
    }
  });

  return executionId;
}

/**
 * Registra ou recarrega um agendamento individual no motor `node-cron`.
 *
 * @param scheduleId UUID do agendamento.
 * @param cronExpression Expressão Cron validada.
 * @param isActive Define se a tarefa deve iniciar ativa.
 */
export function registerScheduleTask(
  scheduleId: string,
  cronExpression: string,
  isActive: boolean
): void {
  unregisterScheduleTask(scheduleId);

  if (!isActive) return;

  const task = cron.schedule(
    cronExpression,
    () => {
      void executeScheduledJob(scheduleId);
    },
    { timezone: env.TZ }
  );

  activeTasks.set(scheduleId, task);
}

/**
 * Remove e interrompe uma tarefa agendada da memória.
 *
 * @param scheduleId UUID do agendamento.
 */
export function unregisterScheduleTask(scheduleId: string): void {
  const existing = activeTasks.get(scheduleId);
  if (existing) {
    existing.stop();
    activeTasks.delete(scheduleId);
  }
}

/**
 * Carrega todos os agendamentos ativos do SQLite ao iniciar o servidor.
 *
 * @example
 * initScheduler();
 */
export function initScheduler(): void {
  const db = getDatabase();
  const rows = db
    .prepare('SELECT id, cron_expression, is_active FROM schedules WHERE is_active = 1')
    .all() as unknown as Array<{ id: string; cron_expression: string; is_active: number }>;

  for (const row of rows) {
    if (cron.validate(row.cron_expression)) {
      registerScheduleTask(row.id, row.cron_expression, row.is_active === 1);
    }
  }

  console.log(`⏰ Agendador inicializado com ${activeTasks.size} tarefa(s) ativa(s).`);
}
