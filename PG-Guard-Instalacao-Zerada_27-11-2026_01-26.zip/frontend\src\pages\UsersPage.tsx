import { useEffect, useState, type FormEvent } from 'react';
import { KeyRound, Mail, Pencil, Shield, Trash2, UserPlus, Users } from 'lucide-react';
import { apiRequest } from '../services/api';
import { Badge, Button, Card, Input, Select, Toggle, cn } from '../components/ui';

interface MatrixRow {
  screen: string;
  actions: Array<{ key: string; label: string }>;
}

interface RoleItem {
  id: string;
  name: string;
  description: string | null;
  permissions: string[];
  is_system: boolean;
}

interface UserItem {
  id: string;
  username: string;
  role_id: string | null;
  role_name: string | null;
  is_master: boolean;
  is_privileged: boolean;
  created_at: string;
}

type SubTab = 'perfil' | 'acessos' | 'email';

/**
 * Tela de Minha Conta (alteração de senha no topo) e abas modulares:
 * "Perfil" (matriz por tela), "Acessos" (usuários) e "E-mail" (SMTP).
 *
 * @example
 * <UsersPage canManageUsers={true} isMaster={true} userPermissions={[]} />
 */
export function UsersPage({
  canManageUsers,
  isMaster,
  userPermissions
}: {
  canManageUsers: boolean;
  isMaster: boolean;
  userPermissions: string[];
}) {
  const callerPermSet = new Set(userPermissions);
  const canManageSmtp = isMaster || callerPermSet.has('smtp:manage') || canManageUsers;
  const [activeSubTab, setActiveSubTab] = useState<SubTab>(canManageUsers ? 'perfil' : 'email');

  const canGrantRole = (r: RoleItem) =>
    isMaster ||
    (!r.is_system &&
      !r.permissions.includes('users:manage') &&
      r.permissions.every((p) => callerPermSet.has(p)));

  // Alterar própria senha
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [pwdMsg, setPwdMsg] = useState<{ ok: boolean; text: string } | null>(null);

  // Perfis e Usuários
  const [matrix, setMatrix] = useState<MatrixRow[]>([]);
  const [roles, setRoles] = useState<RoleItem[]>([]);
  const [users, setUsers] = useState<UserItem[]>([]);

  const [editingRoleId, setEditingRoleId] = useState<string | null>(null);
  const [roleName, setRoleName] = useState('');
  const [roleDesc, setRoleDesc] = useState('');
  const [selectedPerms, setSelectedPerms] = useState<string[]>([]);

  const [newUsername, setNewUsername] = useState('');
  const [newUserPass, setNewUserPass] = useState('');
  const [newUserRoleId, setNewUserRoleId] = useState('');
  const [adminMsg, setAdminMsg] = useState('');

  // SMTP Alertas
  const [smtpHost, setSmtpHost] = useState('');
  const [smtpPort, setSmtpPort] = useState('587');
  const [smtpSecure, setSmtpSecure] = useState(false);
  const [smtpUser, setSmtpUser] = useState('');
  const [smtpPass, setSmtpPass] = useState('');
  const [smtpFromEmail, setSmtpFromEmail] = useState('');
  const [smtpFromName, setSmtpFromName] = useState('PG Guard Alertas');
  const [smtpAllowSelfSigned, setSmtpAllowSelfSigned] = useState(false);
  const [smtpSubjectSuccess, setSmtpSubjectSuccess] = useState('[PG Guard] ✅ SUCESSO - {{perfil}} ({{banco}})');
  const [smtpSubjectError, setSmtpSubjectError] = useState('[PG Guard] ❌ FALHA - {{perfil}} ({{banco}})');
  const [smtpCustomMessage, setSmtpCustomMessage] = useState('');
  const [smtpBodyFields, setSmtpBodyFields] = useState<Record<string, boolean>>({
    perfil: true,
    conexao: true,
    banco: true,
    data_hora: true,
    duracao: true,
    tamanho: true,
    arquivo: true,
    erro: true
  });
  const [smtpTestTo, setSmtpTestTo] = useState('');
  const [smtpMsg, setSmtpMsg] = useState<{ ok: boolean; text: string } | null>(null);

  async function loadAdminData() {
    if (canManageUsers) {
      const [permRes, rolesRes, usersRes] = await Promise.all([
        apiRequest<{ matrix: MatrixRow[] }>('/api/users/permissions'),
        apiRequest<{ roles: RoleItem[] }>('/api/users/roles'),
        apiRequest<{ users: UserItem[] }>('/api/users')
      ]);
      setMatrix(permRes.matrix ?? []);
      setRoles(rolesRes.roles);
      setUsers(usersRes.users);
      const firstAllowedRole = rolesRes.roles.find((r) => canGrantRole(r));
      if (firstAllowedRole && !newUserRoleId) {
        setNewUserRoleId(firstAllowedRole.id);
      }
    }

    if (canManageSmtp) {
      const smtpRes = await apiRequest<{
        settings: {
          host: string;
          port: number;
          secure: boolean;
          username: string;
          fromEmail: string;
          fromName: string;
          allowSelfSigned: boolean;
          subjectSuccess?: string;
          subjectError?: string;
          customMessage?: string;
          bodyFields?: Record<string, boolean>;
        } | null;
      }>('/api/smtp').catch(() => ({ settings: null }));

      if (smtpRes.settings) {
        setSmtpHost(smtpRes.settings.host);
        setSmtpPort(String(smtpRes.settings.port));
        setSmtpSecure(smtpRes.settings.secure);
        setSmtpUser(smtpRes.settings.username);
        setSmtpFromEmail(smtpRes.settings.fromEmail);
        setSmtpFromName(smtpRes.settings.fromName);
        setSmtpAllowSelfSigned(smtpRes.settings.allowSelfSigned);
        if (smtpRes.settings.subjectSuccess) setSmtpSubjectSuccess(smtpRes.settings.subjectSuccess);
        if (smtpRes.settings.subjectError) setSmtpSubjectError(smtpRes.settings.subjectError);
        if (smtpRes.settings.customMessage !== undefined) setSmtpCustomMessage(smtpRes.settings.customMessage);
        if (smtpRes.settings.bodyFields) setSmtpBodyFields(smtpRes.settings.bodyFields);
      }
    }
  }

  useEffect(() => {
    void loadAdminData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canManageUsers, canManageSmtp]);

  async function handleChangePassword(e: FormEvent) {
    e.preventDefault();
    setPwdMsg(null);
    try {
      const res = await apiRequest<{ message: string }>('/api/auth/change-password', {
        method: 'POST',
        body: JSON.stringify({ currentPassword, newPassword })
      });
      setCurrentPassword('');
      setNewPassword('');
      setPwdMsg({ ok: true, text: res.message });
    } catch (err) {
      setPwdMsg({ ok: false, text: (err as Error).message });
    }
  }

  function togglePerm(key: string) {
    setSelectedPerms((prev) =>
      prev.includes(key) ? prev.filter((p) => p !== key) : [...prev, key]
    );
  }

  function toggleRowPerms(row: MatrixRow) {
    const allowedKeys = row.actions
      .filter((a) => isMaster || (a.key !== 'users:manage' && callerPermSet.has(a.key)))
      .map((a) => a.key);
    const allSelected = allowedKeys.every((k) => selectedPerms.includes(k));
    if (allSelected) {
      setSelectedPerms((prev) => prev.filter((p) => !allowedKeys.includes(p)));
    } else {
      setSelectedPerms((prev) => Array.from(new Set([...prev, ...allowedKeys])));
    }
  }

  function startEditRole(role: RoleItem) {
    setEditingRoleId(role.id);
    setRoleName(role.name);
    setRoleDesc(role.description || '');
    setSelectedPerms(role.permissions);
  }

  async function handleSaveRole(e: FormEvent) {
    e.preventDefault();
    setAdminMsg('');
    try {
      if (editingRoleId) {
        await apiRequest(`/api/users/roles/${editingRoleId}`, {
          method: 'PUT',
          body: JSON.stringify({ name: roleName, description: roleDesc, permissions: selectedPerms })
        });
      } else {
        await apiRequest('/api/users/roles', {
          method: 'POST',
          body: JSON.stringify({ name: roleName, description: roleDesc, permissions: selectedPerms })
        });
      }
      setEditingRoleId(null);
      setRoleName('');
      setRoleDesc('');
      setSelectedPerms([]);
      await loadAdminData();
      setAdminMsg('Perfil salvo com sucesso!');
    } catch (err) {
      setAdminMsg((err as Error).message);
    }
  }

  async function handleDeleteRole(id: string) {
    if (!confirm('Excluir este perfil de acesso?')) return;
    try {
      await apiRequest(`/api/users/roles/${id}`, { method: 'DELETE' });
      await loadAdminData();
    } catch (err) {
      setAdminMsg((err as Error).message);
    }
  }

  async function handleCreateUser(e: FormEvent) {
    e.preventDefault();
    setAdminMsg('');
    try {
      await apiRequest('/api/users', {
        method: 'POST',
        body: JSON.stringify({
          username: newUsername,
          password: newUserPass,
          roleId: newUserRoleId
        })
      });
      setNewUsername('');
      setNewUserPass('');
      await loadAdminData();
      setAdminMsg('Usuário criado com sucesso!');
    } catch (err) {
      setAdminMsg((err as Error).message);
    }
  }

  async function handleChangeUserRole(userId: string, roleId: string) {
    await apiRequest(`/api/users/${userId}`, {
      method: 'PUT',
      body: JSON.stringify({ roleId })
    });
    await loadAdminData();
  }

  async function handleDeleteUser(id: string) {
    if (!confirm('Excluir este usuário?')) return;
    try {
      await apiRequest(`/api/users/${id}`, { method: 'DELETE' });
      await loadAdminData();
    } catch (err) {
      setAdminMsg((err as Error).message);
    }
  }

  async function handleSaveSmtp(e: FormEvent) {
    e.preventDefault();
    setSmtpMsg(null);
    try {
      await apiRequest('/api/smtp', {
        method: 'PUT',
        body: JSON.stringify({
          host: smtpHost,
          port: Number(smtpPort),
          secure: smtpSecure,
          username: smtpUser,
          password: smtpPass || undefined,
          fromEmail: smtpFromEmail,
          fromName: smtpFromName,
          allowSelfSigned: smtpAllowSelfSigned,
          subjectSuccess: smtpSubjectSuccess,
          subjectError: smtpSubjectError,
          customMessage: smtpCustomMessage,
          bodyFields: smtpBodyFields
        })
      });
      setSmtpPass('');
      setSmtpMsg({ ok: true, text: 'Configuração SMTP salva com senha criptografada (AES-256-GCM)!' });
    } catch (err) {
      setSmtpMsg({ ok: false, text: (err as Error).message });
    }
  }

  async function handleTestSmtp() {
    setSmtpMsg(null);
    try {
      const res = await apiRequest<{ message: string }>('/api/smtp/test', {
        method: 'POST',
        body: JSON.stringify({ to: smtpTestTo })
      });
      setSmtpMsg({ ok: true, text: res.message });
    } catch (err) {
      setSmtpMsg({
        ok: false,
        text: `${(err as Error).message} (Lembre-se: clique em "Salvar Configuração SMTP" antes de testar o envio.)`
      });
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Minha Conta e Acessos</h2>
        <p className="text-sm text-muted-foreground">
          Altere sua senha no topo e gerencie perfis por tela, usuários e servidor de e-mail nas abas abaixo.
        </p>
      </div>

      {/* Alterar senha própria (fixo no topo) */}
      <Card className="p-5">
        <h3 className="mb-3 flex items-center gap-2 text-base font-semibold">
          <KeyRound className="h-4 w-4 text-primary" />
          Alterar Minha Senha
        </h3>
        <form onSubmit={handleChangePassword} className="grid gap-4 md:grid-cols-3">
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">Senha Atual</label>
            <Input
              type="password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              required
            />
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">Nova Senha (mín. 6 caracteres)</label>
            <Input
              type="password"
              minLength={6}
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              required
            />
          </div>
          <div className="flex items-end">
            <Button type="submit">Atualizar Senha</Button>
          </div>
        </form>
        {pwdMsg && (
          <div
            className={`mt-3 rounded-lg p-3 text-xs ${
              pwdMsg.ok ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400' : 'bg-destructive/15 text-destructive'
            }`}
          >
            {pwdMsg.text}
          </div>
        )}
      </Card>

      {(canManageUsers || canManageSmtp) && (
        <div className="space-y-4">
          {/* Abas: Perfil | Acessos | E-mail */}
          <div className="flex gap-2 border-b border-border pb-2">
            {canManageUsers && (
              <>
                <button
                  type="button"
                  onClick={() => setActiveSubTab('perfil')}
                  className={cn(
                    'flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition',
                    activeSubTab === 'perfil'
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                  )}
                >
                  <Shield className="h-4 w-4" />
                  Perfil
                </button>
                <button
                  type="button"
                  onClick={() => setActiveSubTab('acessos')}
                  className={cn(
                    'flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition',
                    activeSubTab === 'acessos'
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                  )}
                >
                  <Users className="h-4 w-4" />
                  Acessos
                </button>
              </>
            )}
            {canManageSmtp && (
              <button
                type="button"
                onClick={() => setActiveSubTab('email')}
                className={cn(
                  'flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition',
                  activeSubTab === 'email'
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                )}
              >
                <Mail className="h-4 w-4" />
                E-mail
              </button>
            )}
          </div>

          {adminMsg && <div className="rounded-lg bg-primary/10 p-3 text-xs text-primary">{adminMsg}</div>}

          {/* ABA 1: PERFIL (Matriz por Tela) */}
          {activeSubTab === 'perfil' && canManageUsers && (
            <Card className="space-y-4 p-5">
              <h3 className="flex items-center gap-2 text-base font-semibold">
                <Shield className="h-4 w-4 text-primary" />
                {editingRoleId ? 'Editar Perfil de Acesso' : 'Criar Perfil de Acesso por Tela'}
              </h3>

              <form onSubmit={handleSaveRole} className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Nome do Perfil</label>
                    <Input
                      value={roleName}
                      onChange={(e) => setRoleName(e.target.value)}
                      placeholder="Ex: Operador de Jobs / Auditor"
                      required
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Descrição</label>
                    <Input
                      value={roleDesc}
                      onChange={(e) => setRoleDesc(e.target.value)}
                      placeholder="O que este perfil pode fazer"
                    />
                  </div>
                </div>

                <div className="divide-y divide-border rounded-lg border border-border">
                  {matrix.map((row) => (
                    <div key={row.screen} className="flex flex-wrap items-center justify-between gap-3 p-3">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold">{row.screen}</span>
                        <button
                          type="button"
                          onClick={() => toggleRowPerms(row)}
                          className="text-[11px] text-primary hover:underline"
                        >
                          Alternar linha
                        </button>
                      </div>
                      <div className="flex flex-wrap gap-3">
                        {row.actions.map((act) => {
                          const checked = selectedPerms.includes(act.key);
                          const missingPerm = !isMaster && !callerPermSet.has(act.key);
                          const blocked = !isMaster && (act.key === 'users:manage' || missingPerm);
                          return (
                            <label
                              key={act.key}
                              className={cn(
                                'flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-xs transition',
                                blocked
                                  ? 'cursor-not-allowed opacity-45'
                                  : checked
                                    ? 'cursor-pointer border-primary bg-primary/10 font-medium text-primary'
                                    : 'cursor-pointer border-border hover:bg-muted/50'
                              )}
                            >
                              <input
                                type="checkbox"
                                checked={checked}
                                disabled={blocked}
                                onChange={() => togglePerm(act.key)}
                              />
                              <span>{act.label}</span>
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex gap-2">
                  <Button type="submit" disabled={selectedPerms.length === 0}>
                    {editingRoleId ? 'Atualizar Perfil' : 'Criar Perfil'}
                  </Button>
                  {editingRoleId && (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setEditingRoleId(null);
                        setRoleName('');
                        setRoleDesc('');
                        setSelectedPerms([]);
                      }}
                    >
                      Cancelar
                    </Button>
                  )}
                </div>
              </form>

              <div className="grid gap-3 border-t border-border pt-4 md:grid-cols-2">
                {roles.map((r) => {
                  const isAdminRole = r.is_system || r.permissions.includes('users:manage');
                  const canEditRole = !r.is_system && (isMaster || !isAdminRole);
                  return (
                    <div key={r.id} className="flex items-start justify-between rounded-lg border border-border p-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-semibold">{r.name}</span>
                          {r.is_system && <Badge tone="success">Sistema</Badge>}
                        </div>
                        <p className="text-xs text-muted-foreground">{r.description}</p>
                        <div className="mt-1.5 flex flex-wrap gap-1">
                          {r.permissions.map((p) => (
                            <Badge key={p}>{p}</Badge>
                          ))}
                        </div>
                      </div>
                      {canEditRole && (
                        <div className="flex gap-1">
                          <Button variant="ghost" size="sm" onClick={() => startEditRole(r)}>
                            <Pencil className="h-3.5 w-3.5" />
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => void handleDeleteRole(r.id)}>
                            <Trash2 className="h-3.5 w-3.5 text-destructive" />
                          </Button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </Card>
          )}

          {/* ABA 2: ACESSOS (Usuários) */}
          {activeSubTab === 'acessos' && canManageUsers && (
            <Card className="space-y-4 p-5">
              <h3 className="flex items-center gap-2 text-base font-semibold">
                <UserPlus className="h-4 w-4 text-primary" />
                Usuários e Atribuição de Perfis
              </h3>

              <form onSubmit={handleCreateUser} className="grid gap-4 md:grid-cols-4">
                <div>
                  <label className="mb-1 block text-xs font-medium text-muted-foreground">Login</label>
                  <Input value={newUsername} onChange={(e) => setNewUsername(e.target.value)} required />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-muted-foreground">Senha</label>
                  <Input type="password" minLength={6} value={newUserPass} onChange={(e) => setNewUserPass(e.target.value)} required />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-muted-foreground">Perfil de Acesso</label>
                  <Select value={newUserRoleId} onChange={(e) => setNewUserRoleId(e.target.value)}>
                    {roles
                      .filter((r) => canGrantRole(r))
                      .map((r) => (
                        <option key={r.id} value={r.id}>{r.name}</option>
                      ))}
                  </Select>
                </div>
                <div className="flex items-end">
                  <Button type="submit" className="w-full">Criar Usuário</Button>
                </div>
              </form>

              <div className="divide-y divide-border rounded-lg border border-border">
                {users.map((u) => {
                  const canModifyUser = !u.is_master && (isMaster || !u.is_privileged);
                  return (
                    <div key={u.id} className="flex flex-wrap items-center justify-between gap-3 p-3 text-sm">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold">{u.username}</span>
                        {u.is_master && <Badge tone="success">Admin Master</Badge>}
                        <span className="text-xs text-muted-foreground">
                          ({u.role_name || 'Sem perfil'})
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        {canModifyUser ? (
                          <>
                            <Select
                              className="w-56 py-1 text-xs"
                              value={u.role_id || ''}
                              onChange={(e) => void handleChangeUserRole(u.id, e.target.value)}
                            >
                              {roles
                                .filter((r) => canGrantRole(r))
                                .map((r) => (
                                  <option key={r.id} value={r.id}>{r.name}</option>
                                ))}
                            </Select>
                            <Button variant="ghost" size="sm" onClick={() => void handleDeleteUser(u.id)}>
                              <Trash2 className="h-3.5 w-3.5 text-destructive" />
                            </Button>
                          </>
                        ) : (
                          <span className="text-xs text-muted-foreground">
                            {u.is_master ? 'Protegido (Master)' : 'Somente o Master pode alterar'}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>
          )}

          {/* ABA 3: E-MAIL (SMTP) */}
          {activeSubTab === 'email' && canManageSmtp && (
            <Card className="space-y-4 p-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="flex items-center gap-2 text-base font-semibold">
                  <Mail className="h-4 w-4 text-primary" />
                  Servidor de E-mail para Alertas (SMTP)
                </h3>
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSmtpHost('smtp.gmail.com');
                      setSmtpPort('587');
                      setSmtpSecure(false);
                    }}
                  >
                    Gmail
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSmtpHost('smtp.office365.com');
                      setSmtpPort('587');
                      setSmtpSecure(false);
                    }}
                  >
                    Microsoft 365
                  </Button>
                </div>
              </div>

              <form onSubmit={handleSaveSmtp} className="space-y-4">
                <div className="grid gap-4 md:grid-cols-3">
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Host SMTP</label>
                    <Input value={smtpHost} onChange={(e) => setSmtpHost(e.target.value)} placeholder="smtp.gmail.com" required />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Porta (587 STARTTLS / 465 SSL)</label>
                    <Input type="number" value={smtpPort} onChange={(e) => setSmtpPort(e.target.value)} required />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Usuário SMTP</label>
                    <Input value={smtpUser} onChange={(e) => setSmtpUser(e.target.value)} placeholder="email@dominio.com" required />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Senha / Senha de App (deixe vazio p/ manter)</label>
                    <Input type="password" value={smtpPass} onChange={(e) => setSmtpPass(e.target.value)} />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">E-mail Remetente</label>
                    <Input type="email" value={smtpFromEmail} onChange={(e) => setSmtpFromEmail(e.target.value)} required />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Nome do Remetente</label>
                    <Input value={smtpFromName} onChange={(e) => setSmtpFromName(e.target.value)} required />
                  </div>
                </div>

                <div className="grid gap-3 md:grid-cols-2">
                  <Toggle checked={smtpSecure} onChange={setSmtpSecure} label="Usar SSL direto (Porta 465)" />
                  <Toggle checked={smtpAllowSelfSigned} onChange={setSmtpAllowSelfSigned} label="Aceitar certificado autoassinado (SMTP Local)" />
                </div>

                {/* Personalização de Assunto, Mensagem Fixa e Variáveis do Corpo */}
                <div className="space-y-3 rounded-lg border border-border bg-muted/20 p-4">
                  <div className="text-xs font-semibold">
                    Personalização do E-mail (variáveis disponíveis para assunto: <code>{'{{perfil}}'}</code>, <code>{'{{banco}}'}</code>, <code>{'{{conexao}}'}</code>, <code>{'{{status}}'}</code>, <code>{'{{data}}'}</code>)
                  </div>

                  <div className="grid gap-3 md:grid-cols-2">
                    <div>
                      <label className="mb-1 block text-xs font-medium text-muted-foreground">Assunto Padrão (Sucesso)</label>
                      <Input value={smtpSubjectSuccess} onChange={(e) => setSmtpSubjectSuccess(e.target.value)} required />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs font-medium text-muted-foreground">Assunto Padrão (Falha)</label>
                      <Input value={smtpSubjectError} onChange={(e) => setSmtpSubjectError(e.target.value)} required />
                    </div>
                  </div>

                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">
                      Mensagem Fixa Manual (opcional — exibida no topo do corpo do e-mail)
                    </label>
                    <textarea
                      rows={2}
                      value={smtpCustomMessage}
                      onChange={(e) => setSmtpCustomMessage(e.target.value)}
                      placeholder="Ex: Equipe de TI — Em caso de falha, verificar o serviço PostgreSQL no servidor."
                      className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <div className="mb-2 text-xs font-medium text-muted-foreground">
                      Variáveis exibidas no corpo do e-mail:
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {[
                        ['perfil', 'Perfil / Job'],
                        ['conexao', 'Conexão / Motor'],
                        ['banco', 'Banco de Dados'],
                        ['data_hora', 'Data / Hora'],
                        ['duracao', 'Duração'],
                        ['tamanho', 'Tamanho'],
                        ['arquivo', 'Arquivo / Detalhes'],
                        ['erro', 'Mensagem de Erro']
                      ].map(([key, label]) => (
                        <label
                          key={key}
                          className="flex cursor-pointer items-center gap-1.5 rounded-md border border-border bg-background px-2.5 py-1 text-xs"
                        >
                          <input
                            type="checkbox"
                            checked={Boolean(smtpBodyFields[key])}
                            onChange={() =>
                              setSmtpBodyFields((prev) => ({ ...prev, [key]: !prev[key] }))
                            }
                          />
                          <span>{label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>

                {smtpMsg && (
                  <div
                    className={`rounded-lg p-3 text-xs ${
                      smtpMsg.ok ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400' : 'bg-destructive/15 text-destructive'
                    }`}
                  >
                    {smtpMsg.text}
                  </div>
                )}

                <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border pt-3">
                  <Button type="submit">Salvar Configuração SMTP</Button>
                  <div className="flex items-center gap-2">
                    <Input
                      type="email"
                      className="w-60"
                      value={smtpTestTo}
                      onChange={(e) => setSmtpTestTo(e.target.value)}
                      placeholder="E-mail para teste..."
                    />
                    <Button type="button" variant="outline" onClick={() => void handleTestSmtp()} disabled={!smtpTestTo}>
                      Testar Envio
                    </Button>
                  </div>
                </div>
              </form>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}
