import nodemailer from 'nodemailer';
import { env } from '../config/env';
import { getDatabase } from '../db/sqlite';
import { decryptSecret } from '../security/crypto';

export interface EmailBodyFields {
  perfil: boolean;
  conexao: boolean;
  banco: boolean;
  data_hora: boolean;
  duracao: boolean;
  tamanho: boolean;
  arquivo: boolean;
  erro: boolean;
}

export const DEFAULT_BODY_FIELDS: EmailBodyFields = {
  perfil: true,
  conexao: true,
  banco: true,
  data_hora: true,
  duracao: true,
  tamanho: true,
  arquivo: true,
  erro: true
};

export interface SmtpSettingsRow {
  id: string;
  host: string;
  port: number;
  secure: number;
  username: string;
  password_encrypted: string;
  password_iv: string;
  password_tag: string;
  from_email: string;
  from_name: string;
  allow_self_signed: number;
  subject_success: string;
  subject_error: string;
  custom_message: string | null;
  body_fields_json: string;
}

export interface BackupAlertPayload {
  to: string;
  profileName: string;
  connectionName: string;
  engine: string;
  databaseName: string;
  success: boolean;
  durationMs: number;
  filePath?: string;
  fileSizeBytes?: number | null;
  errorMessage?: string | null;
}

function parseBodyFields(raw?: string): EmailBodyFields {
  if (!raw) return DEFAULT_BODY_FIELDS;
  try {
    return { ...DEFAULT_BODY_FIELDS, ...(JSON.parse(raw) as Partial<EmailBodyFields>) };
  } catch {
    return DEFAULT_BODY_FIELDS;
  }
}

function renderSubjectTemplate(
  template: string,
  vars: { perfil: string; banco: string; conexao: string; status: string; data: string }
): string {
  return template
    .replace(/\{\{perfil\}\}/gi, vars.perfil)
    .replace(/\{\{banco\}\}/gi, vars.banco)
    .replace(/\{\{conexao\}\}/gi, vars.conexao)
    .replace(/\{\{status\}\}/gi, vars.status)
    .replace(/\{\{data\}\}/gi, vars.data);
}

/**
 * Cria um transporter Nodemailer a partir das configurações SMTP criptografadas no SQLite.
 */
function buildTransporter(): {
  transporter: nodemailer.Transporter;
  from: string;
  cfg: SmtpSettingsRow;
  bodyFields: EmailBodyFields;
} | null {
  const db = getDatabase();
  const cfg = db
    .prepare("SELECT * FROM smtp_settings WHERE id = 'default'")
    .get() as SmtpSettingsRow | undefined;

  if (!cfg) return null;

  const password = decryptSecret({
    encrypted: cfg.password_encrypted,
    iv: cfg.password_iv,
    tag: cfg.password_tag
  });

  const transporter = nodemailer.createTransport({
    host: cfg.host,
    port: cfg.port,
    secure: cfg.secure === 1,
    auth: {
      user: cfg.username,
      pass: password
    },
    tls: cfg.allow_self_signed === 1 ? { rejectUnauthorized: false } : undefined
  });

  return {
    transporter,
    from: `"${cfg.from_name}" <${cfg.from_email}>`,
    cfg,
    bodyFields: parseBodyFields(cfg.body_fields_json)
  };
}

/**
 * Envia um e-mail de teste para validar a configuração SMTP e o template atual.
 */
export async function sendTestAlertEmail(to: string): Promise<void> {
  const built = buildTransporter();
  if (!built) {
    throw new Error('Configuração SMTP ainda não foi salva.');
  }

  const customBlock = built.cfg.custom_message
    ? `<div style="margin-bottom: 12px; padding: 10px; background: #f8fafc; border-left: 4px solid #3b82f6; font-size: 13px;">${built.cfg.custom_message}</div>`
    : '';

  await built.transporter.sendMail({
    from: built.from,
    to,
    subject: renderSubjectTemplate(built.cfg.subject_success, {
      perfil: 'Teste SMTP',
      banco: 'postgres',
      conexao: 'Servidor Local',
      status: 'SUCESSO',
      data: new Date().toLocaleDateString('pt-BR', { timeZone: env.TZ })
    }),
    html: `${customBlock}<p>Este é um e-mail de teste do <strong>PG Guard</strong>. Seu servidor SMTP está configurado corretamente.</p>`
  });
}

/**
 * Envia o alerta personalizado (assunto, mensagem fixa e apenas as variáveis marcadas na tela).
 */
export async function sendBackupAlertEmail(payload: BackupAlertPayload): Promise<void> {
  const built = buildTransporter();
  if (!built) return;

  const localNow = new Date().toLocaleString('pt-BR', { timeZone: env.TZ });
  const localDate = new Date().toLocaleDateString('pt-BR', { timeZone: env.TZ });
  const template = payload.success
    ? built.cfg.subject_success || '[PG Guard] ✅ SUCESSO - {{perfil}} ({{banco}})'
    : built.cfg.subject_error || '[PG Guard] ❌ FALHA - {{perfil}} ({{banco}})';

  const subject = renderSubjectTemplate(template, {
    perfil: payload.profileName,
    banco: payload.databaseName,
    conexao: payload.connectionName,
    status: payload.success ? 'SUCESSO' : 'FALHA',
    data: localDate
  });

  const sizeMb =
    payload.fileSizeBytes !== undefined && payload.fileSizeBytes !== null
      ? `${(payload.fileSizeBytes / 1024 / 1024).toFixed(2)} MB`
      : '-';
  const durationSec = `${(payload.durationMs / 1000).toFixed(2)}s`;
  const f = built.bodyFields;

  const rows: Array<[string, string, boolean]> = [
    ['Perfil', payload.profileName, f.perfil],
    ['Conexão / Motor', `${payload.connectionName} (${payload.engine})`, f.conexao],
    ['Banco de Dados', payload.databaseName, f.banco],
    ['Data / Hora', localNow, f.data_hora],
    ['Duração', durationSec, f.duracao],
    ['Tamanho', sizeMb, f.tamanho],
    ['Arquivo', payload.filePath || '-', f.arquivo]
  ];

  const rowsHtml = rows
    .filter(([, , enabled]) => enabled)
    .map(
      ([label, val]) =>
        `<tr><td style="padding: 6px; border-bottom: 1px solid #e2e8f0;"><strong>${label}:</strong></td><td style="padding: 6px; border-bottom: 1px solid #e2e8f0;">${val}</td></tr>`
    )
    .join('');

  const customBlock = built.cfg.custom_message
    ? `<div style="margin-bottom: 12px; padding: 10px; background: #f8fafc; border-left: 4px solid #3b82f6; font-size: 13px;">${built.cfg.custom_message}</div>`
    : '';

  const html = `
    <div style="font-family: Arial, sans-serif; color: #1e293b; max-width: 600px;">
      <h2 style="color: ${payload.success ? '#059669' : '#dc2626'};">
        ${payload.success ? 'Operação Concluída com Sucesso' : 'Falha na Execução'}
      </h2>
      ${customBlock}
      ${rowsHtml ? `<table style="width: 100%; border-collapse: collapse; font-size: 14px;">${rowsHtml}</table>` : ''}
      ${
        f.erro && payload.errorMessage
          ? `<div style="margin-top: 12px; padding: 10px; background: #fef2f2; color: #991b1b; border-radius: 6px;"><strong>Erro:</strong> ${payload.errorMessage}</div>`
          : ''
      }
    </div>
  `;

  await built.transporter.sendMail({
    from: built.from,
    to: payload.to,
    subject,
    html
  });
}

export interface JobStepReport {
  order: number;
  type: 'backup' | 'restore';
  label: string;
  success: boolean;
  durationMs: number;
  detail: string;
}

/**
 * Envia um único e-mail consolidado ao término de um Job sequencial,
 * respeitando assunto personalizado, mensagem fixa e campos selecionados.
 */
export async function sendJobAlertEmail(payload: {
  to: string;
  jobName: string;
  allSuccess: boolean;
  totalDurationMs: number;
  steps: JobStepReport[];
}): Promise<void> {
  const built = buildTransporter();
  if (!built) return;

  const passedCount = payload.steps.filter((s) => s.success).length;
  const localNow = new Date().toLocaleString('pt-BR', { timeZone: env.TZ });
  const localDate = new Date().toLocaleDateString('pt-BR', { timeZone: env.TZ });
  const template = payload.allSuccess
    ? built.cfg.subject_success || '[PG Guard] ✅ SUCESSO - {{perfil}} ({{banco}})'
    : built.cfg.subject_error || '[PG Guard] ❌ FALHA - {{perfil}} ({{banco}})';

  const subject = renderSubjectTemplate(template, {
    perfil: `Job: ${payload.jobName}`,
    banco: `${passedCount}/${payload.steps.length} etapas`,
    conexao: 'Pipeline',
    status: payload.allSuccess ? 'SUCESSO' : 'FALHA',
    data: localDate
  });

  const f = built.bodyFields;
  const customBlock = built.cfg.custom_message
    ? `<div style="margin-bottom: 12px; padding: 10px; background: #f8fafc; border-left: 4px solid #3b82f6; font-size: 13px;">${built.cfg.custom_message}</div>`
    : '';

  const rowsHtml = payload.steps
    .map(
      (s) => `
      <tr>
        <td style="padding: 6px; border-bottom: 1px solid #e2e8f0;">#${s.order} (${s.type === 'backup' ? 'Backup' : 'Restauração'})</td>
        <td style="padding: 6px; border-bottom: 1px solid #e2e8f0;">${s.label}</td>
        <td style="padding: 6px; border-bottom: 1px solid #e2e8f0; color: ${s.success ? '#059669' : '#dc2626'}; font-weight: bold;">
          ${s.success ? 'Sucesso' : 'Falha'}
        </td>
        ${f.duracao ? `<td style="padding: 6px; border-bottom: 1px solid #e2e8f0;">${(s.durationMs / 1000).toFixed(2)}s</td>` : ''}
        ${f.arquivo || f.erro ? `<td style="padding: 6px; border-bottom: 1px solid #e2e8f0; font-size: 12px;">${s.detail}</td>` : ''}
      </tr>
    `
    )
    .join('');

  const html = `
    <div style="font-family: Arial, sans-serif; color: #1e293b; max-width: 760px;">
      <h2 style="color: ${payload.allSuccess ? '#059669' : '#dc2626'};">
        ${payload.allSuccess ? 'Job Concluído com Sucesso' : 'Job Finalizado com Falha(s)'}: ${payload.jobName}
      </h2>
      ${customBlock}
      ${
        f.data_hora || f.duracao
          ? `<p style="font-size: 13px; color: #475569;">
              ${f.data_hora ? `Executado em: <strong>${localNow}</strong> ` : ''}
              ${f.duracao ? `• Duração total: <strong>${(payload.totalDurationMs / 1000).toFixed(2)}s</strong>` : ''}
            </p>`
          : ''
      }
      <table style="width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 10px;">
        <thead>
          <tr style="background: #f1f5f9; text-align: left;">
            <th style="padding: 8px;">Etapa</th>
            <th style="padding: 8px;">Alvo</th>
            <th style="padding: 8px;">Status</th>
            ${f.duracao ? '<th style="padding: 8px;">Duração</th>' : ''}
            ${f.arquivo || f.erro ? '<th style="padding: 8px;">Detalhes</th>' : ''}
          </tr>
        </thead>
        <tbody>${rowsHtml}</tbody>
      </table>
    </div>
  `;

  await built.transporter.sendMail({
    from: built.from,
    to: payload.to,
    subject,
    html
  });
}
