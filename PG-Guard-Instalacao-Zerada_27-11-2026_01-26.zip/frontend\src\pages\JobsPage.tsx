import { useEffect, useState, type FormEvent } from 'react';
import {
  ArrowDown,
  ArrowUp,
  DatabaseBackup,
  HardDriveUpload,
  Pause,
  Play,
  Plus,
  RotateCw,
  Trash2,
  Workflow
} from 'lucide-react';
import { apiRequest } from '../services/api';
import { Badge, Button, Card, Input, Select, Toggle } from '../components/ui';
import type { Connection } from './ConnectionsPage';

interface BackupProfile {
  id: string;
  name: string;
  connection_name: string;
  database_name: string | null;
}

interface RestoreProfile {
  id: string;
  name: string;
  target_connection_name: string;
  target_database: string;
}

interface DraftStep {
  stepType: 'backup' | 'restore';
  profileId: string;
  restoreProfileId: string;
  usePreviousBackup: boolean;
  sourceConnectionId: string;
  sourceDatabase: string;
  targetConnectionId: string;
  targetDatabase: string;
  createDatabaseIfNotExists: boolean;
  clean: boolean;
}

interface SavedJob {
  id: string;
  name: string;
  description: string | null;
  cron_expression: string;
  is_active: number;
  notify_email_to: string | null;
  next_run_at: string | null;
  steps: Array<{
    id: string;
    step_order: number;
    step_type: 'backup' | 'restore';
    profile_name: string | null;
    restore_profile_name: string | null;
    source_database: string | null;
    target_connection_name: string | null;
    target_database: string | null;
    use_previous_backup: number;
  }>;
}

/**
 * Tela dedicada para criação de Jobs Sequenciais (Pipelines):
 * executa múltiplos backups e/ou restaurações programadas em ordem
 * e envia 1 único e-mail consolidado com o resultado de cada etapa.
 *
 * @example
 * <JobsPage />
 */
export function JobsPage() {
  const [profiles, setProfiles] = useState<BackupProfile[]>([]);
  const [restoreProfiles, setRestoreProfiles] = useState<RestoreProfile[]>([]);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [dbsByConn, setDbsByConn] = useState<Record<string, string[]>>({});
  const [jobs, setJobs] = useState<SavedJob[]>([]);

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [preset, setPreset] = useState<'daily' | 'weekly' | 'monthly' | 'custom'>('daily');
  const [hour, setHour] = useState('02');
  const [minute, setMinute] = useState('00');
  const [weekDay, setWeekDay] = useState('0');
  const [monthDay, setMonthDay] = useState('1');
  const [customCron, setCustomCron] = useState('0 2 * * *');
  const [stopOnError, setStopOnError] = useState(true);
  const [notifyEmailTo, setNotifyEmailTo] = useState('');
  const [notifyOnSuccess, setNotifyOnSuccess] = useState(true);
  const [notifyOnError, setNotifyOnError] = useState(true);
  const [steps, setSteps] = useState<DraftStep[]>([]);
  const [feedback, setFeedback] = useState('');

  async function loadDbs(connId: string) {
    if (!connId || dbsByConn[connId]) return;
    try {
      const res = await apiRequest<{ databases: string[] }>(`/api/connections/${connId}/databases`);
      setDbsByConn((prev) => ({ ...prev, [connId]: res.databases }));
    } catch {
      setDbsByConn((prev) => ({ ...prev, [connId]: [] }));
    }
  }

  async function loadAll() {
    const [pRes, rpRes, cRes, jRes] = await Promise.all([
      apiRequest<{ profiles: BackupProfile[] }>('/api/backups/profiles'),
      apiRequest<{ profiles: RestoreProfile[] }>('/api/restores/profiles').catch(() => ({ profiles: [] })),
      apiRequest<{ connections: Connection[] }>('/api/connections'),
      apiRequest<{ jobs: SavedJob[] }>('/api/jobs')
    ]);
    setProfiles(pRes.profiles);
    setRestoreProfiles(rpRes.profiles);
    setConnections(cRes.connections);
    setJobs(jRes.jobs);
  }

  useEffect(() => {
    void loadAll();
  }, []);

  const resolvedCron =
    preset === 'daily'
      ? `${Number(minute)} ${Number(hour)} * * *`
      : preset === 'weekly'
        ? `${Number(minute)} ${Number(hour)} * * ${weekDay}`
        : preset === 'monthly'
          ? `${Number(minute)} ${Number(hour)} ${monthDay} * *`
          : customCron;

  function addBackupStep() {
    setSteps((prev) => [
      ...prev,
      {
        stepType: 'backup',
        profileId: profiles[0]?.id ?? '',
        restoreProfileId: '',
        usePreviousBackup: false,
        sourceConnectionId: '',
        sourceDatabase: '',
        targetConnectionId: '',
        targetDatabase: '',
        createDatabaseIfNotExists: true,
        clean: true
      }
    ]);
  }

  function addRestoreStep() {
    const firstConnId = connections[0]?.id ?? '';
    if (firstConnId) void loadDbs(firstConnId);
    setSteps((prev) => [
      ...prev,
      {
        stepType: 'restore',
        profileId: '',
        restoreProfileId: '',
        usePreviousBackup: prev.some((s) => s.stepType === 'backup'),
        sourceConnectionId: firstConnId,
        sourceDatabase: '',
        targetConnectionId: firstConnId,
        targetDatabase: '',
        createDatabaseIfNotExists: true,
        clean: true
      }
    ]);
  }

  function updateStep(index: number, patch: Partial<DraftStep>) {
    setSteps((prev) => prev.map((s, i) => (i === index ? { ...s, ...patch } : s)));
  }

  function moveStep(index: number, dir: -1 | 1) {
    const target = index + dir;
    if (target < 0 || target >= steps.length) return;
    setSteps((prev) => {
      const next = [...prev];
      const [item] = next.splice(index, 1);
      next.splice(target, 0, item);
      return next;
    });
  }

  async function handleCreateJob(e: FormEvent) {
    e.preventDefault();
    setFeedback('');
    try {
      await apiRequest('/api/jobs', {
        method: 'POST',
        body: JSON.stringify({
          name,
          description,
          cronExpression: resolvedCron,
          isActive: true,
          stopOnError,
          notifyEmailTo: notifyEmailTo.trim() || '',
          notifyOnSuccess,
          notifyOnError,
          steps: steps.map((s) => ({
            stepType: s.stepType,
            profileId: s.stepType === 'backup' ? s.profileId : null,
            restoreProfileId: s.stepType === 'restore' && s.restoreProfileId ? s.restoreProfileId : null,
            usePreviousBackup: s.usePreviousBackup,
            sourceConnectionId: s.stepType === 'restore' && !s.restoreProfileId && !s.usePreviousBackup ? s.sourceConnectionId : null,
            sourceDatabase: s.stepType === 'restore' && !s.restoreProfileId && !s.usePreviousBackup ? s.sourceDatabase : null,
            targetConnectionId: s.stepType === 'restore' && !s.restoreProfileId ? s.targetConnectionId : null,
            targetDatabase: s.stepType === 'restore' && !s.restoreProfileId ? s.targetDatabase : null,
            restoreOptions:
              s.stepType === 'restore'
                ? { createDatabaseIfNotExists: s.createDatabaseIfNotExists, clean: s.clean, noOwner: true }
                : undefined
          }))
        })
      });
      setName('');
      setDescription('');
      setSteps([]);
      setNotifyEmailTo('');
      await loadAll();
      setFeedback('Job sequencial criado com sucesso!');
    } catch (err) {
      setFeedback((err as Error).message);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Jobs Sequenciais (Pipelines)</h2>
        <p className="text-sm text-muted-foreground">
          Combine vários backups e restaurações programadas em um único agendamento sequencial com 1 alerta consolidado ao final.
        </p>
      </div>

      <Card className="p-5">
        <h3 className="mb-4 flex items-center gap-2 text-base font-semibold">
          <Workflow className="h-4 w-4 text-primary" />
          Novo Job Programado
        </h3>

        <form onSubmit={handleCreateJob} className="space-y-5">
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Nome do Job</label>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex: Rotina Noturna (Backup Oficial + Clone p/ Teste)"
                required
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Descrição (opcional)</label>
              <Input
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Ex: Copia bases da produção e atualiza homologação"
              />
            </div>
          </div>

          {/* Construtor de etapas sequenciais */}
          <div className="space-y-3 rounded-xl border border-border bg-muted/20 p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="text-sm font-semibold">Etapas do Job (executadas em ordem sequencial)</div>
              <div className="flex gap-2">
                <Button type="button" variant="outline" size="sm" onClick={addBackupStep} disabled={profiles.length === 0}>
                  <DatabaseBackup className="h-3.5 w-3.5" />
                  + Etapa de Backup
                </Button>
                <Button type="button" variant="outline" size="sm" onClick={addRestoreStep} disabled={connections.length === 0}>
                  <HardDriveUpload className="h-3.5 w-3.5" />
                  + Etapa de Restauração
                </Button>
              </div>
            </div>

            {steps.length === 0 && (
              <div className="rounded-lg border border-dashed border-border p-4 text-center text-xs text-muted-foreground">
                Nenhuma etapa adicionada. Clique nos botões acima para montar a sequência de backups e restaurações.
              </div>
            )}

            {steps.map((step, idx) => (
              <Card key={idx} className="space-y-3 p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm font-semibold">
                    <Badge tone="running">Etapa {idx + 1}</Badge>
                    <span>{step.stepType === 'backup' ? 'Executar Backup' : 'Restauração Programada'}</span>
                  </div>
                  <div className="flex gap-1">
                    <Button type="button" variant="ghost" size="sm" onClick={() => moveStep(idx, -1)} disabled={idx === 0}>
                      <ArrowUp className="h-3.5 w-3.5" />
                    </Button>
                    <Button type="button" variant="ghost" size="sm" onClick={() => moveStep(idx, 1)} disabled={idx === steps.length - 1}>
                      <ArrowDown className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => setSteps((prev) => prev.filter((_, i) => i !== idx))}
                    >
                      <Trash2 className="h-3.5 w-3.5 text-destructive" />
                    </Button>
                  </div>
                </div>

                {step.stepType === 'backup' ? (
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Perfil de Backup</label>
                    <Select
                      value={step.profileId}
                      onChange={(e) => updateStep(idx, { profileId: e.target.value })}
                      required
                    >
                      {profiles.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} ({p.connection_name} / {p.database_name || 'Cluster'})
                        </option>
                      ))}
                    </Select>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {restoreProfiles.length > 0 && (
                      <div>
                        <label className="mb-1 block text-xs font-medium text-muted-foreground">
                          Usar Perfil de Restauração Salvo (opcional)
                        </label>
                        <Select
                          value={step.restoreProfileId}
                          onChange={(e) => updateStep(idx, { restoreProfileId: e.target.value })}
                        >
                          <option value="">Configurar manualmente abaixo</option>
                          {restoreProfiles.map((rp) => (
                            <option key={rp.id} value={rp.id}>
                              {rp.name} ({rp.target_connection_name} → {rp.target_database})
                            </option>
                          ))}
                        </Select>
                      </div>
                    )}

                    {!step.restoreProfileId && (
                      <>
                        <Toggle
                          checked={step.usePreviousBackup}
                          onChange={(v) => updateStep(idx, { usePreviousBackup: v })}
                          label="Usar o backup gerado pela etapa anterior deste Job"
                          hint="Desative para restaurar automaticamente o último backup salvo de uma base específica"
                        />

                    {!step.usePreviousBackup && (
                      <div className="grid gap-3 md:grid-cols-2">
                        <div>
                          <label className="mb-1 block text-xs font-medium text-muted-foreground">Conexão de Origem (último backup)</label>
                          <Select
                            value={step.sourceConnectionId}
                            onChange={(e) => {
                              updateStep(idx, { sourceConnectionId: e.target.value });
                              void loadDbs(e.target.value);
                            }}
                          >
                            {connections.map((c) => (
                              <option key={c.id} value={c.id}>{c.name}</option>
                            ))}
                          </Select>
                        </div>
                        <div>
                          <label className="mb-1 block text-xs font-medium text-muted-foreground">
                            Banco de Origem (escolha ou digite)
                          </label>
                          <Input
                            list={`src-dbs-${idx}`}
                            value={step.sourceDatabase}
                            onChange={(e) => updateStep(idx, { sourceDatabase: e.target.value })}
                            placeholder="Ex: gestao_projetos_db"
                            required
                          />
                          <datalist id={`src-dbs-${idx}`}>
                            {(dbsByConn[step.sourceConnectionId] ?? []).map((db) => (
                              <option key={db} value={db} />
                            ))}
                          </datalist>
                        </div>
                      </div>
                    )}

                    <div className="grid gap-3 md:grid-cols-2">
                      <div>
                        <label className="mb-1 block text-xs font-medium text-muted-foreground">Conexão de Destino</label>
                        <Select
                          value={step.targetConnectionId}
                          onChange={(e) => {
                            updateStep(idx, { targetConnectionId: e.target.value });
                            void loadDbs(e.target.value);
                          }}
                        >
                          {connections.map((c) => (
                            <option key={c.id} value={c.id}>{c.name} [{c.engine}]</option>
                          ))}
                        </Select>
                      </div>
                      <div>
                        <label className="mb-1 block text-xs font-medium text-muted-foreground">
                          Banco de Destino (selecione existente ou digite novo)
                        </label>
                        <Input
                          list={`tgt-dbs-${idx}`}
                          value={step.targetDatabase}
                          onChange={(e) => updateStep(idx, { targetDatabase: e.target.value })}
                          placeholder="Ex: base_teste"
                          required
                        />
                        <datalist id={`tgt-dbs-${idx}`}>
                          {(dbsByConn[step.targetConnectionId] ?? []).map((db) => (
                            <option key={db} value={db} />
                          ))}
                        </datalist>
                      </div>
                    </div>

                    <div className="grid gap-3 md:grid-cols-2">
                      <Toggle
                        checked={step.createDatabaseIfNotExists}
                        onChange={(v) => updateStep(idx, { createDatabaseIfNotExists: v })}
                        label="Criar banco automaticamente se não existir"
                      />
                      <Toggle
                        checked={step.clean}
                        onChange={(v) => updateStep(idx, { clean: v })}
                        label="Sobrescrever objetos existentes (--clean)"
                      />
                    </div>
                      </>
                    )}
                  </div>
                )}
              </Card>
            ))}
          </div>

          {/* Frequência Cron */}
          <div className="grid gap-4 md:grid-cols-4">
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Frequência</label>
              <Select value={preset} onChange={(e) => setPreset(e.target.value as typeof preset)}>
                <option value="daily">Diário</option>
                <option value="weekly">Semanal</option>
                <option value="monthly">Mensal</option>
                <option value="custom">Expressão Cron</option>
              </Select>
            </div>
            {preset !== 'custom' ? (
              <>
                <div>
                  <label className="mb-1 block text-xs font-medium text-muted-foreground">Hora</label>
                  <Input type="number" min={0} max={23} value={hour} onChange={(e) => setHour(e.target.value)} />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-muted-foreground">Minuto</label>
                  <Input type="number" min={0} max={59} value={minute} onChange={(e) => setMinute(e.target.value)} />
                </div>
                {preset === 'weekly' && (
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Dia da Semana</label>
                    <Select value={weekDay} onChange={(e) => setWeekDay(e.target.value)}>
                      <option value="0">Domingo</option>
                      <option value="1">Segunda</option>
                      <option value="2">Terça</option>
                      <option value="3">Quarta</option>
                      <option value="4">Quinta</option>
                      <option value="5">Sexta</option>
                      <option value="6">Sábado</option>
                    </Select>
                  </div>
                )}
                {preset === 'monthly' && (
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Dia do Mês</label>
                    <Input type="number" min={1} max={28} value={monthDay} onChange={(e) => setMonthDay(e.target.value)} />
                  </div>
                )}
              </>
            ) : (
              <div className="md:col-span-2">
                <label className="mb-1 block text-xs font-medium text-muted-foreground">Cron (5 campos)</label>
                <Input value={customCron} onChange={(e) => setCustomCron(e.target.value)} />
              </div>
            )}
            <div className="flex items-end">
              <div className="w-full rounded-lg bg-muted p-2.5 text-xs">
                Cron: <code className="font-bold">{resolvedCron}</code>
              </div>
            </div>
          </div>

          <Toggle
            checked={stopOnError}
            onChange={setStopOnError}
            label="Interromper próximas etapas se uma etapa falhar"
            hint="Recomendado para evitar restaurar dados caso o backup anterior tenha falhado"
          />

          <div className="grid gap-4 border-t border-border pt-4 md:grid-cols-3">
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">
                E-mail para Alerta Único Consolidado (opcional)
              </label>
              <Input
                type="email"
                value={notifyEmailTo}
                onChange={(e) => setNotifyEmailTo(e.target.value)}
                placeholder="ti@empresa.com.br"
              />
            </div>
            <Toggle checked={notifyOnSuccess} onChange={setNotifyOnSuccess} label="Alertar se todo o Job der Sucesso" />
            <Toggle checked={notifyOnError} onChange={setNotifyOnError} label="Alertar se alguma etapa Falhar" />
          </div>

          {feedback && <div className="rounded-lg bg-primary/10 p-3 text-xs text-primary">{feedback}</div>}

          <Button type="submit" disabled={steps.length === 0}>
            <Plus className="h-4 w-4" />
            Salvar Job Sequencial
          </Button>
        </form>
      </Card>

      <div className="space-y-3">
        {jobs.map((job) => (
          <Card key={job.id} className="space-y-2 p-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-semibold">{job.name}</span>
                  <Badge tone={job.is_active === 1 ? 'success' : 'neutral'}>
                    {job.is_active === 1 ? 'Ativo' : 'Pausado'}
                  </Badge>
                  <code className="rounded bg-muted px-2 py-0.5 text-xs">{job.cron_expression}</code>
                </div>
                {job.next_run_at && (
                  <p className="text-xs text-muted-foreground">
                    Próxima execução: {new Date(job.next_run_at).toLocaleString('pt-BR')}
                    {job.notify_email_to && ` • Alerta: ${job.notify_email_to}`}
                  </p>
                )}
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    void apiRequest(`/api/jobs/${job.id}/run-now`, { method: 'POST' });
                    setFeedback(`Job "${job.name}" iniciado! Acompanhe na aba Histórico e Logs.`);
                  }}
                >
                  <RotateCw className="h-3.5 w-3.5" />
                  Executar Agora
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => void apiRequest(`/api/jobs/${job.id}/toggle`, { method: 'PUT' }).then(loadAll)}
                >
                  {job.is_active === 1 ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
                  {job.is_active === 1 ? 'Pausar' : 'Ativar'}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    if (confirm('Excluir este Job?')) {
                      void apiRequest(`/api/jobs/${job.id}`, { method: 'DELETE' }).then(loadAll);
                    }
                  }}
                >
                  <Trash2 className="h-3.5 w-3.5 text-destructive" />
                </Button>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 border-t border-border pt-2 text-xs">
              {job.steps.map((st) => (
                <Badge key={st.id}>
                  #{st.step_order} {st.step_type === 'backup'
                    ? `Backup: ${st.profile_name || '?'}`
                    : st.restore_profile_name
                      ? `Restaurar (Perfil: ${st.restore_profile_name})`
                      : `Restaurar (${st.use_previous_backup ? 'etapa anterior' : st.source_database}) → ${st.target_connection_name}/${st.target_database}`}
                </Badge>
              ))}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
