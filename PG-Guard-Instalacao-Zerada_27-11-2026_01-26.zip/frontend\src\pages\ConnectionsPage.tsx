import { useEffect, useState, type FormEvent } from 'react';
import {
  CheckCircle2,
  Database,
  Pencil,
  PlugZap,
  Plus,
  Search,
  Server,
  Trash2,
  X,
  XCircle
} from 'lucide-react';
import { apiRequest } from '../services/api';
import { Badge, Button, Card, Input, Select } from '../components/ui';

export interface Connection {
  id: string;
  name: string;
  engine: string;
  host: string;
  port: number;
  username: string;
  default_database: string;
  ssl_mode: string;
}

const ENGINE_OPTIONS = [
  { value: 'postgresql', label: 'PostgreSQL', defaultPort: '5432', defaultDb: 'postgres' },
  { value: 'mysql', label: 'MySQL', defaultPort: '3306', defaultDb: 'mysql' },
  { value: 'mariadb', label: 'MariaDB', defaultPort: '3306', defaultDb: 'mysql' },
  { value: 'sqlserver', label: 'SQL Server', defaultPort: '1433', defaultDb: 'master' },
  { value: 'oracle', label: 'Oracle Database', defaultPort: '1521', defaultDb: 'ORCL' },
  { value: 'mongodb', label: 'MongoDB', defaultPort: '27017', defaultDb: 'admin' },
  { value: 'rabbitmq', label: 'RabbitMQ (Management API)', defaultPort: '15672', defaultDb: '/' },
  { value: 'firebird', label: 'Firebird (.fdb)', defaultPort: '3050', defaultDb: '/firebird/data/banco.fdb' }
] as const;

/**
 * Gerenciador de conexões multi-banco (PostgreSQL, MySQL, MariaDB, SQL Server, Oracle, MongoDB e RabbitMQ).
 * Permite descobrir bancos automaticamente antes de salvar, editar, excluir,
 * testar conectividade e definir o banco padrão com um clique.
 *
 * @example
 * <ConnectionsPage />
 */
export function ConnectionsPage() {
  const [connections, setConnections] = useState<Connection[]>([]);
  const [databasesByConn, setDatabasesByConn] = useState<Record<string, string[]>>({});
  const [testStatus, setTestStatus] = useState<Record<string, { ok: boolean; msg: string }>>({});
  const [loading, setLoading] = useState(false);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [engine, setEngine] = useState<string>('postgresql');
  const [name, setName] = useState('');
  const [host, setHost] = useState('host.docker.internal');
  const [port, setPort] = useState('5432');
  const [username, setUsername] = useState('postgres');
  const [password, setPassword] = useState('');
  const [defaultDb, setDefaultDb] = useState('postgres');
  const [sslMode, setSslMode] = useState('prefer');
  const [discoveredDbs, setDiscoveredDbs] = useState<string[]>([]);
  const [discoverMsg, setDiscoverMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [formError, setFormError] = useState('');

  async function loadConnections() {
    const data = await apiRequest<{ connections: Connection[] }>('/api/connections');
    setConnections(data.connections);
  }

  useEffect(() => {
    void loadConnections();
  }, []);

  function resetForm() {
    setEditingId(null);
    setEngine('postgresql');
    setName('');
    setHost('host.docker.internal');
    setPort('5432');
    setUsername('postgres');
    setPassword('');
    setDefaultDb('postgres');
    setSslMode('prefer');
    setDiscoveredDbs([]);
    setDiscoverMsg(null);
    setFormError('');
  }

  function startEdit(conn: Connection) {
    setEditingId(conn.id);
    setEngine(conn.engine);
    setName(conn.name);
    setHost(conn.host);
    setPort(String(conn.port));
    setUsername(conn.username);
    setPassword('');
    setDefaultDb(conn.default_database);
    setSslMode(conn.ssl_mode);
    setDiscoveredDbs(databasesByConn[conn.id] ?? []);
    setDiscoverMsg(null);
    setFormError('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function handleDiscoverDatabases() {
    setDiscoverMsg(null);
    setFormError('');
    try {
      if (editingId && !password) {
        const dbRes = await apiRequest<{ databases: string[] }>(`/api/connections/${editingId}/databases`);
        setDiscoveredDbs(dbRes.databases);
        if (dbRes.databases.length > 0 && !dbRes.databases.includes(defaultDb)) {
          setDefaultDb(dbRes.databases[0]);
        }
        setDiscoverMsg({ ok: true, text: `${dbRes.databases.length} banco(s) encontrado(s) no servidor!` });
        return;
      }

      const res = await apiRequest<{ ok: boolean; databases: string[] }>('/api/connections/discover', {
        method: 'POST',
        body: JSON.stringify({
          engine,
          host,
          port: Number(port),
          username,
          password,
          default_database: defaultDb || 'postgres',
          ssl_mode: sslMode
        })
      });
      setDiscoveredDbs(res.databases);
      if (res.databases.length > 0 && (!defaultDb || defaultDb === 'postgres')) {
        setDefaultDb(res.databases[0]);
      }
      setDiscoverMsg({ ok: true, text: `${res.databases.length} banco(s) encontrado(s) no servidor!` });
    } catch (err) {
      setDiscoverMsg({ ok: false, text: (err as Error).message });
    }
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setFormError('');
    setLoading(true);
    try {
      if (editingId) {
        const body: Record<string, unknown> = {
          name,
          host,
          port: Number(port),
          username,
          default_database: defaultDb || 'postgres',
          ssl_mode: sslMode
        };
        if (password) body.password = password;

        await apiRequest(`/api/connections/${editingId}`, {
          method: 'PUT',
          body: JSON.stringify(body)
        });
      } else {
        await apiRequest('/api/connections', {
          method: 'POST',
          body: JSON.stringify({
            name,
            engine,
            host,
            port: Number(port),
            username,
            password,
            default_database: defaultDb || 'postgres',
            ssl_mode: sslMode
          })
        });
      }
      resetForm();
      await loadConnections();
    } catch (err) {
      setFormError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  async function handleTest(id: string) {
    setTestStatus((prev) => ({ ...prev, [id]: { ok: true, msg: 'Testando...' } }));
    try {
      const res = await apiRequest<{ ok: boolean; message: string }>(`/api/connections/${id}/test`, {
        method: 'POST'
      });
      setTestStatus((prev) => ({ ...prev, [id]: { ok: res.ok, msg: res.message } }));
      const dbRes = await apiRequest<{ databases: string[] }>(`/api/connections/${id}/databases`);
      setDatabasesByConn((prev) => ({ ...prev, [id]: dbRes.databases }));
    } catch (err) {
      setTestStatus((prev) => ({ ...prev, [id]: { ok: false, msg: (err as Error).message } }));
    }
  }

  async function handleSetDefaultDb(connId: string, dbName: string) {
    await apiRequest(`/api/connections/${connId}`, {
      method: 'PUT',
      body: JSON.stringify({ default_database: dbName })
    });
    await loadConnections();
  }

  async function handleDelete(id: string) {
    if (!confirm('Remover esta conexão?')) return;
    try {
      await apiRequest(`/api/connections/${id}`, { method: 'DELETE' });
      if (editingId === id) resetForm();
      await loadConnections();
    } catch (err) {
      alert((err as Error).message);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Conexões de Servidores</h2>
        <p className="text-sm text-muted-foreground">
          Cadastre servidores locais ou remotos (ex: Oficial e Teste). Para bancos na sua máquina local, use{' '}
          <code>host.docker.internal</code> em vez de <code>127.0.0.1</code>.
        </p>
      </div>

      <Card className="p-5">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="flex items-center gap-2 text-base font-semibold">
            {editingId ? <Pencil className="h-4 w-4 text-primary" /> : <Plus className="h-4 w-4 text-primary" />}
            {editingId ? 'Editar Conexão PostgreSQL' : 'Nova Conexão PostgreSQL'}
          </h3>
          {editingId && (
            <Button variant="ghost" size="sm" onClick={resetForm}>
              <X className="h-4 w-4" />
              Cancelar Edição
            </Button>
          )}
        </div>

        <form onSubmit={handleSubmit} className="grid gap-4 md:grid-cols-3">
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">Tipo de Conexão (Motor)</label>
            <Select
              value={engine}
              disabled={Boolean(editingId)}
              onChange={(e) => {
                const nextEngine = e.target.value;
                setEngine(nextEngine);
                const meta = ENGINE_OPTIONS.find((o) => o.value === nextEngine);
                if (meta) {
                  setPort(meta.defaultPort);
                  setDefaultDb(meta.defaultDb);
                }
                setDiscoveredDbs([]);
              }}
            >
              {ENGINE_OPTIONS.map((opt) => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </Select>
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">Nome identificador</label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex: Servidor Oficial" required />
          </div>
          <div>
            <label className="mb-1 flex items-center justify-between text-xs font-medium text-muted-foreground">
              <span>Host / IP</span>
              <button
                type="button"
                onClick={() => setHost('host.docker.internal')}
                className="text-[11px] text-primary hover:underline"
              >
                Usar host local
              </button>
            </label>
            <Input value={host} onChange={(e) => setHost(e.target.value)} placeholder="host.docker.internal ou IP" required />
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">Porta</label>
            <Input type="number" value={port} onChange={(e) => setPort(e.target.value)} required />
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">Usuário</label>
            <Input value={username} onChange={(e) => setUsername(e.target.value)} required />
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">
              Senha {editingId && '(deixe vazio para manter a atual)'}
            </label>
            <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required={!editingId} />
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">Modo SSL</label>
            <Select value={sslMode} onChange={(e) => setSslMode(e.target.value)}>
              <option value="disable">disable (Desabilitado)</option>
              <option value="allow">allow</option>
              <option value="prefer">prefer (Padrão)</option>
              <option value="require">require (Obrigatório)</option>
              <option value="verify-ca">verify-ca</option>
              <option value="verify-full">verify-full</option>
            </Select>
          </div>

          <div className="md:col-span-2">
            <label className="mb-1 block text-xs font-medium text-muted-foreground">
              Banco Padrão (opcional — clique em &quot;Buscar Bancos&quot; para descobrir automaticamente)
            </label>
            <div className="flex gap-2">
              {discoveredDbs.length > 0 ? (
                <Select value={defaultDb} onChange={(e) => setDefaultDb(e.target.value)}>
                  {discoveredDbs.map((db) => (
                    <option key={db} value={db}>{db}</option>
                  ))}
                </Select>
              ) : (
                <Input
                  value={defaultDb}
                  onChange={(e) => setDefaultDb(e.target.value)}
                  placeholder="postgres"
                />
              )}
              <Button
                type="button"
                variant="outline"
                onClick={() => void handleDiscoverDatabases()}
                disabled={!host || !username || (!password && !editingId)}
              >
                <Search className="h-4 w-4" />
                Buscar Bancos
              </Button>
            </div>
          </div>

          <div className="flex items-end">
            <Button type="submit" className="w-full" disabled={loading}>
              <Server className="h-4 w-4" />
              {loading ? 'Salvando...' : editingId ? 'Atualizar Conexão' : 'Salvar Conexão Segura'}
            </Button>
          </div>
        </form>

        {discoverMsg && (
          <div
            className={`mt-3 rounded-lg p-3 text-xs ${
              discoverMsg.ok ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400' : 'bg-destructive/15 text-destructive'
            }`}
          >
            {discoverMsg.text}
          </div>
        )}

        {formError && (
          <div className="mt-3 rounded-lg bg-destructive/15 p-3 text-xs text-destructive">{formError}</div>
        )}
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        {connections.map((conn) => {
          const status = testStatus[conn.id];
          const dbs = databasesByConn[conn.id];

          return (
            <Card key={conn.id} className="p-5">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-semibold">{conn.name}</h4>
                    <Badge>{conn.engine}</Badge>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {conn.username}@{conn.host}:{conn.port}/{conn.default_database} (SSL: {conn.ssl_mode})
                  </p>
                </div>

                <div className="flex gap-1.5">
                  <Button variant="outline" size="sm" onClick={() => void handleTest(conn.id)}>
                    <PlugZap className="h-3.5 w-3.5" />
                    Testar
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => startEdit(conn)} title="Editar conexão">
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => void handleDelete(conn.id)} title="Excluir conexão">
                    <Trash2 className="h-3.5 w-3.5 text-destructive" />
                  </Button>
                </div>
              </div>

              {status && (
                <div
                  className={`mt-3 flex items-center gap-2 rounded-lg p-2.5 text-xs ${
                    status.ok ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400' : 'bg-red-500/15 text-red-500'
                  }`}
                >
                  {status.ok ? <CheckCircle2 className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
                  <span>{status.msg}</span>
                </div>
              )}

              {dbs && (
                <div className="mt-3 border-t border-border pt-3">
                  <div className="mb-1.5 flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                    <Database className="h-3.5 w-3.5" />
                    Bancos disponíveis ({dbs.length}) — clique para definir como padrão:
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {dbs.map((dbName) => {
                      const isDefault = dbName === conn.default_database;
                      return (
                        <button
                          key={dbName}
                          type="button"
                          onClick={() => void handleSetDefaultDb(conn.id, dbName)}
                          className={`rounded-full px-2.5 py-0.5 text-xs font-medium transition ${
                            isDefault
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-muted text-muted-foreground hover:bg-primary/20 hover:text-foreground'
                          }`}
                          title={isDefault ? 'Banco padrão atual' : 'Clique para definir como banco padrão'}
                        >
                          {dbName}{isDefault ? ' ✓' : ''}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
}
