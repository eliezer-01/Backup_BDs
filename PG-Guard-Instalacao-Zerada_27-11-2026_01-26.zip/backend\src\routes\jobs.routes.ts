import crypto from 'node:crypto';
import type { FastifyInstance } from 'fastify';
import cron from 'node-cron';
import { z } from 'zod';
import { getDatabase } from '../db/sqlite';
import { authenticateRequest, requirePermission } from '../security/auth';
import { computeNextRun } from '../services/scheduler.service';
import { executeJob, registerJobTask, unregisterJobTask } from '../services/jobs.service';

const jobStepInputSchema = z.object({
  stepType: z.enum(['backup', 'restore']),
  profileId: z.string().uuid().optional().nullable(),
  restoreProfileId: z.string().uuid().optional().nullable(),
  sourceConnectionId: z.string().uuid().optional().nullable(),
  sourceDatabase: z.string().trim().max(260).optional().nullable(),
  targetConnectionId: z.string().uuid().optional().nullable(),
  targetDatabase: z.string().trim().max(260).optional().nullable(),
  usePreviousBackup: z.boolean().default(true),
  restoreOptions: z
    .object({
      createDatabaseIfNotExists: z.boolean().default(true),
      clean: z.boolean().default(true),
      noOwner: z.boolean().default(true)
    })
    .optional()
});

const jobInputSchema = z.object({
  name: z.string().trim().min(2, 'Nome do Job é obrigatório.').max(120),
  description: z.string().trim().max(300).optional().default(''),
  cronExpression: z
    .string()
    .trim()
    .refine((expr) => cron.validate(expr), 'Expressão Cron inválida.'),
  isActive: z.boolean().default(true),
  stopOnError: z.boolean().default(true),
  notifyEmailTo: z.string().trim().email('E-mail inválido.').optional().or(z.literal('')),
  notifyOnSuccess: z.boolean().default(true),
  notifyOnError: z.boolean().default(true),
  steps: z.array(jobStepInputSchema).min(1, 'Adicione pelo menos 1 etapa ao Job.')
});

/**
 * Registra as rotas de gerenciamento de Jobs Sequenciais (Pipelines de Backup e Restauração).
 *
 * @example
 * app.register(jobsRoutes, { prefix: '/api/jobs' });
 */
export async function jobsRoutes(app: FastifyInstance): Promise<void> {
  app.addHook('preHandler', authenticateRequest);

  app.get('/', { preHandler: [requirePermission('jobs:read', 'schedules:manage')] }, async () => {
    const db = getDatabase();
    const jobs = db.prepare('SELECT * FROM jobs ORDER BY created_at DESC').all() as Array<{ id: string }>;
    const allSteps = db
      .prepare(`
        SELECT s.*, p.name as profile_name, rp.name as restore_profile_name, tc.name as target_connection_name, sc.name as source_connection_name
        FROM job_steps s
        LEFT JOIN backup_profiles p ON p.id = s.profile_id
        LEFT JOIN restore_profiles rp ON rp.id = s.restore_profile_id
        LEFT JOIN connections tc ON tc.id = s.target_connection_id
        LEFT JOIN connections sc ON sc.id = s.source_connection_id
        ORDER BY s.step_order ASC
      `)
      .all() as Array<{ job_id: string }>;

    const stepsByJob = new Map<string, Array<{ job_id: string }>>();
    for (const st of allSteps) {
      const list = stepsByJob.get(st.job_id) ?? [];
      list.push(st);
      stepsByJob.set(st.job_id, list);
    }

    return {
      jobs: jobs.map((j) => ({
        ...j,
        steps: stepsByJob.get(j.id) ?? []
      }))
    };
  });

  app.post('/', { preHandler: [requirePermission('jobs:create', 'schedules:manage')] }, async (request, reply) => {
    const parsed = jobInputSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: parsed.error.issues[0]?.message || 'Dados inválidos.' });
    }

    const db = getDatabase();
    const jobId = crypto.randomUUID();
    const nextRun = parsed.data.isActive ? computeNextRun(parsed.data.cronExpression) : null;

    db.exec('BEGIN TRANSACTION;');
    try {
      db.prepare(`
        INSERT INTO jobs (id, name, description, cron_expression, is_active, stop_on_error, notify_email_to, notify_on_success, notify_on_error, next_run_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        jobId,
        parsed.data.name,
        parsed.data.description,
        parsed.data.cronExpression,
        parsed.data.isActive ? 1 : 0,
        parsed.data.stopOnError ? 1 : 0,
        parsed.data.notifyEmailTo || null,
        parsed.data.notifyOnSuccess ? 1 : 0,
        parsed.data.notifyOnError ? 1 : 0,
        nextRun
      );

      parsed.data.steps.forEach((step, idx) => {
        db.prepare(`
          INSERT INTO job_steps (id, job_id, step_order, step_type, profile_id, restore_profile_id, source_connection_id, source_database, target_connection_id, target_database, use_previous_backup, restore_options_json)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
          crypto.randomUUID(),
          jobId,
          idx + 1,
          step.stepType,
          step.profileId ?? null,
          step.restoreProfileId ?? null,
          step.sourceConnectionId ?? null,
          step.sourceDatabase ?? null,
          step.targetConnectionId ?? null,
          step.targetDatabase ?? null,
          step.usePreviousBackup ? 1 : 0,
          step.restoreOptions ? JSON.stringify(step.restoreOptions) : null
        );
      });

      db.exec('COMMIT;');
    } catch (err) {
      db.exec('ROLLBACK;');
      throw err;
    }

    registerJobTask(jobId, parsed.data.cronExpression, parsed.data.isActive);
    return reply.status(201).send({ id: jobId, nextRunAt: nextRun });
  });

  app.put<{ Params: { id: string } }>('/:id/toggle', { preHandler: [requirePermission('jobs:update', 'schedules:manage')] }, async (request, reply) => {
    const db = getDatabase();
    const job = db
      .prepare('SELECT id, cron_expression, is_active FROM jobs WHERE id = ?')
      .get(request.params.id) as { id: string; cron_expression: string; is_active: number } | undefined;

    if (!job) return reply.status(404).send({ error: 'Job não encontrado.' });

    const nextActive = job.is_active !== 1;
    const nextRun = nextActive ? computeNextRun(job.cron_expression) : null;
    db.prepare("UPDATE jobs SET is_active = ?, next_run_at = ?, updated_at = datetime('now') WHERE id = ?").run(
      nextActive ? 1 : 0,
      nextRun,
      job.id
    );

    registerJobTask(job.id, job.cron_expression, nextActive);
    return reply.send({ isActive: nextActive, nextRunAt: nextRun });
  });

  app.post<{ Params: { id: string } }>('/:id/run-now', { preHandler: [requirePermission('jobs:execute', 'schedules:manage')] }, async (request, reply) => {
    const db = getDatabase();
    const job = db.prepare('SELECT id FROM jobs WHERE id = ?').get(request.params.id);
    if (!job) return reply.status(404).send({ error: 'Job não encontrado.' });

    void executeJob(request.params.id);
    return reply.status(202).send({ started: true });
  });

  app.delete<{ Params: { id: string } }>('/:id', { preHandler: [requirePermission('jobs:delete', 'schedules:manage')] }, async (request, reply) => {
    unregisterJobTask(request.params.id);
    const db = getDatabase();
    const res = db.prepare('DELETE FROM jobs WHERE id = ?').run(request.params.id);
    if (res.changes === 0) return reply.status(404).send({ error: 'Job não encontrado.' });
    return reply.send({ deleted: true });
  });
}
