const TOKEN_KEY = 'pg_guard_token';

/**
 * Recupera o token JWT salvo no navegador.
 * @example
 * const token = getAuthToken();
 */
export function getAuthToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

/**
 * Armazena ou remove o token JWT de autenticação.
 * @example
 * setAuthToken('eyJhbGci...');
 */
export function setAuthToken(token: string | null): void {
  if (token) {
    localStorage.setItem(TOKEN_KEY, token);
  } else {
    localStorage.removeItem(TOKEN_KEY);
  }
}

/**
 * Cliente HTTP autenticado para chamadas JSON à API REST do backend.
 * Redireciona para login automaticamente caso receba HTTP 401.
 *
 * @example
 * const data = await apiRequest<{ connections: Connection[] }>('/api/connections');
 */
export async function apiRequest<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getAuthToken();
  const headers = new Headers(options.headers);

  if (options.body !== undefined && !headers.has('Content-Type') && !(options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  const response = await fetch(path, { ...options, headers });

  if (response.status === 401) {
    setAuthToken(null);
    window.dispatchEvent(new Event('auth-expired'));
    throw new Error('Sessão expirada. Faça login novamente.');
  }

  const payload = await response.json().catch(() => ({}));

  if (!response.ok) {
    const message = payload.message || payload.error || payload.details || 'Erro na requisição.';
    throw new Error(typeof message === 'string' ? message : JSON.stringify(message));
  }

  return payload as T;
}

/**
 * Realiza o download autenticado de um arquivo de backup gerado.
 *
 * @example
 * await downloadBackupFile('uuid-da-execucao', 'oficial_2026.backup');
 */
export async function downloadBackupFile(executionId: string, suggestedName: string): Promise<void> {
  const token = getAuthToken();
  const response = await fetch(`/api/executions/${executionId}/download`, {
    headers: token ? { Authorization: `Bearer ${token}` } : {}
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({ error: 'Falha ao baixar arquivo.' }));
    throw new Error(err.error || 'Falha ao baixar arquivo.');
  }

  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = suggestedName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

/**
 * Monta a URL do WebSocket autenticada com o token JWT atual.
 * @example
 * const ws = new WebSocket(getWebSocketUrl());
 */
export function getWebSocketUrl(): string {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const token = getAuthToken() ?? '';
  return `${protocol}//${window.location.host}/ws/logs?token=${encodeURIComponent(token)}`;
}
