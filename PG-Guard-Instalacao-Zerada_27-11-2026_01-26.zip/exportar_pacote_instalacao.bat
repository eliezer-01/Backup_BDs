@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion

title PG Guard - Exportar Pacote de Instalacao Limpa (Base Zerada)
cd /d "%~dp0"

echo ========================================================================
echo   PG Guard - Exportando Pacote Limpo para Nova Instalacao (.zip)
echo ========================================================================
echo.

for /f "usebackq delims=" %%T in (`powershell -NoProfile -Command "Get-Date -Format 'dd-MM-yyyy_HH-mm'"`) do set "STAMP=%%T"
set "STAGE_DIR=%TEMP%\pg_guard_export_%STAMP%"
set "OUT_ZIP=%~dp0PG-Guard-Instalacao-Zerada_%STAMP%.zip"

if exist "%STAGE_DIR%" rmdir /s /q "%STAGE_DIR%"
mkdir "%STAGE_DIR%"

echo [1/2] Copiando apenas os arquivos necessarios (sem .env, data/, node_modules/ e dist/)...

robocopy "." "%STAGE_DIR%" /E /XD data node_modules dist .git atualizacao .vscode /XF .env .env.* *.sqlite *.sqlite-journal *.log *.zip *.rar /NFL /NDL /NJH /NJS >nul
if %errorlevel% geq 8 (
    echo [ERRO] Falha ao copiar arquivos para exportacao.
    pause
    exit /b 1
)

:: Mantem .env.example e atualizacao/LEIA-ME.txt no pacote limpo
if exist ".env.example" copy /y ".env.example" "%STAGE_DIR%\.env.example" >nul
if not exist "%STAGE_DIR%\atualizacao" mkdir "%STAGE_DIR%\atualizacao"
if exist "atualizacao\LEIA-ME.txt" copy /y "atualizacao\LEIA-ME.txt" "%STAGE_DIR%\atualizacao\LEIA-ME.txt" >nul

echo [2/2] Compactando em "%OUT_ZIP%"...
powershell -NoProfile -Command "Compress-Archive -Path '%STAGE_DIR%\*' -DestinationPath '%OUT_ZIP%' -Force"
if %errorlevel% neq 0 (
    echo [ERRO] Falha ao gerar o arquivo ZIP.
    rmdir /s /q "%STAGE_DIR%" >nul 2>&1
    pause
    exit /b 1
)

rmdir /s /q "%STAGE_DIR%" >nul 2>&1

echo.
echo ========================================================================
echo   Pacote de instalacao zerada gerado com sucesso!
echo   Arquivo: %OUT_ZIP%
echo.
echo   Para instalar em outro computador:
echo   1. Extraia o ZIP em uma pasta no novo PC/servidor
echo   2. Execute instalar_atualizar.bat (Windows) ou ./instalar_atualizar.sh (Linux/Mac)
echo ========================================================================
echo.
pause
