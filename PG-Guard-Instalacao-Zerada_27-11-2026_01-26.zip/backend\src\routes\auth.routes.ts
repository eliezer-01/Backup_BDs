import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { getDatabase } from '../db/sqlite';
import {
  authenticateRequest,
  getUserAccessInfo,
  hashPassword,
  verifyPassword
} from '../security/auth';

const loginSchema = z.object({
  username: z.string().trim().min(1),
  password: z.string().min(1)
});

const changePasswordSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword: z.string().min(6, 'A nova senha deve ter pelo menos 6 caracteres.')
});

/**
 * Registra as rotas de autenticação do painel (login, sessão atual com permissões e alteração de senha).
 *
 * @example
 * app.register(authRoutes, { prefix: '/api/auth' });
 */
export async function authRoutes(app: FastifyInstance): Promise<void> {
  app.post('/login', async (request, reply) => {
    const parsed = loginSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Usuário e senha são obrigatórios.' });
    }

    const db = getDatabase();
    const user = db
      .prepare('SELECT id, username, password_hash FROM users WHERE username = ?')
      .get(parsed.data.username) as { id: string; username: string; password_hash: string } | undefined;

    if (!user || !verifyPassword(parsed.data.password, user.password_hash)) {
      return reply.status(401).send({ error: 'Credenciais inválidas.' });
    }

    const access = getUserAccessInfo(user.id);
    const token = app.jwt.sign(
      { sub: user.id, username: user.username },
      { expiresIn: '12h' }
    );

    return reply.send({
      token,
      user: {
        id: user.id,
        username: user.username,
        roleName: access.roleName,
        permissions: access.permissions,
        isMaster: access.isMaster
      }
    });
  });

  app.get('/me', { preHandler: [authenticateRequest] }, async (request) => {
    const payload = request.user as { sub: string; username: string };
    const access = getUserAccessInfo(payload.sub);
    return {
      user: {
        id: payload.sub,
        username: payload.username,
        roleName: access.roleName,
        permissions: access.permissions,
        isMaster: access.isMaster
      }
    };
  });

  app.post('/change-password', { preHandler: [authenticateRequest] }, async (request, reply) => {
    const parsed = changePasswordSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: parsed.error.issues[0]?.message || 'Dados inválidos.' });
    }

    const payload = request.user as { sub: string };
    const db = getDatabase();
    const user = db
      .prepare('SELECT id, password_hash FROM users WHERE id = ?')
      .get(payload.sub) as { id: string; password_hash: string } | undefined;

    if (!user || !verifyPassword(parsed.data.currentPassword, user.password_hash)) {
      return reply.status(400).send({ error: 'Senha atual incorreta.' });
    }

    const newHash = hashPassword(parsed.data.newPassword);
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(newHash, user.id);

    return reply.send({ ok: true, message: 'Senha alterada com sucesso! Ela já está salva com hash criptográfico no SQLite.' });
  });
}
