/**
 * Lista completa de permissões modulares (inclui ações granulares por tela e chaves legadas).
 */
export const ALL_PERMISSIONS = [
  // Legadas (mantidas para compatibilidade com perfis existentes)
  'connections:read',
  'connections:write',
  'backup:execute',
  'backup:profiles',
  'restore:execute',
  'schedules:manage',
  'logs:read',
  'logs:download',
  'users:manage',
  // Granulares por tela: Conexões e Rede
  'connections:create',
  'connections:update',
  'connections:delete',
  // Backup
  'backup:read',
  'backup:create',
  'backup:delete',
  // Restauração
  'restore:read',
  'restore:create',
  'restore:delete',
  // Agendamentos
  'schedules:read',
  'schedules:create',
  'schedules:update',
  'schedules:delete',
  'schedules:execute',
  // Jobs (Pipelines)
  'jobs:read',
  'jobs:create',
  'jobs:update',
  'jobs:delete',
  'jobs:execute',
  // E-mail SMTP
  'smtp:manage'
] as const;

export type Permission = (typeof ALL_PERMISSIONS)[number];

export interface PermissionMatrixRow {
  screen: string;
  actions: Array<{ key: Permission; label: string }>;
}

/**
 * Matriz de permissões agrupada por tela para exibição na aba "Perfil".
 */
export const PERMISSION_MATRIX: PermissionMatrixRow[] = [
  {
    screen: 'Conexões e Rede (SMB/AD)',
    actions: [
      { key: 'connections:read', label: 'Consultar' },
      { key: 'connections:create', label: 'Criar' },
      { key: 'connections:update', label: 'Modificar' },
      { key: 'connections:delete', label: 'Excluir' }
    ]
  },
  {
    screen: 'Backup e Perfis',
    actions: [
      { key: 'backup:read', label: 'Consultar' },
      { key: 'backup:create', label: 'Criar Perfil' },
      { key: 'backup:delete', label: 'Excluir Perfil' },
      { key: 'backup:execute', label: 'Executar / Exportar' }
    ]
  },
  {
    screen: 'Restauração e Perfis',
    actions: [
      { key: 'restore:read', label: 'Consultar' },
      { key: 'restore:create', label: 'Criar Perfil' },
      { key: 'restore:delete', label: 'Excluir Perfil' },
      { key: 'restore:execute', label: 'Executar' }
    ]
  },
  {
    screen: 'Agendamentos',
    actions: [
      { key: 'schedules:read', label: 'Consultar' },
      { key: 'schedules:create', label: 'Criar' },
      { key: 'schedules:update', label: 'Modificar' },
      { key: 'schedules:delete', label: 'Excluir' },
      { key: 'schedules:execute', label: 'Executar' }
    ]
  },
  {
    screen: 'Jobs (Pipelines)',
    actions: [
      { key: 'jobs:read', label: 'Consultar' },
      { key: 'jobs:create', label: 'Criar' },
      { key: 'jobs:update', label: 'Modificar' },
      { key: 'jobs:delete', label: 'Excluir' },
      { key: 'jobs:execute', label: 'Executar' }
    ]
  },
  {
    screen: 'Histórico e Logs',
    actions: [
      { key: 'logs:read', label: 'Consultar' },
      { key: 'logs:download', label: 'Exportar / Baixar' }
    ]
  },
  {
    screen: 'Conta, Acessos e E-mail',
    actions: [
      { key: 'users:manage', label: 'Gerenciar Usuários/Perfis' },
      { key: 'smtp:manage', label: 'Configurar E-mail SMTP' }
    ]
  }
];

/**
 * Catálogo plano derivado da matriz (para compatibilidade com clientes antigos).
 */
export const PERMISSION_CATALOG = PERMISSION_MATRIX.flatMap((row) =>
  row.actions.map((a) => ({
    key: a.key,
    label: `${row.screen}: ${a.label}`,
    description: `${a.label} em ${row.screen}`
  }))
);
