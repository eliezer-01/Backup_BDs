import crypto from 'node:crypto';
import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { getDatabase } from '../db/sqlite';
import {
  authenticateRequest,
  getUserAccessInfo,
  hashPassword,
  requirePermission
} from '../security/auth';
import { ALL_PERMISSIONS, PERMISSION_CATALOG, PERMISSION_MATRIX } from '../security/permissions';

const roleInputSchema = z.object({
  name: z.string().trim().min(2, 'Nome do perfil deve ter ao menos 2 caracteres.').max(80),
  description: z.string().trim().max(250).optional().default(''),
  permissions: z.array(z.enum(ALL_PERMISSIONS)).min(1, 'Selecione pelo menos uma permissão.')
});

const createUserSchema = z.object({
  username: z.string().trim().min(3, 'Usuário deve ter ao menos 3 caracteres.').max(60),
  password: z.string().min(6, 'Senha deve ter ao menos 6 caracteres.'),
  roleId: z.string().uuid('Perfil de acesso inválido.')
});

const updateUserSchema = z.object({
  roleId: z.string().uuid('Perfil de acesso inválido.').optional(),
  password: z.string().min(6, 'Senha deve ter ao menos 6 caracteres.').optional()
});

/**
 * Verifica se todas as permissões de uma lista pertencem ao conjunto de permissões do solicitante.
 * Impede que um gestor de usuários crie ou atribua perfis com acessos superiores aos seus (anti-escalonamento).
 */
function hasSubsetPermissions(callerPerms: string[], targetPerms: string[]): boolean {
  const allowed = new Set(callerPerms);
  return targetPerms.every((p) => allowed.has(p));
}

/**
 * Busca as permissões de um perfil pelo seu UUID.
 */
function getRolePermissions(roleId: string | null): string[] {
  if (!roleId) return [];
  const db = getDatabase();
  const row = db
    .prepare('SELECT permissions_json FROM roles WHERE id = ?')
    .get(roleId) as { permissions_json: string } | undefined;
  if (!row) return [];
  try {
    return JSON.parse(row.permissions_json) as string[];
  } catch {
    return [];
  }
}

/**
 * Verifica se um perfil de acesso possui privilégios administrativos
 * (`is_system = 1` ou permissão `users:manage`).
 */
function isPrivilegedRole(roleId: string | null): boolean {
  if (!roleId) return false;
  const db = getDatabase();
  const role = db
    .prepare('SELECT is_system, permissions_json FROM roles WHERE id = ?')
    .get(roleId) as { is_system: number; permissions_json: string } | undefined;

  if (!role) return false;
  if (role.is_system === 1) return true;
  try {
    const perms = JSON.parse(role.permissions_json) as string[];
    return perms.includes('users:manage');
  } catch {
    return false;
  }
}

/**
 * Registra as rotas de gerenciamento modular de Perfis de Acesso (RBAC) e Usuários,
 * aplicando proteção hierárquica do Admin Master (`is_master = 1`).
 *
 * @example
 * app.register(usersRoutes, { prefix: '/api/users' });
 */
export async function usersRoutes(app: FastifyInstance): Promise<void> {
  app.addHook('preHandler', authenticateRequest);
  app.addHook('preHandler', requirePermission('users:manage'));

  app.get('/permissions', async () => {
    return { permissions: PERMISSION_CATALOG, matrix: PERMISSION_MATRIX };
  });

  app.get('/roles', async () => {
    const db = getDatabase();
    const rows = db
      .prepare('SELECT id, name, description, permissions_json, is_system, created_at FROM roles ORDER BY is_system DESC, name ASC')
      .all() as Array<{
        id: string;
        name: string;
        description: string | null;
        permissions_json: string;
        is_system: number;
        created_at: string;
      }>;

    return {
      roles: rows.map((r) => ({
        id: r.id,
        name: r.name,
        description: r.description,
        permissions: JSON.parse(r.permissions_json) as string[],
        is_system: r.is_system === 1,
        created_at: r.created_at
      }))
    };
  });

  app.post('/roles', async (request, reply) => {
    const parsed = roleInputSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: parsed.error.issues[0]?.message || 'Dados inválidos.' });
    }

    const caller = request.user as { sub: string };
    const callerAccess = getUserAccessInfo(caller.sub);

    // Bloqueia criação de perfil com acesso à gestão de usuários/admins ou com permissões que o criador não possui
    if (!callerAccess.isMaster) {
      if (parsed.data.permissions.includes('users:manage')) {
        return reply.status(403).send({
          error: 'Acesso negado',
          message: 'Somente o Admin Master pode criar perfis com permissão de gerenciar usuários/administradores.'
        });
      }
      if (!hasSubsetPermissions(callerAccess.permissions, parsed.data.permissions)) {
        return reply.status(403).send({
          error: 'Acesso negado',
          message: 'Você não pode criar um perfil com permissões que você mesmo não possui.'
        });
      }
    }

    const db = getDatabase();
    const exists = db.prepare('SELECT id FROM roles WHERE name = ?').get(parsed.data.name);
    if (exists) {
      return reply.status(409).send({ error: 'Já existe um perfil com este nome.' });
    }

    const id = crypto.randomUUID();
    db.prepare(
      'INSERT INTO roles (id, name, description, permissions_json, is_system) VALUES (?, ?, ?, ?, 0)'
    ).run(id, parsed.data.name, parsed.data.description, JSON.stringify(parsed.data.permissions));

    return reply.status(201).send({ id, ...parsed.data });
  });

  app.put<{ Params: { id: string } }>('/roles/:id', async (request, reply) => {
    const parsed = roleInputSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: parsed.error.issues[0]?.message || 'Dados inválidos.' });
    }

    const caller = request.user as { sub: string };
    const callerAccess = getUserAccessInfo(caller.sub);

    const db = getDatabase();
    const existing = db
      .prepare('SELECT id, is_system FROM roles WHERE id = ?')
      .get(request.params.id) as { id: string; is_system: number } | undefined;

    if (!existing) {
      return reply.status(404).send({ error: 'Perfil não encontrado.' });
    }
    if (existing.is_system === 1) {
      return reply.status(400).send({ error: 'O perfil Administrador padrão não pode ser alterado.' });
    }

    if (!callerAccess.isMaster) {
      if (isPrivilegedRole(existing.id) || parsed.data.permissions.includes('users:manage')) {
        return reply.status(403).send({
          error: 'Acesso negado',
          message: 'Somente o Admin Master pode editar perfis administrativos.'
        });
      }
      if (!hasSubsetPermissions(callerAccess.permissions, parsed.data.permissions)) {
        return reply.status(403).send({
          error: 'Acesso negado',
          message: 'Você não pode conceder permissões que você mesmo não possui.'
        });
      }
    }

    db.prepare('UPDATE roles SET name = ?, description = ?, permissions_json = ? WHERE id = ?').run(
      parsed.data.name,
      parsed.data.description,
      JSON.stringify(parsed.data.permissions),
      request.params.id
    );

    return reply.send({ updated: true });
  });

  app.delete<{ Params: { id: string } }>('/roles/:id', async (request, reply) => {
    const caller = request.user as { sub: string };
    const callerAccess = getUserAccessInfo(caller.sub);

    const db = getDatabase();
    const existing = db
      .prepare('SELECT id, is_system FROM roles WHERE id = ?')
      .get(request.params.id) as { id: string; is_system: number } | undefined;

    if (!existing) {
      return reply.status(404).send({ error: 'Perfil não encontrado.' });
    }
    if (existing.is_system === 1) {
      return reply.status(400).send({ error: 'O perfil Administrador padrão não pode ser excluído.' });
    }
    if (!callerAccess.isMaster && isPrivilegedRole(existing.id)) {
      return reply.status(403).send({
        error: 'Acesso negado',
        message: 'Somente o Admin Master pode excluir perfis administrativos.'
      });
    }

    db.prepare('DELETE FROM roles WHERE id = ?').run(request.params.id);
    return reply.send({ deleted: true });
  });

  app.get('/', async () => {
    const db = getDatabase();
    const users = db
      .prepare(`
        SELECT u.id, u.username, u.role_id, u.is_master, u.created_at, r.name as role_name
        FROM users u
        LEFT JOIN roles r ON r.id = u.role_id
        ORDER BY u.is_master DESC, u.username ASC
      `)
      .all() as Array<{
        id: string;
        username: string;
        role_id: string | null;
        is_master: number;
        created_at: string;
        role_name: string | null;
      }>;

    return {
      users: users.map((u) => ({
        ...u,
        is_master: u.is_master === 1,
        is_privileged: isPrivilegedRole(u.role_id)
      }))
    };
  });

  app.post('/', async (request, reply) => {
    const parsed = createUserSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: parsed.error.issues[0]?.message || 'Dados inválidos.' });
    }

    const caller = request.user as { sub: string };
    const callerAccess = getUserAccessInfo(caller.sub);

    if (!callerAccess.isMaster) {
      if (isPrivilegedRole(parsed.data.roleId)) {
        return reply.status(403).send({
          error: 'Acesso negado',
          message: 'Somente o Admin Master pode criar contas de Administradores ou com gestão de usuários.'
        });
      }
      const targetPerms = getRolePermissions(parsed.data.roleId);
      if (!hasSubsetPermissions(callerAccess.permissions, targetPerms)) {
        return reply.status(403).send({
          error: 'Acesso negado',
          message: 'Você não pode criar um usuário com permissões superiores às suas.'
        });
      }
    }

    const db = getDatabase();
    const exists = db.prepare('SELECT id FROM users WHERE username = ?').get(parsed.data.username);
    if (exists) {
      return reply.status(409).send({ error: 'Já existe um usuário com este login.' });
    }

    const id = crypto.randomUUID();
    const passwordHash = hashPassword(parsed.data.password);
    db.prepare('INSERT INTO users (id, username, password_hash, role_id, is_master) VALUES (?, ?, ?, ?, 0)').run(
      id,
      parsed.data.username,
      passwordHash,
      parsed.data.roleId
    );

    return reply.status(201).send({ id, username: parsed.data.username, roleId: parsed.data.roleId });
  });

  app.put<{ Params: { id: string } }>('/:id', async (request, reply) => {
    const parsed = updateUserSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: parsed.error.issues[0]?.message || 'Dados inválidos.' });
    }

    const caller = request.user as { sub: string };
    const callerAccess = getUserAccessInfo(caller.sub);
    const db = getDatabase();

    const target = db
      .prepare('SELECT id, role_id, is_master FROM users WHERE id = ?')
      .get(request.params.id) as { id: string; role_id: string | null; is_master: number } | undefined;

    if (!target) {
      return reply.status(404).send({ error: 'Usuário não encontrado.' });
    }

    // Ninguém pode alterar o perfil do Admin Master
    if (target.is_master === 1 && parsed.data.roleId && parsed.data.roleId !== target.role_id) {
      return reply.status(403).send({
        error: 'Operação bloqueada',
        message: 'O perfil do Admin Master não pode ser alterado.'
      });
    }

    // Somente o Master pode mexer em contas de outros admins, promover ou alterar o próprio perfil
    if (!callerAccess.isMaster) {
      if (caller.sub === request.params.id && parsed.data.roleId && parsed.data.roleId !== target.role_id) {
        return reply.status(403).send({
          error: 'Acesso negado',
          message: 'Você não pode alterar o seu próprio perfil de acesso.'
        });
      }
      if (target.is_master === 1 || isPrivilegedRole(target.role_id) || isPrivilegedRole(parsed.data.roleId ?? null)) {
        return reply.status(403).send({
          error: 'Acesso negado',
          message: 'Somente o Admin Master pode alterar contas administrativas ou conceder acesso admin.'
        });
      }
      const newPerms = parsed.data.roleId ? getRolePermissions(parsed.data.roleId) : [];
      const currentPerms = getRolePermissions(target.role_id);
      if (
        !hasSubsetPermissions(callerAccess.permissions, currentPerms) ||
        !hasSubsetPermissions(callerAccess.permissions, newPerms)
      ) {
        return reply.status(403).send({
          error: 'Acesso negado',
          message: 'Você não pode alterar usuários que possuam permissões além das suas.'
        });
      }
    }

    if (parsed.data.roleId) {
      db.prepare('UPDATE users SET role_id = ? WHERE id = ?').run(parsed.data.roleId, request.params.id);
    }
    if (parsed.data.password) {
      db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(
        hashPassword(parsed.data.password),
        request.params.id
      );
    }

    return reply.send({ updated: true });
  });

  app.delete<{ Params: { id: string } }>('/:id', async (request, reply) => {
    const caller = request.user as { sub: string };
    if (caller.sub === request.params.id) {
      return reply.status(400).send({ error: 'Você não pode excluir o próprio usuário conectado.' });
    }

    const callerAccess = getUserAccessInfo(caller.sub);
    const db = getDatabase();
    const target = db
      .prepare('SELECT id, role_id, is_master FROM users WHERE id = ?')
      .get(request.params.id) as { id: string; role_id: string | null; is_master: number } | undefined;

    if (!target) {
      return reply.status(404).send({ error: 'Usuário não encontrado.' });
    }

    if (target.is_master === 1) {
      return reply.status(403).send({
        error: 'Operação bloqueada',
        message: 'O Admin Master é protegido e não pode ser excluído.'
      });
    }

    if (!callerAccess.isMaster && isPrivilegedRole(target.role_id)) {
      return reply.status(403).send({
        error: 'Acesso negado',
        message: 'Somente o Admin Master pode excluir outros administradores.'
      });
    }

    db.prepare('DELETE FROM users WHERE id = ?').run(request.params.id);
    return reply.send({ deleted: true });
  });
}
